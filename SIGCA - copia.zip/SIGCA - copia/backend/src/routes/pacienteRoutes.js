
const express = require('express');
const router = express.Router();

const {
  crearPaciente,
  obtenerPacientes,
  obtenerPacientePorId,
  actualizarPaciente,
  cambiarEstadoPaciente
} = require('../controllers/pacienteController');

const {
  verificarToken,
  permitirRoles
} = require('../middlewares/authMiddleware');

// Todas las operaciones requieren una sesión válida.
router.use(verificarToken);

// Consultar pacientes.
router.get(
  '/',
  permitirRoles('ADMINISTRADOR', 'RECEPCIONISTA', 'PROFESIONAL'),
  obtenerPacientes
);

// Consultar paciente por ID.
router.get(
  '/:id',
  permitirRoles('ADMINISTRADOR', 'RECEPCIONISTA', 'PROFESIONAL'),
  obtenerPacientePorId
);

// Registrar paciente.
router.post(
  '/',
  permitirRoles('ADMINISTRADOR', 'RECEPCIONISTA'),
  crearPaciente
);

// Actualizar paciente.
router.put(
  '/:id',
  permitirRoles('ADMINISTRADOR', 'RECEPCIONISTA'),
  actualizarPaciente
);

// Activar o desactivar paciente.
router.patch(
  '/:id/estado',
  permitirRoles('ADMINISTRADOR', 'RECEPCIONISTA'),
  cambiarEstadoPaciente
);

module.exports = router;