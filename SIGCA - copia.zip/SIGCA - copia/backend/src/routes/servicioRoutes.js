const express = require('express');
const router = express.Router();

const {
  crearServicio,
  obtenerServicios,
  obtenerServicioPorId,
  actualizarServicio,
  cambiarEstadoServicio
} = require('../controllers/servicioController');

const {
  verificarToken,
  permitirRoles
} = require('../middlewares/authMiddleware');

// Consultas públicas
router.get('/', obtenerServicios);
router.get('/:id', obtenerServicioPorId);

// Crear servicio: administrador o recepcionista
router.post(
  '/',
  verificarToken,
  permitirRoles('ADMINISTRADOR', 'RECEPCIONISTA'),
  crearServicio
);

// Editar servicio
router.put(
  '/:id',
  verificarToken,
  permitirRoles('ADMINISTRADOR', 'RECEPCIONISTA'),
  actualizarServicio
);

// Activar o desactivar servicio
router.patch(
  '/:id/estado',
  verificarToken,
  permitirRoles('ADMINISTRADOR', 'RECEPCIONISTA'),
  cambiarEstadoServicio
);

module.exports = router;
