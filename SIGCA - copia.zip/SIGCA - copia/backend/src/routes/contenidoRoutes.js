
const router = require('express').Router();

const contenido = require('../controllers/contenidoController');

const {
  verificarToken,
  permitirRoles
} = require('../middlewares/authMiddleware');

// Consulta pública
router.get('/publico', contenido.publico);

// Administración protegida
router.get(
  '/admin',
  verificarToken,
  permitirRoles('ADMINISTRADOR'),
  contenido.admin
);

router.put(
  '/admin',
  verificarToken,
  permitirRoles('ADMINISTRADOR'),
  contenido.guardar
);

router.patch(
  '/admin/publicacion',
  verificarToken,
  permitirRoles('ADMINISTRADOR'),
  contenido.publicar
);

module.exports = router;