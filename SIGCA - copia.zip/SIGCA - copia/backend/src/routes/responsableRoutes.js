
const express = require('express');
const router = express.Router();

const {
  crearResponsable,
  obtenerResponsables,
  obtenerResponsablePorId,
  actualizarResponsable,
  asociarPacientes,
  obtenerPacientesAsociados
} = require('../controllers/responsableController');

const {
  verificarToken,
  permitirRoles
} = require('../middlewares/authMiddleware');

// Proteger todas las rutas de responsables.
router.use(verificarToken);

// Consultar responsables.
router.get(
  '/',
  permitirRoles('ADMINISTRADOR', 'RECEPCIONISTA'),
  obtenerResponsables
);

// Consultar responsable por ID.
router.get(
  '/:id',
  permitirRoles('ADMINISTRADOR', 'RECEPCIONISTA'),
  obtenerResponsablePorId
);

// Registrar responsable.
router.post(
  '/',
  permitirRoles('ADMINISTRADOR', 'RECEPCIONISTA'),
  crearResponsable
);

// Actualizar responsable.
router.put(
  '/:id',
  permitirRoles('ADMINISTRADOR', 'RECEPCIONISTA'),
  actualizarResponsable
);

// Asociar pacientes a un responsable.
router.post(
  '/:id/pacientes',
  permitirRoles('ADMINISTRADOR', 'RECEPCIONISTA'),
  asociarPacientes
);

// Consultar pacientes asociados.
router.get(
  '/:id/pacientes',
  permitirRoles('ADMINISTRADOR', 'RECEPCIONISTA'),
  obtenerPacientesAsociados
);

module.exports = router;