
const express = require('express');
const router = express.Router();

const {
  crearMaterial,
  obtenerMateriales,
  obtenerMaterialPorId,
  actualizarMaterial,
  cambiarEstadoMaterial,
  eliminarMaterial
} = require('../controllers/materialController');

const {
  verificarToken,
  permitirRoles
} = require('../middlewares/authMiddleware');

// Todas las operaciones requieren autenticación.
router.use(verificarToken);

// Consultar materiales.
// El profesional puede ver el inventario.
router.get(
  '/',
  permitirRoles('ADMINISTRADOR', 'RECEPCIONISTA', 'PROFESIONAL'),
  obtenerMateriales
);

// Consultar un material por ID.
router.get(
  '/:id',
  permitirRoles('ADMINISTRADOR', 'RECEPCIONISTA', 'PROFESIONAL'),
  obtenerMaterialPorId
);

// Registrar material.
router.post(
  '/',
  permitirRoles('ADMINISTRADOR', 'RECEPCIONISTA'),
  crearMaterial
);

// Actualizar material.
router.put(
  '/:id',
  permitirRoles('ADMINISTRADOR', 'RECEPCIONISTA'),
  actualizarMaterial
);

// Cambiar estado de material.
router.patch(
  '/:id/estado',
  permitirRoles('ADMINISTRADOR', 'RECEPCIONISTA'),
  cambiarEstadoMaterial
);

// Eliminar material.
router.delete(
  '/:id',
  permitirRoles('ADMINISTRADOR', 'RECEPCIONISTA'),
  eliminarMaterial
);

module.exports = router;