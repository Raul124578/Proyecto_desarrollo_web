const express = require('express');
const router = express.Router();

const {
  crearUsuario,
  obtenerUsuarios,
  actualizarUsuario,
  restablecerPassword
} = require('../controllers/usuarioController');

const {
  verificarToken,
  permitirRoles
} = require('../middlewares/authMiddleware');

router.use(verificarToken);

// Consulta autorizada de profesionales
router.get(
  '/profesionales',
  permitirRoles('ADMINISTRADOR', 'RECEPCIONISTA', 'PROFESIONAL'),
  async (req, res) => {
    try {
      const Usuario = require('../models/Usuario');

      const profesionales = await Usuario.find({
        rol: 'PROFESIONAL',
        estado: 'ACTIVO'
      }).select('_id nombre correo');

      return res.status(200).json(profesionales);
    } catch (error) {
      return res.status(500).json({
        mensaje: 'Error al consultar profesionales'
      });
    }
  }
);

// Operaciones exclusivas del administrador
router.use(permitirRoles('ADMINISTRADOR'));

router.get('/', obtenerUsuarios);

// Consultar usuarios.
router.get('/', obtenerUsuarios);

// Registrar usuario.
router.post('/', crearUsuario);

// Editar información, rol o estado.
router.put('/:id', actualizarUsuario);

// Restablecer contraseña.
router.put('/:id/password', restablecerPassword);

module.exports = router;