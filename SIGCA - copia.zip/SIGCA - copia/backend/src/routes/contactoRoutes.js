
const router = require('express').Router();

const contactoController = require(
  '../controllers/contactoController'
);

const {
  verificarToken,
  permitirRoles
} = require('../middlewares/authMiddleware');

// Cualquier visitante puede enviar un mensaje.
router.post(
  '/',
  contactoController.crearMensaje
);

// Solo administradores pueden consultar mensajes.
router.get(
  '/admin',
  verificarToken,
  permitirRoles('ADMINISTRADOR'),
  contactoController.listarMensajes
);

// Solo administradores pueden actualizar el estado.
router.patch(
  '/admin/:id/estado',
  verificarToken,
  permitirRoles('ADMINISTRADOR'),
  contactoController.actualizarEstado
);

module.exports = router;