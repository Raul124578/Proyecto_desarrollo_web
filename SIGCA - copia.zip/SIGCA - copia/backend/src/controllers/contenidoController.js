
const Contenido = require('../models/ContenidoInstitucional');

const camposPermitidos = [
  'institucion',
  'lema',
  'mision',
  'vision',
  'valores',
  'actividades',
  'horarios',
  'contacto',
  'carrusel'
];

const publico = async (req, res) => {
  try {
    const contenido = await Contenido.findOne({
      clave: 'principal',
      publicado: true
    });

    if (!contenido) {
      return res.status(404).json({
        mensaje: 'No hay contenido publicado'
      });
    }

    return res.status(200).json(contenido);
  } catch (error) {
    return res.status(500).json({
      mensaje: 'Error al consultar contenido'
    });
  }
};

const admin = async (req, res) => {
  try {
    const contenido = await Contenido.findOne({
      clave: 'principal'
    });

    return res.status(200).json(contenido || {});
  } catch (error) {
    return res.status(500).json({
      mensaje: 'Error al consultar contenido'
    });
  }
};

const guardar = async (req, res) => {
  try {
    const datos = {};

    for (const campo of camposPermitidos) {
      if (Object.prototype.hasOwnProperty.call(
        req.body || {}, campo
      )) {
        datos[campo] = req.body[campo];
      }
    }

    if (Object.keys(datos).length === 0) {
      return res.status(400).json({
        mensaje: 'No se enviaron campos válidos'
      });
    }

    const contenido = await Contenido.findOneAndUpdate(
      { clave: 'principal' },
      {
        $set: datos,
        $setOnInsert: {
          clave: 'principal',
          publicado: false
        }
      },
      {
        new: true,
        upsert: true,
        runValidators: true
      }
    );

    return res.status(200).json({
      mensaje: 'Contenido institucional guardado correctamente',
      contenido
    });
  } catch (error) {
    return res.status(
      ['ValidationError', 'CastError'].includes(error.name)
        ? 400 : 500
    ).json({
      mensaje: 'No se pudo guardar el contenido'
    });
  }
};

const publicar = async (req, res) => {
  try {
    if (typeof req.body?.publicado !== 'boolean') {
      return res.status(400).json({
        mensaje: 'publicado debe ser true o false'
      });
    }

    const contenido = await Contenido.findOneAndUpdate(
      { clave: 'principal' },
      { $set: { publicado: req.body.publicado } },
      { new: true }
    );

    if (!contenido) {
      return res.status(404).json({
        mensaje: 'Primero registre contenido'
      });
    }

    return res.status(200).json({
      mensaje: 'Publicación actualizada',
      contenido
    });
  } catch (error) {
    return res.status(500).json({
      mensaje: 'Error al publicar'
    });
  }
};

module.exports = {
  publico,
  admin,
  guardar,
  publicar
};
