const mongoose = require('mongoose');
const Recurso = require('../models/RecursoEducativo');
const Asignacion = require('../models/AsignacionRecurso');
const Paciente = require('../models/Paciente');
const errorRespuesta = (res, e) => {
  if (e.name === 'ValidationError') return res.status(400).json({ mensaje: Object.values(e.errors).map(x => x.message).join('; ') });
  if (e.code === 11000) return res.status(409).json({ mensaje: 'El recurso ya está asignado a ese paciente' });
  console.error('Recursos educativos:', e);
  return res.status(500).json({ mensaje: 'Error al procesar recursos educativos' });
};
const idValido = id => mongoose.isValidObjectId(id);
const campos = body => Object.fromEntries(['titulo','descripcion','tipo','enlaceRecurso'].filter(k => body[k] !== undefined).map(k => [k,body[k]]));
exports.listar = async (req,res) => {
  try { const filtro = req.query.estado ? { estado: req.query.estado } : {};
    return res.json(await Recurso.find(filtro).sort({ fechaRegistro: -1 }));
  } catch(e) { return errorRespuesta(res,e); }
};
exports.crear = async (req,res) => {
  try { const recurso = await Recurso.create(campos(req.body)); return res.status(201).json(recurso); }
  catch(e) { return errorRespuesta(res,e); }
};
exports.actualizar = async (req,res) => {
  if (!idValido(req.params.id)) return res.status(400).json({ mensaje:'ID inválido' });
  try { const recurso = await Recurso.findByIdAndUpdate(req.params.id, { $set: campos(req.body) }, { new:true, runValidators:true });
    return recurso ? res.json(recurso) : res.status(404).json({ mensaje:'Recurso no encontrado' }); }
  catch(e) { return errorRespuesta(res,e); }
};
exports.cambiarEstado = async (req,res) => {
  if (!idValido(req.params.id) || !['ACTIVO','INACTIVO'].includes(req.body.estado)) return res.status(400).json({ mensaje:'ID o estado inválido' });
  try { const recurso = await Recurso.findByIdAndUpdate(req.params.id, { $set: { estado:req.body.estado } }, { new:true, runValidators:true });
    return recurso ? res.json(recurso) : res.status(404).json({ mensaje:'Recurso no encontrado' }); }
  catch(e) { return errorRespuesta(res,e); }
};
exports.listarAsignaciones = async (req,res) => {
  try { return res.json(await Asignacion.find().populate('paciente','nombres apellidos estado').populate('recurso','titulo tipo enlaceRecurso estado').sort({ fechaAsignacion:-1 })); }
  catch(e) { return errorRespuesta(res,e); }
};
exports.asignar = async (req,res) => {
  const { pacienteId, recursoId, observaciones = '' } = req.body;
  if (!idValido(pacienteId) || !idValido(recursoId)) return res.status(400).json({ mensaje:'IDs inválidos' });
  try {
    const [paciente,recurso] = await Promise.all([Paciente.findById(pacienteId),Recurso.findById(recursoId)]);
    if (!paciente || !recurso) return res.status(404).json({ mensaje:'Paciente o recurso no encontrado' });
    if (paciente.estado !== 'ACTIVO' || recurso.estado !== 'ACTIVO') return res.status(400).json({ mensaje:'Solo pueden asignarse recursos activos a pacientes activos' });
    const asignacion = await Asignacion.create({ paciente:pacienteId, recurso:recursoId, observaciones, asignadoPor:req.usuario._id });
    return res.status(201).json(asignacion);
  } catch(e) { return errorRespuesta(res,e); }
};
