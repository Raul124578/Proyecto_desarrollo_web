
const mongoose = require('mongoose');
const AsignacionMaterial = require('../models/AsignacionMaterial');
const Material = require('../models/Material');
const Paciente = require('../models/Paciente');

// Manejo de errores
const manejarError = (res, error) => {
  if (error.name === 'ValidationError') {
    return res.status(400).json({
      mensaje: 'Error de validación',
      errores: Object.values(error.errors).map(e => e.message)
    });
  }

  if (error.name === 'CastError') {
    return res.status(400).json({
      mensaje: 'Identificador inválido'
    });
  }

  console.error('Error en asignaciones:', error);

  return res.status(500).json({
    mensaje: 'Error interno al procesar la asignación'
  });
};

// Actualizar estado según existencias
const actualizarEstadoMaterial = async (materialId, cantidadActual) => {
  const estado = cantidadActual === 0
    ? 'AGOTADO'
    : 'DISPONIBLE';

  await Material.updateOne(
    {
      _id: materialId,
      estado: { $ne: 'MANTENIMIENTO' }
    },
    {
      $set: { estado }
    }
  );
};

// CREAR ASIGNACIÓN
const crearAsignacion = async (req, res) => {
  let reservado = false;
  let materialId;
  let cantidad;

  try {
    const { pacienteId, observaciones } = req.body;

    materialId = req.body.materialId;
    cantidad = Number(req.body.cantidad);

    // Validar identificadores
    if (
      !mongoose.isValidObjectId(materialId) ||
      !mongoose.isValidObjectId(pacienteId)
    ) {
      return res.status(400).json({
        mensaje: 'IDs de material y paciente inválidos'
      });
    }

    // Validar cantidad
    if (!Number.isSafeInteger(cantidad) || cantidad < 1) {
      return res.status(400).json({
        mensaje: 'La cantidad debe ser un entero positivo'
      });
    }

    // Validar observaciones
    if (
      observaciones != null &&
      (
        typeof observaciones !== 'string' ||
        observaciones.length > 1000
      )
    ) {
      return res.status(400).json({
        mensaje: 'Observaciones inválidas (máximo 1000 caracteres)'
      });
    }

    // Verificar paciente
    const paciente = await Paciente.findById(pacienteId);

    if (!paciente) {
      return res.status(404).json({
        mensaje: 'Paciente no encontrado'
      });
    }

    if (paciente.estado !== 'ACTIVO') {
      return res.status(400).json({
        mensaje: 'Solo se permiten asignaciones a pacientes activos (RN-09)'
      });
    }

    // Verificar material
    const material = await Material.findById(materialId);

    if (!material) {
      return res.status(404).json({
        mensaje: 'Material no encontrado'
      });
    }

    if (material.estado === 'MANTENIMIENTO') {
      return res.status(400).json({
        mensaje: 'Material en mantenimiento'
      });
    }

    // Descontar existencias
    const actualizado = await Material.findOneAndUpdate(
      {
        _id: materialId,
        cantidad: { $gte: cantidad },
        estado: {
          $nin: ['MANTENIMIENTO', 'AGOTADO']
        }
      },
      {
        $inc: { cantidad: -cantidad }
      },
      {
        new: true
      }
    );

    if (!actualizado) {
      return res.status(400).json({
        mensaje: 'Existencias insuficientes o material no disponible'
      });
    }

    reservado = true;

    // Registrar asignación
    const asignacion = await AsignacionMaterial.create({
      material: materialId,
      paciente: pacienteId,
      cantidad,
      asignadoPor: req.usuario._id,
      observaciones: observaciones || '',
      estado: 'ASIGNADO'
    });

    reservado = false;

    // Sincronizar estado
    try {
      await actualizarEstadoMaterial(
        materialId,
        actualizado.cantidad
      );
    } catch (errorEstado) {
      console.error(
        'Aviso: no se pudo sincronizar el estado:',
        errorEstado
      );
    }

    // Consultar detalle
    const detalle = await AsignacionMaterial.findById(asignacion._id)
      .populate('material', 'nombre categoria cantidad estado')
      .populate('paciente', 'nombres apellidos estado')
      .populate('asignadoPor', 'nombre correo');

    return res.status(201).json({
      mensaje: 'Material asignado correctamente',
      asignacion: detalle || asignacion
    });

  } catch (error) {

    // Restaurar existencias si falla el registro
    if (reservado) {
      try {
        const restaurado = await Material.findByIdAndUpdate(
          materialId,
          {
            $inc: { cantidad }
          },
          {
            new: true
          }
        );

        if (restaurado) {
          await actualizarEstadoMaterial(
            materialId,
            restaurado.cantidad
          );
        }

      } catch (reversionError) {
        console.error(
          'ALERTA: No se pudo restaurar el inventario:',
          reversionError
        );
      }
    }

    return manejarError(res, error);
  }
};

// CONSULTAR ASIGNACIONES
const obtenerAsignaciones = async (req, res) => {
  try {
    const filtro = {};

    const campos = [
      ['pacienteId', 'paciente'],
      ['materialId', 'material']
    ];

    for (const [campo, clave] of campos) {
      if (req.query[campo]) {

        if (!mongoose.isValidObjectId(req.query[campo])) {
          return res.status(400).json({
            mensaje: `${campo} inválido`
          });
        }

        filtro[clave] = req.query[campo];
      }
    }

    if (req.query.estado) {
      const estadosValidos = [
        'ASIGNADO',
        'DEVUELTO',
        'EXTRAVIADO'
      ];

      if (!estadosValidos.includes(req.query.estado)) {
        return res.status(400).json({
          mensaje: 'Estado inválido'
        });
      }

      filtro.estado = req.query.estado;
    }

    const asignaciones = await AsignacionMaterial.find(filtro)
      .populate('material', 'nombre categoria cantidad estado')
      .populate('paciente', 'nombres apellidos estado')
      .populate('asignadoPor', 'nombre correo')
      .sort({ fechaAsignacion: -1 });

    return res.status(200).json(asignaciones);

  } catch (error) {
    return manejarError(res, error);
  }
};

// DEVOLVER MATERIAL
const devolverAsignacion = async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({
        mensaje: 'ID de asignación inválido'
      });
    }

    // Marcar asignación como devuelta
    const asignacion = await AsignacionMaterial.findOneAndUpdate(
      {
        _id: req.params.id,
        estado: 'ASIGNADO'
      },
      {
        $set: {
          estado: 'DEVUELTO',
          fechaDevolucion: new Date()
        }
      },
      {
        new: true
      }
    );

    if (!asignacion) {
      return res.status(404).json({
        mensaje: 'Asignación inexistente o ya procesada'
      });
    }

    let material;

    try {
      // Devolver unidades al inventario
      material = await Material.findByIdAndUpdate(
        asignacion.material,
        {
          $inc: {
            cantidad: asignacion.cantidad
          }
        },
        {
          new: true
        }
      );

      if (!material) {
        throw new Error('Material asociado no encontrado');
      }

    } catch (errorInventario) {

      // Revertir estado si falla el inventario
      try {
        await AsignacionMaterial.updateOne(
          {
            _id: asignacion._id,
            estado: 'DEVUELTO'
          },
          {
            $set: {
              estado: 'ASIGNADO',
              fechaDevolucion: null
            }
          }
        );

      } catch (errorReversion) {
        console.error(
          'ALERTA: No se pudo revertir la devolución:',
          errorReversion
        );
      }

      throw errorInventario;
    }

    // Actualizar disponibilidad
    try {
      await actualizarEstadoMaterial(
        asignacion.material,
        material.cantidad
      );
    } catch (errorEstado) {
      console.error(
        'Aviso: no se pudo sincronizar el estado:',
        errorEstado
      );
    }

    return res.status(200).json({
      mensaje: 'Material devuelto y existencias actualizadas',
      asignacion
    });

  } catch (error) {
    return manejarError(res, error);
  }
};

// Exportar funciones
module.exports = {
  crearAsignacion,
  obtenerAsignaciones,
  devolverAsignacion
};
