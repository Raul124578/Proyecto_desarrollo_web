
const MensajeContacto = require('../models/MensajeContacto');

const crearMensaje = async (req, res) => {
  try {
    const {
      nombre,
      correo,
      telefono,
      asunto,
      mensaje
    } = req.body || {};

    if (
      !nombre?.trim() ||
      !correo?.trim() ||
      !asunto?.trim() ||
      !mensaje?.trim()
    ) {
      return res.status(400).json({
        mensaje: 'Complete todos los campos obligatorios'
      });
    }

    const correoValido = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!correoValido.test(correo.trim())) {
      return res.status(400).json({
        mensaje: 'Ingrese un correo electrónico válido'
      });
    }

    const nuevoMensaje = await MensajeContacto.create({
      nombre,
      correo,
      telefono: telefono || '',
      asunto,
      mensaje
    });

    return res.status(201).json({
      mensaje: 'Mensaje enviado correctamente',
      id: nuevoMensaje._id
    });

  } catch (error) {
    if (error.name === 'ValidationError') {
      return res.status(400).json({
        mensaje: 'Revise los datos enviados'
      });
    }

    console.error('Error al guardar contacto:', error.message);

    return res.status(500).json({
      mensaje: 'No fue posible enviar el mensaje'
    });
  }
};

const listarMensajes = async (req, res) => {
  try {
    const mensajes = await MensajeContacto.find()
      .sort({ createdAt: -1 })
      .limit(100);

    return res.status(200).json(mensajes);
  } catch (error) {
    return res.status(500).json({
      mensaje: 'Error al consultar mensajes'
    });
  }
};

const actualizarEstado = async (req, res) => {
  try {
    const { estado } = req.body || {};

    if (!['PENDIENTE', 'ATENDIDO'].includes(estado)) {
      return res.status(400).json({
        mensaje: 'Estado no válido'
      });
    }

    const mensaje = await MensajeContacto.findByIdAndUpdate(
      req.params.id,
      { estado },
      { new: true, runValidators: true }
    );

    if (!mensaje) {
      return res.status(404).json({
        mensaje: 'Mensaje no encontrado'
      });
    }

    return res.status(200).json({
      mensaje: 'Estado actualizado correctamente',
      contacto: mensaje
    });
  } catch (error) {
    return res.status(
      error.name === 'CastError' ? 400 : 500
    ).json({
      mensaje: 'No se pudo actualizar el mensaje'
    });
  }
};

module.exports = {
  crearMensaje,
  listarMensajes,
  actualizarEstado
};