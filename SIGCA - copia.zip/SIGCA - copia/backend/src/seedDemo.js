
require('dotenv').config();
const mongoose = require('mongoose');

const Usuario = require('./models/Usuario');
const Paciente = require('./models/Paciente');
const Responsable = require('./models/Responsable');
const Servicio = require('./models/Servicio');
const Horario = require('./models/Horario');
const Cita = require('./models/Cita');
const Caja = require('./models/Caja');
const Pago = require('./models/Pago');
const Material = require('./models/Material');
const SolicitudCita = require('./models/SolicitudCita');

const MARCA = '[DEMO-SIGCA-2026]';
const CORREOS = {
  recepcion: 'recepcion.demo@sigca.example',
  profesional: 'profesional.demo@sigca.example'
};

// Las fechas corresponden a la hora de Guatemala (UTC-6).
const fecha = (dia, hora) =>
  new Date(`${dia}T${hora}:00-06:00`);

async function obtenerOCrear(Modelo, filtro, datos) {
  const existente = await Modelo.findOne(filtro);
  if (existente) return existente;

  return Modelo.create(datos);
}

async function crearUsuario(nombre, correo, rol, password) {
  let usuario = await Usuario.findOne({ correo });

  if (usuario) {
    if (usuario.rol !== rol) {
      throw new Error(
        `El correo ${correo} existe con otro rol.`
      );
    }
    return usuario;
  }

  // create() ejecuta el hook de bcrypt del modelo.
  usuario = await Usuario.create({
    nombre,
    correo,
    password,
    rol,
    estado: 'ACTIVO'
  });

  return usuario;
}

async function ejecutar() {
  const uri =
    process.env.MONGO_URI ||
    process.env.MONGODB_URI ||
    'mongodb://127.0.0.1:27017/sigca';

  const password = process.env.SIGCA_DEMO_PASSWORD;

  if (!password || Buffer.byteLength(password, 'utf8') < 8 ||
      Buffer.byteLength(password, 'utf8') > 72) {
    throw new Error(
      'Define SIGCA_DEMO_PASSWORD con una contraseña ' +
      'de 8 a 72 bytes antes de ejecutar.'
    );
  }

  await mongoose.connect(uri, { dbName: 'sigca' });

  console.log('Conectado a MongoDB:', mongoose.connection.name);

  const administrador = await Usuario.findOne({
    rol: 'ADMINISTRADOR',
    estado: 'ACTIVO'
  });

  if (!administrador) {
    throw new Error(
      'No existe un administrador activo. ' +
      'Verifica el usuario actual antes de continuar.'
    );
  }

  // 1. Usuarios
  const recepcionista = await crearUsuario(
    'Recepcionista Demo',
    CORREOS.recepcion,
    'RECEPCIONISTA',
    password
  );

  const profesional = await crearUsuario(
    'Profesional Demo',
    CORREOS.profesional,
    'PROFESIONAL',
    password
  );

  console.log('Usuarios de prueba preparados.');

  // 2. Servicios
  const datosServicios = [
    ['Evaluación de lenguaje', 'Evaluación inicial de lenguaje.', 60, 15000],
    ['Terapia ocupacional', 'Sesión de habilidades funcionales.', 45, 12500],
    ['Orientación familiar', 'Acompañamiento a familiares.', 60, 10000],
    ['Evaluación auditiva', 'Valoración auditiva inicial.', 45, 17500],
    ['Terapia de comunicación', 'Fortalecimiento de comunicación.', 60, 14000],
    ['Seguimiento terapéutico', 'Seguimiento del proceso.', 30, 8000]
  ];

  const servicios = [];

  for (let i = 0; i < datosServicios.length; i++) {
    const [nombre, descripcion, duracion, precio] = datosServicios[i];
    const nombreDemo = `${nombre} ${MARCA}`;

    servicios.push(await obtenerOCrear(
      Servicio,
      { nombre: nombreDemo },
      {
        nombre: nombreDemo,
        descripcion,
        duracionMinutos: duracion,
        precioCentavos: precio,
        estado: 'ACTIVO'
      }
    ));
  }

  console.log('Servicios preparados.');

  // 3. Pacientes y responsables
  const personas = [
    ['Daniel', 'López', '2015-04-12', 'MASCULINO',
     'María', 'López', 'Madre'],
    ['Lucía', 'Pérez', '2017-08-20', 'FEMENINO',
     'Ana', 'Pérez', 'Madre'],
    ['Mateo', 'García', '2014-02-10', 'MASCULINO',
     'Carlos', 'García', 'Padre'],
    ['Sofía', 'Morales', '2018-06-15', 'FEMENINO',
     'Elena', 'Morales', 'Madre'],
    ['Valeria', 'Ramírez', '2016-11-03', 'FEMENINO',
     'Jorge', 'Ramírez', 'Padre']
  ];

  const pacientes = [];

  for (let i = 0; i < personas.length; i++) {
    const [nombres, apellido, nacimiento, sexo,
      nombreResponsable, apellidoResponsable, parentesco] = personas[i];

    const correo = `responsable.demo${i + 1}@sigca.example`;

    const responsable = await obtenerOCrear(
      Responsable,
      { correo },
      {
        nombres: nombreResponsable,
        apellidos: apellidoResponsable,
        parentesco,
        telefono: `5550100${i + 1}`,
        correo,
        direccion: 'Dirección ficticia, Guatemala',
        pacientes: []
      }
    );

    const paciente = await obtenerOCrear(
      Paciente,
      {
        nombres,
        apellidos: `${apellido} ${MARCA}`
      },
      {
        nombres,
        apellidos: `${apellido} ${MARCA}`,
        fechaNacimiento: new Date(`${nacimiento}T12:00:00Z`),
        sexo,
        telefono: `5550200${i + 1}`,
        direccion: 'Dirección ficticia, Guatemala',
        observaciones: 'Registro de demostración SIGCA',
        estado: 'ACTIVO',
        responsables: [responsable._id]
      }
    );

    // Sin duplicar las relaciones existentes.
    await Paciente.updateOne(
      { _id: paciente._id },
      { $addToSet: { responsables: responsable._id } }
    );

    await Responsable.updateOne(
      { _id: responsable._id },
      { $addToSet: { pacientes: paciente._id } }
    );

    pacientes.push(paciente);
  }

  console.log('Pacientes y responsables preparados.');

  // 4. Horarios: lunes a viernes, 8:00 a 16:00
  for (let dia = 1; dia <= 5; dia++) {
    await obtenerOCrear(
      Horario,
      { diaSemana: dia },
      {
        diaSemana: dia,
        activo: true,
        tramos: [
          { inicioMinuto: 480, finMinuto: 720 },
          { inicioMinuto: 780, finMinuto: 960 }
        ]
      }
    );
  }

  console.log('Horarios preparados.');

  // 5. Materiales
  const datosMateriales = [
    ['Tarjetas de lenguaje', 'Material para comunicación', 20, 'Fonoaudiología'],
    ['Bloques didácticos', 'Material de coordinación', 15, 'Terapia Ocupacional'],
    ['Guías familiares', 'Material educativo', 30, 'Orientación Familiar'],
    ['Kit de evaluación', 'Instrumentos de evaluación', 5, 'Diagnóstico Clínico'],
    ['Audífonos de prueba', 'Equipo de apoyo auditivo', 4, 'Audiología']
  ];

  for (const [nombre, descripcion, cantidad, categoria] of datosMateriales) {
    const nombreDemo = `${nombre} ${MARCA}`;

    await obtenerOCrear(
      Material,
      { nombre: nombreDemo },
      {
        nombre: nombreDemo,
        descripcion,
        cantidad,
        categoria,
        estado: 'DISPONIBLE'
      }
    );
  }

  console.log('Materiales preparados.');

  // 6. Citas sin superposición para el profesional
  const datosCitas = [
    ['2027-01-11', '08:00', 'COMPLETADA'],
    ['2027-01-11', '10:00', 'COMPLETADA'],
    ['2027-01-12', '08:00', 'COMPLETADA'],
    ['2027-01-12', '10:00', 'CONFIRMADA'],
    ['2027-01-13', '08:00', 'PENDIENTE']
  ];

  const citas = [];

  for (let i = 0; i < datosCitas.length; i++) {
    const [dia, hora, estado] = datosCitas[i];
    const servicio = servicios[i];
    const inicio = fecha(dia, hora);
    const fin = new Date(
      inicio.getTime() + servicio.duracionMinutos * 60000
    );

    const cita = await obtenerOCrear(
      Cita,
      { observaciones: `${MARCA} Cita ${i + 1}` },
      {
        paciente: pacientes[i]._id,
        servicio: servicio._id,
        profesional: profesional._id,
        fechaInicio: inicio,
        fechaFin: fin,
        duracionMinutos: servicio.duracionMinutos,
        precioCentavos: servicio.precioCentavos,
        estado,
        observaciones: `${MARCA} Cita ${i + 1}`,
        creadoPor: recepcionista._id,
        actualizadoPor: recepcionista._id
      }
    );

    citas.push(cita);
  }

  console.log('Citas preparadas.');

  // 7. Caja de prueba: cerrada para no bloquear
  // la apertura de una caja real del recepcionista.
  const caja = await obtenerOCrear(
    Caja,
    {
      usuario: recepcionista._id,
      fechaApertura: fecha('2027-01-11', '07:30')
    },
    {
      usuario: recepcionista._id,
      fechaApertura: fecha('2027-01-11', '07:30'),
      montoInicialCentavos: 20000,
      estado: 'CERRADA',
      fechaCierre: fecha('2027-01-11', '16:00'),
      montoContadoCentavos: 62500,
      diferenciaCentavos: 0,
      cerradaPor: recepcionista._id
    }
  );

  console.log('Caja de prueba preparada.');

  // 8. Pagos
  for (let i = 0; i < 3; i++) {
    const numeroRecibo = `DEMO-SIGCA-2026-${i + 1}`;

    await obtenerOCrear(
      Pago,
      { numeroRecibo },
      {
        cita: citas[i]._id,
        paciente: pacientes[i]._id,
        caja: caja._id,
        registradoPor: recepcionista._id,
        montoCentavos: citas[i].precioCentavos,
        metodo: ['EFECTIVO', 'TARJETA', 'TRANSFERENCIA'][i],
        numeroRecibo,
        estado: 'REGISTRADO'
      }
    );
  }

  console.log('Pagos preparados.');

  // 9. Solicitudes de cita
  for (let i = 0; i < 3; i++) {
    const correo = `solicitud.demo${i + 1}@sigca.example`;

    await obtenerOCrear(
      SolicitudCita,
      { correo },
      {
        nombre: `Solicitante Demo ${i + 1}`,
        correo,
        telefono: `5550300${i + 1}`,
        servicioId: servicios[i]._id,
        fechaPreferida: fecha('2027-01-18', '09:00'),
        horarioPreferido: 'Mañana',
        motivo: 'Solicitud de demostración SIGCA',
        estado: 'PENDIENTE'
      }
    );
  }

  console.log('Solicitudes de cita preparadas.');
  console.log('\nDatos de demostración SIGCA preparados correctamente.');
}

ejecutar()
  .catch(error => {
    console.error('\nError al preparar datos:', error.message);
    process.exitCode = 1;
  })
  .finally(async () => {
    await mongoose.disconnect();
  });
