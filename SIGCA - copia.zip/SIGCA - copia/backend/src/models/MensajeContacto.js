
const mongoose = require('mongoose');

const mensajeContactoSchema = new mongoose.Schema({
  nombre: {
    type: String,
    required: true,
    trim: true,
    maxlength: 120
  },
  correo: {
    type: String,
    required: true,
    trim: true,
    lowercase: true,
    maxlength: 254
  },
  telefono: {
    type: String,
    trim: true,
    default: '',
    maxlength: 30
  },
  asunto: {
    type: String,
    required: true,
    trim: true,
    maxlength: 150
  },
  mensaje: {
    type: String,
    required: true,
    trim: true,
    maxlength: 3000
  },
  estado: {
    type: String,
    enum: ['PENDIENTE', 'ATENDIDO'],
    default: 'PENDIENTE'
  }
}, {
  timestamps: true,
  collection: 'mensajes_contacto'
});

module.exports = mongoose.model(
  'MensajeContacto',
  mensajeContactoSchema
);