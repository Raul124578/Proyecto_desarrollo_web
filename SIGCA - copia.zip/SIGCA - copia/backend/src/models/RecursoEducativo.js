const mongoose = require('mongoose');
const esquema = new mongoose.Schema({
  titulo: { type: String, required: true, trim: true, maxlength: 150 },
  descripcion: { type: String, required: true, trim: true, maxlength: 2000 },
  tipo: { type: String, required: true, enum: ['GUIA', 'DOCUMENTO', 'VIDEO', 'ENLACE', 'OTRO'] },
  enlaceRecurso: { type: String, required: true, trim: true, maxlength: 2000,
    validate: { validator(v) { try { const u = new URL(v); return ['https:', 'http:'].includes(u.protocol); } catch { return false; } }, message: 'El enlace debe iniciar con http:// o https://' } },
  fechaRegistro: { type: Date, default: Date.now, immutable: true },
  estado: { type: String, enum: ['ACTIVO', 'INACTIVO'], default: 'ACTIVO' }
}, { timestamps: true, collection: 'recursosEducativos' });
module.exports = mongoose.model('RecursoEducativo', esquema);
