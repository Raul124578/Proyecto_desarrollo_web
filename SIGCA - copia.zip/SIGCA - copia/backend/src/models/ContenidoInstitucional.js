
const mongoose = require('mongoose');

const contenidoSchema = new mongoose.Schema({
  clave: {
    type: String,
    default: 'principal',
    unique: true
  },
  institucion: {
    type: String,
    default: "Centro K'aslemal"
  },
  lema: {
    type: String,
    default: ''
  },
  mision: {
    type: String,
    default: ''
  },
  vision: {
    type: String,
    default: ''
  },
  valores: [String],
  actividades: [{
    titulo: { type: String, required: true },
    descripcion: { type: String, default: '' }
  }],
  horarios: [{
    dia: { type: String, required: true },
    horario: { type: String, required: true }
  }],
  contacto: {
    telefono: String,
    correo: String,
    direccion: String,
    horarioAtencion: String
  },
  carrusel: [{
    imagen: { type: String, required: true },
    titulo: String,
    descripcion: String
  }],
  publicado: {
    type: Boolean,
    default: false
  }
}, {
  timestamps: true,
  collection: 'contenido_institucional'
});

module.exports = mongoose.model(
  'ContenidoInstitucional',
  contenidoSchema
);
