const mongoose = require('mongoose');
const esquema = new mongoose.Schema({
  recurso: { type: mongoose.Schema.Types.ObjectId, ref: 'RecursoEducativo', required: true },
  paciente: { type: mongoose.Schema.Types.ObjectId, ref: 'Paciente', required: true },
  asignadoPor: { type: mongoose.Schema.Types.ObjectId, ref: 'Usuario', required: true },
  fechaAsignacion: { type: Date, default: Date.now },
  observaciones: { type: String, trim: true, maxlength: 1000, default: '' }
}, { timestamps: true, collection: 'asignacionesRecursos' });
esquema.index({ recurso: 1, paciente: 1 }, { unique: true });
module.exports = mongoose.model('AsignacionRecurso', esquema);
