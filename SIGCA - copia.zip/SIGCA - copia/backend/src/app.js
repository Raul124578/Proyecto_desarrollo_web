
const express = require('express');
const cors = require('cors');

// Rutas existentes del proyecto SIGCA
const citaRoutes = require('./routes/citaRoutes');
const cajaRoutes = require('./routes/cajaRoutes');
const pagoRoutes = require('./routes/pagoRoutes');
const pacienteRoutes = require('./routes/pacienteRoutes');
const responsableRoutes = require('./routes/responsableRoutes');
const authRoutes = require('./routes/authRoutes');
const usuarioRoutes = require('./routes/usuarioRoutes');
const servicioRoutes = require('./routes/servicioRoutes');
const horarioRoutes = require('./routes/horarioRoutes');
const solicitudCitaRoutes = require('./routes/solicitudCitaRoutes');
const materialRoutes = require('./routes/materialRoutes');
const recursoEducativoRoutes = require('./routes/recursoEducativoRoutes');
const asignacionMaterialRoutes = require('./routes/asignacionMaterialRoutes');

const contenidoRoutes = require('./routes/contenidoRoutes');
const contactoRoutes = require('./routes/contactoRoutes');

const app = express();

// Middlewares
app.use(cors());
app.use(express.json({ limit: '1mb' }));

// Estado del servidor
app.get('/api/status', (req, res) => {
  res.status(200).json({
    estado: 'OK',
    aplicacion: 'SIGCA',
    mensaje: 'API funcionando correctamente'
  });
});

// Rutas existentes
app.use('/api/pacientes', pacienteRoutes);
app.use('/api/responsables', responsableRoutes);
app.use('/api/servicios', servicioRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/usuarios', usuarioRoutes);
app.use('/api/horarios', horarioRoutes);
app.use('/api/citas', citaRoutes);
app.use('/api/cajas', cajaRoutes);
app.use('/api/pagos', pagoRoutes);
app.use('/api/solicitudes-cita', solicitudCitaRoutes);
app.use('/api/materiales', materialRoutes);
app.use('/api/recursos-educativos', recursoEducativoRoutes);
app.use('/api/asignaciones-materiales', asignacionMaterialRoutes);

// Rutas institucionales
app.use('/api/contenido', contenidoRoutes);
app.use('/api/contacto', contactoRoutes);

module.exports = app;
