
<template>
  <main class="contenedor">
    <header class="encabezado">
      <div>
        <h2>Administración de Servicios</h2>
        <p>Gestiona los servicios disponibles en SIGCA.</p>
      </div>
      <button class="primario" @click="nuevoServicio">
        + Registrar Nuevo Servicio
      </button>
    </header>

    <div v-if="mensaje" class="aviso" :class="{ error: tipoError }">
      {{ mensaje }}
      <button @click="mensaje = ''">×</button>
    </div>

    <div class="filtros">
      <input v-model="busqueda" placeholder="Buscar servicio..." />
      <select v-model="filtroEstado">
        <option value="">Todos los estados</option>
        <option value="ACTIVO">Activos</option>
        <option value="INACTIVO">Inactivos</option>
      </select>
      <button @click="cargarServicios">Actualizar</button>
    </div>

    <p v-if="cargando">Cargando servicios...</p>

    <div v-else class="tabla-responsive">
      <table>
        <thead>
          <tr>
            <th>Servicio</th>
            <th>Ícono</th>
            <th>Duración</th>
            <th>Precio</th>
            <th>Estado</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="s in serviciosFiltrados" :key="s._id">
            <td>
              <strong>{{ s.nombre }}</strong>
              <small>{{ s.descripcion }}</small>
            </td>
            <td>{{ nombreIcono(s.icono) }}</td>
            <td>{{ s.duracionMinutos }} min</td>
            <td>Q{{ precioServicio(s).toFixed(2) }}</td>
            <td>{{ s.estado }}</td>
            <td>
              <div class="acciones">
                <button @click="editarServicio(s)">Editar</button>
                <button
                  :disabled="procesando"
                  @click="cambiarEstado(s)"
                >
                  {{ s.estado === 'ACTIVO' ? 'Desactivar' : 'Activar' }}
                </button>
              </div>
            </td>
          </tr>
          <tr v-if="serviciosFiltrados.length === 0">
            <td colspan="6">No se encontraron servicios.</td>
          </tr>
        </tbody>
      </table>
    </div>

    <div v-if="mostrarFormulario" class="fondo-modal">
      <div class="modal">
        <header class="modal-header">
          <h3>{{ editandoId ? 'Editar Servicio' : 'Registrar Servicio' }}</h3>
          <button type="button" @click="cerrarFormulario">×</button>
        </header>

        <form @submit.prevent="guardarServicio">
          <label>Nombre del servicio</label>
          <input v-model.trim="form.nombre" required />

          <label>Descripción</label>
          <textarea v-model.trim="form.descripcion" rows="3" required></textarea>

          <div class="columnas">
            <div>
              <label>Duración (minutos)</label>
              <input
                v-model.number="form.duracionMinutos"
                type="number"
                min="1"
                step="1"
                required
              />
            </div>
            <div>
              <label>Precio (Q)</label>
              <input
                v-model.number="form.precio"
                type="number"
                min="0"
                step="0.01"
                required
              />
            </div>
          </div>

          <label>Selecciona un ícono</label>
          <div class="selector-iconos">
            <label
              v-for="opcion in opcionesIconos"
              :key="opcion.valor"
              class="opcion-icono"
              :class="{ seleccionado: form.icono === opcion.valor }"
            >
              <input
                v-model="form.icono"
                type="radio"
                :value="opcion.valor"
              />
              <svg
                viewBox="0 0 24 24"
                width="38"
                height="38"
                fill="none"
                stroke="currentColor"
                stroke-width="1.6"
                stroke-linecap="round"
                stroke-linejoin="round"
              >
                <template v-if="opcion.valor === 'seguimiento'">
                  <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8Z"/>
                  <path d="M3.5 12h5l2-3 3 6 2-3h5"/>
                </template>
                <template v-else-if="opcion.valor === 'comunicacion'">
                  <path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5 9 9 0 0 1-4-.9L3 21l1.9-5.5a9 9 0 0 1-.9-4A8.5 8.5 0 0 1 12.5 3 8.5 8.5 0 0 1 21 11.5Z"/>
                  <path d="M8 11h8M8 15h5M8 7h6"/>
                </template>
                <template v-else-if="opcion.valor === 'auditiva'">
                  <path d="M6 10a6 6 0 0 1 12 0c0 4-4 4-4 8a3 3 0 0 1-6 0"/>
                  <path d="M10 10a2 2 0 0 1 4 0c0 2-2 2-2 4M3 8v4M21 8v4"/>
                </template>
                <template v-else-if="opcion.valor === 'familia'">
                  <circle cx="9" cy="7" r="3"/>
                  <circle cx="17" cy="8" r="2.5"/>
                  <path d="M3 20v-2a6 6 0 0 1 12 0v2M16 14a5 5 0 0 1 5 5v1"/>
                </template>
                <template v-else-if="opcion.valor === 'ocupacional'">
                  <path d="M8 13V5a1.5 1.5 0 0 1 3 0v6M11 11V4a1.5 1.5 0 0 1 3 0v7M14 11V6a1.5 1.5 0 0 1 3 0v7M17 12a1.5 1.5 0 0 1 3 0v4c0 3-2 5-5 5h-4c-2 0-4-1-5-3l-3-5a1.5 1.5 0 0 1 2.5-1.5L8 14"/>
                </template>
                <template v-else-if="opcion.valor === 'lenguaje'">
                  <rect x="3" y="4" width="18" height="14" rx="3"/>
                  <path d="M8 18l-2 3M9 9h6M12 9v5M9 14h6"/>
                </template>
                <template v-else>
                  <circle cx="12" cy="12" r="9"/>
                  <path d="M12 7v10M7 12h10"/>
                </template>
              </svg>
              <span>{{ opcion.nombre }}</span>
            </label>
          </div>

          <label>URL de imagen (opcional)</label>
          <input
            v-model.trim="form.imagen"
            placeholder="Dejar vacío para mostrar el ícono"
          />

          <template v-if="!editandoId">
            <label>Estado inicial</label>
            <select v-model="form.estado">
              <option value="ACTIVO">ACTIVO</option>
              <option value="INACTIVO">INACTIVO</option>
            </select>
          </template>

          <p v-if="errorFormulario" class="error-texto">
            {{ errorFormulario }}
          </p>

          <footer class="botones">
            <button type="button" @click="cerrarFormulario">Cancelar</button>
            <button class="primario" type="submit" :disabled="procesando">
              {{ procesando ? 'Guardando...' : 'Guardar Servicio' }}
            </button>
          </footer>
        </form>
      </div>
    </div>
  </main>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue';
import api from '../services/api';

const opcionesIconos = [
  { valor: 'seguimiento', nombre: 'Seguimiento' },
  { valor: 'comunicacion', nombre: 'Comunicación' },
  { valor: 'auditiva', nombre: 'Auditiva' },
  { valor: 'familia', nombre: 'Familia' },
  { valor: 'ocupacional', nombre: 'Ocupacional' },
  { valor: 'lenguaje', nombre: 'Lenguaje' },
  { valor: 'general', nombre: 'General' }
];

const servicios = ref([]);
const busqueda = ref('');
const filtroEstado = ref('');
const cargando = ref(false);
const procesando = ref(false);
const mostrarFormulario = ref(false);
const editandoId = ref(null);
const mensaje = ref('');
const tipoError = ref(false);
const errorFormulario = ref('');

const formularioVacio = () => ({
  nombre: '',
  descripcion: '',
  duracionMinutos: 45,
  precio: 0,
  imagen: '',
  icono: 'general',
  estado: 'ACTIVO'
});

const form = ref(formularioVacio());

const serviciosFiltrados = computed(() =>
  servicios.value.filter(s =>
    (s.nombre || '').toLowerCase().includes(busqueda.value.toLowerCase()) &&
    (!filtroEstado.value || s.estado === filtroEstado.value)
  )
);

const nombreIcono = (valor) =>
  opcionesIconos.find(o => o.valor === valor)?.nombre || 'Automático';

const precioServicio = (s) =>
  s.precio != null
    ? Number(s.precio)
    : Number(s.precioCentavos || 0) / 100;

const mostrarMensaje = (texto, error = false) => {
  mensaje.value = texto;
  tipoError.value = error;
};

const obtenerError = (err) => {
  const datos = err.response?.data;
  return datos?.errores?.join(', ') ||
    datos?.mensaje ||
    'No se pudo completar la operación.';
};

const cargarServicios = async () => {
  cargando.value = true;
  try {
    const respuesta = await api.get('/servicios');
    servicios.value = respuesta.data;
  } catch (err) {
    mostrarMensaje(obtenerError(err), true);
  } finally {
    cargando.value = false;
  }
};

const nuevoServicio = () => {
  editandoId.value = null;
  form.value = formularioVacio();
  errorFormulario.value = '';
  mostrarFormulario.value = true;
};

const editarServicio = (s) => {
  editandoId.value = s._id;
  form.value = {
    nombre: s.nombre,
    descripcion: s.descripcion,
    duracionMinutos: s.duracionMinutos,
    precio: precioServicio(s),
    imagen: s.imagen || '',
    icono: s.icono || 'general',
    estado: s.estado
  };
  errorFormulario.value = '';
  mostrarFormulario.value = true;
};

const cerrarFormulario = () => {
  if (procesando.value) return;
  mostrarFormulario.value = false;
};

const guardarServicio = async () => {
  errorFormulario.value = '';

  if (!Number.isInteger(form.value.duracionMinutos) ||
      form.value.duracionMinutos < 1) {
    errorFormulario.value = 'La duración debe ser un entero mayor a cero.';
    return;
  }

  if (!Number.isFinite(form.value.precio) || form.value.precio < 0) {
    errorFormulario.value = 'El precio debe ser válido.';
    return;
  }

  procesando.value = true;
  try {
    const datos = {
      nombre: form.value.nombre,
      descripcion: form.value.descripcion,
      duracionMinutos: form.value.duracionMinutos,
      precio: form.value.precio,
      imagen: form.value.imagen,
      icono: form.value.icono
    };

    if (editandoId.value) {
      await api.put(`/servicios/${editandoId.value}`, datos);
      mostrarMensaje('Servicio actualizado correctamente.');
    } else {
      await api.post('/servicios', {
        ...datos,
        estado: form.value.estado
      });
      mostrarMensaje('Servicio registrado correctamente.');
    }

    mostrarFormulario.value = false;
    await cargarServicios();
  } catch (err) {
    errorFormulario.value = obtenerError(err);
  } finally {
    procesando.value = false;
  }
};

const cambiarEstado = async (s) => {
  const estado = s.estado === 'ACTIVO' ? 'INACTIVO' : 'ACTIVO';

  if (!window.confirm(`¿Cambiar el servicio a ${estado}?`)) return;

  procesando.value = true;
  try {
    await api.patch(`/servicios/${s._id}/estado`, { estado });
    mostrarMensaje(`Servicio cambiado a ${estado}.`);
    await cargarServicios();
  } catch (err) {
    mostrarMensaje(obtenerError(err), true);
  } finally {
    procesando.value = false;
  }
};

onMounted(cargarServicios);
</script>

<style scoped>
.contenedor { max-width: 1150px; margin: 25px auto; padding: 20px; }
.encabezado { display: flex; justify-content: space-between; align-items: center; gap: 15px; flex-wrap: wrap; margin-bottom: 25px; }
h2 { color: #1e3a5f; margin: 0 0 8px; }
.encabezado p { color: #64748b; margin: 0; }
button { border: 1px solid #cbd5e1; background: white; padding: 9px 13px; border-radius: 6px; cursor: pointer; }
button:disabled { opacity: .6; cursor: not-allowed; }
.primario { background: #007bff; color: white; border: none; }
.filtros { display: flex; gap: 12px; margin-bottom: 18px; flex-wrap: wrap; }
input, select, textarea { padding: 10px; border: 1px solid #cbd5e1; border-radius: 6px; font: inherit; box-sizing: border-box; }
.filtros input { flex: 1; min-width: 200px; }
.tabla-responsive { overflow-x: auto; background: white; border-radius: 10px; }
table { width: 100%; border-collapse: collapse; }
th, td { padding: 13px; text-align: left; border-bottom: 1px solid #e2e8f0; }
th { background: #f1f5f9; }
td small { display: block; color: #64748b; margin-top: 5px; }
.acciones { display: flex; gap: 8px; }
.aviso { background: #dcfce7; color: #166534; padding: 12px; border-radius: 6px; margin-bottom: 15px; display: flex; justify-content: space-between; }
.aviso.error { background: #fee2e2; color: #991b1b; }
.fondo-modal { position: fixed; inset: 0; z-index: 3000; background: rgba(0,0,0,.5); display: flex; align-items: center; justify-content: center; padding: 15px; }
.modal { width: 100%; max-width: 620px; max-height: 90vh; overflow-y: auto; background: white; border-radius: 12px; padding: 24px; }
.modal-header { display: flex; justify-content: space-between; align-items: center; }
.modal form { display: flex; flex-direction: column; gap: 10px; }
.modal form > label, .columnas label { font-weight: 600; }
.modal form > input, .modal form > textarea, .modal form > select { width: 100%; }
.columnas { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.columnas > div { display: flex; flex-direction: column; gap: 8px; }
.selector-iconos { display: grid; grid-template-columns: repeat(auto-fit, minmax(105px, 1fr)); gap: 10px; margin: 8px 0 16px; }
.opcion-icono { display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 8px; padding: 12px 8px; border: 2px solid #e2e8f0; border-radius: 10px; cursor: pointer; color: #475569; text-align: center; font-size: 12px; }
.opcion-icono input { width: auto; margin: 0; }
.opcion-icono.seleccionado { border-color: #2563eb; background: #eff6ff; color: #1d4ed8; }
.botones { display: flex; justify-content: flex-end; gap: 10px; margin-top: 12px; }
.error-texto { color: #b91c1c; }
@media (max-width: 600px) { .columnas { grid-template-columns: 1fr; } .acciones { flex-direction: column; } }
</style>
