
<template>
  <div class="servicios-container">
    <h2>Nuestros Servicios</h2>
    <p class="subtitulo">
      Servicios especializados en psicología y estimulación auditiva verbal
    </p>

    <div v-if="cargando" class="mensaje-estado">
      Cargando servicios disponibles...
    </div>

    <div v-else-if="error" class="mensaje-error">
      {{ error }}
    </div>

    <div v-else-if="servicios.length === 0" class="mensaje-estado">
      No hay servicios activos registrados en este momento.
    </div>

    <div v-else class="servicios-grid">
      <div
        v-for="servicio in servicios"
        :key="servicio._id"
        class="servicio-card"
      >
        <div
          class="servicio-img-box"
          :class="'fondo-' + tipoServicio(servicio)"
        >
          <img
            v-if="servicio.imagen"
            :src="servicio.imagen"
            :alt="servicio.nombre"
          />

          <div v-else class="icono-servicio">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="76"
              height="76"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="1.5"
              stroke-linecap="round"
              stroke-linejoin="round"
              aria-hidden="true"
            >
              <template v-if="tipoServicio(servicio) === 'seguimiento'">
                <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8Z"/>
                <path d="M3.5 12h5l2-3 3 6 2-3h5"/>
              </template>

              <template v-else-if="tipoServicio(servicio) === 'comunicacion'">
                <path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5 9 9 0 0 1-4-.9L3 21l1.9-5.5a9 9 0 0 1-.9-4A8.5 8.5 0 0 1 12.5 3 8.5 8.5 0 0 1 21 11.5Z"/>
                <path d="M8 11h8M8 15h5M8 7h6"/>
              </template>

              <template v-else-if="tipoServicio(servicio) === 'auditiva'">
                <path d="M6 10a6 6 0 0 1 12 0c0 4-4 4-4 8a3 3 0 0 1-6 0"/>
                <path d="M10 10a2 2 0 0 1 4 0c0 2-2 2-2 4M3 8v4M21 8v4"/>
              </template>

              <template v-else-if="tipoServicio(servicio) === 'familia'">
                <circle cx="9" cy="7" r="3"/>
                <circle cx="17" cy="8" r="2.5"/>
                <path d="M3 20v-2a6 6 0 0 1 12 0v2M16 14a5 5 0 0 1 5 5v1"/>
              </template>

              <template v-else-if="tipoServicio(servicio) === 'ocupacional'">
                <path d="M8 13V5a1.5 1.5 0 0 1 3 0v6M11 11V4a1.5 1.5 0 0 1 3 0v7M14 11V6a1.5 1.5 0 0 1 3 0v7M17 12a1.5 1.5 0 0 1 3 0v4c0 3-2 5-5 5h-4c-2 0-4-1-5-3l-3-5a1.5 1.5 0 0 1 2.5-1.5L8 14"/>
              </template>

              <template v-else-if="tipoServicio(servicio) === 'lenguaje'">
                <rect x="3" y="4" width="18" height="14" rx="3"/>
                <path d="M8 18l-2 3M9 9h6M12 9v5M9 14h6"/>
              </template>

              <template v-else>
                <circle cx="12" cy="12" r="9"/>
                <path d="M12 7v10M7 12h10"/>
              </template>
            </svg>
          </div>
        </div>

        <div class="servicio-info">
          <h3>{{ servicio.nombre }}</h3>
          <p class="descripcion">{{ servicio.descripcion }}</p>

          <div class="detalles">
            <span>
              <strong>Duración:</strong>
              {{ servicio.duracionMinutos }} min
            </span>
            <span class="precio">
              <strong>Precio:</strong>
              Q{{ obtenerPrecio(servicio) }}
            </span>
          </div>

          <router-link
            :to="`/solicitar-cita?servicioId=${servicio._id}`"
            class="btn-solicitar"
          >
            Solicitar Cita
          </router-link>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import api from '../services/api';

const servicios = ref([]);
const cargando = ref(true);
const error = ref(null);

const obtenerTipoServicio = (nombre) => {
  if (!nombre) return 'general';

  const texto = nombre
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');

  if (texto.includes('seguimiento')) return 'seguimiento';
  if (texto.includes('comunicacion')) return 'comunicacion';
  if (texto.includes('auditiva') || texto.includes('audicion')) return 'auditiva';
  if (texto.includes('familiar') || texto.includes('familia')) return 'familia';
  if (texto.includes('ocupacional')) return 'ocupacional';
  if (texto.includes('lenguaje')) return 'lenguaje';

  return 'general';
};

// Si el administrador eligió un ícono, usarlo.
// Si no existe, conservar la detección automática anterior.
const tipoServicio = (servicio) => {
  return servicio.icono || obtenerTipoServicio(servicio.nombre);
};

const obtenerPrecio = (servicio) => {
  if (servicio.precio !== undefined && servicio.precio !== null) {
    return Number(servicio.precio).toFixed(2);
  }

  return (Number(servicio.precioCentavos || 0) / 100).toFixed(2);
};

const cargarServicios = async () => {
  try {
    cargando.value = true;
    error.value = null;

    const respuesta = await api.get('/servicios?estado=ACTIVO');
    servicios.value = respuesta.data;
  } catch (err) {
    error.value = 'No se pudieron cargar los servicios.';
    console.error('Error al cargar servicios:', err);
  } finally {
    cargando.value = false;
  }
};

onMounted(cargarServicios);
</script>

<style scoped>
.servicios-container {
  max-width: 1100px;
  margin: 0 auto;
  padding: 30px 20px;
}
h2 {
  text-align: center;
  color: #1a365d;
  font-size: 1.8rem;
  margin-bottom: 10px;
}
.subtitulo {
  text-align: center;
  color: #64748b;
  margin-bottom: 35px;
}
.mensaje-estado, .mensaje-error {
  text-align: center;
  padding: 20px;
  background: white;
  border: 1px solid #ddd;
  border-radius: 6px;
}
.mensaje-error {
  color: #721c24;
  background: #f8d7da;
}
.servicios-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 22px;
}
.servicio-card {
  background: white;
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  transition: transform .2s, box-shadow .2s;
}
.servicio-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 8px 20px rgba(0,0,0,.08);
}
.servicio-img-box {
  height: 160px;
  display: flex;
  align-items: center;
  justify-content: center;
}
.servicio-img-box img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.icono-servicio {
  display: flex;
  align-items: center;
  justify-content: center;
}
.icono-servicio svg {
  width: 76px;
  height: 76px;
}
.fondo-seguimiento { background: #e8f4fd; color: #2563eb; }
.fondo-comunicacion { background: #f0eafe; color: #7c3aed; }
.fondo-auditiva { background: #e5f7f2; color: #059669; }
.fondo-familia { background: #fff2e6; color: #ea580c; }
.fondo-ocupacional { background: #e8f4fd; color: #2563eb; }
.fondo-lenguaje { background: #fcebf3; color: #db2777; }
.fondo-general { background: #f1f5f9; color: #64748b; }
.servicio-info {
  padding: 18px;
  display: flex;
  flex-direction: column;
  flex: 1;
}
.servicio-info h3 {
  font-size: 1.1rem;
  margin: 0 0 10px;
  color: #1e293b;
}
.descripcion {
  color: #64748b;
  font-size: .9rem;
  line-height: 1.5;
  margin-bottom: 18px;
  flex: 1;
}
.detalles {
  display: flex;
  justify-content: space-between;
  gap: 10px;
  flex-wrap: wrap;
  font-size: .85rem;
  margin-bottom: 15px;
  padding-top: 12px;
  border-top: 1px solid #e2e8f0;
}
.precio { color: #16a34a; font-weight: bold; }
.btn-solicitar {
  display: block;
  text-align: center;
  background: #007bff;
  color: white;
  padding: 11px;
  border-radius: 6px;
  text-decoration: none;
  font-weight: 600;
}
.btn-solicitar:hover { background: #0056b3; }
@media (max-width: 600px) {
  .servicios-container { padding: 20px 15px; }
  .servicios-grid { grid-template-columns: 1fr; }
  .servicio-img-box { height: 140px; }
  .icono-servicio svg { width: 65px; height: 65px; }
}
</style>
