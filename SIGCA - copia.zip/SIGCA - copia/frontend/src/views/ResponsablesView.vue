
<template>
  <main class="contenedor">
    <header class="encabezado">
      <div>
        <h2>Gestión de Responsables</h2>
        <p>Registro de tutores y asociación de pacientes</p>
      </div>
      <button class="primario" @click="nuevo">
        + Registrar responsable
      </button>
    </header>

    <div v-if="mensaje" :class="['alerta', tipoMensaje]">
      <span>{{ mensaje }}</span>
      <button @click="mensaje = ''">×</button>
    </div>

    <p v-if="cargando">Cargando responsables...</p>

    <div v-else class="tabla">
      <table>
        <thead>
          <tr>
            <th>Responsable</th>
            <th>Parentesco</th>
            <th>Teléfono</th>
            <th>Correo</th>
            <th>Pacientes asociados</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="r in responsables" :key="r._id">
            <td>
              <div class="persona">
                <img
                  v-if="r.fotografia"
                  :src="r.fotografia"
                  alt="Fotografía del responsable"
                  class="mini-foto"
                />
                <div v-else class="mini-foto sin-foto">👤</div>
                <strong>{{ r.nombres }} {{ r.apellidos }}</strong>
              </div>
            </td>
            <td>{{ r.parentesco }}</td>
            <td>{{ r.telefono }}</td>
            <td>{{ r.correo }}</td>
            <td>
              <div class="etiquetas">
                <span
                  v-for="p in r.pacientes || []"
                  :key="p._id || p"
                  class="etiqueta"
                >
                  {{ p.nombres }} {{ p.apellidos }}
                </span>
                <span v-if="!r.pacientes?.length">
                  Sin pacientes asociados
                </span>
              </div>
            </td>
            <td>
              <div class="acciones">
                <button @click="editar(r)">Editar</button>
                <button class="primario" @click="asociar(r)">
                  Asociar paciente
                </button>
              </div>
            </td>
          </tr>
          <tr v-if="responsables.length === 0">
            <td colspan="6" class="vacio">
              No hay responsables registrados.
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- REGISTRO Y EDICIÓN -->
    <div v-if="modal" class="fondo" @click.self="cerrar">
      <section class="ventana">
        <header class="encabezado">
          <h3>
            {{ editandoId ? 'Editar responsable' : 'Registrar responsable' }}
          </h3>
          <button type="button" @click="cerrar">×</button>
        </header>

        <form @submit.prevent="guardar">
          <div class="campos">
            <label>
              Nombres *
              <input v-model.trim="form.nombres" required />
            </label>
            <label>
              Apellidos *
              <input v-model.trim="form.apellidos" required />
            </label>
            <label>
              Parentesco *
              <input
                v-model.trim="form.parentesco"
                placeholder="Madre, padre o tutor"
                required
              />
            </label>
            <label>
              Teléfono *
              <input
                v-model.trim="form.telefono"
                maxlength="8"
                required
              />
            </label>
            <label class="ancho">
              Correo electrónico *
              <input v-model.trim="form.correo" type="email" required />
            </label>
            <label class="ancho">
              Dirección *
              <input v-model.trim="form.direccion" required />
            </label>

            <div class="ancho">
              <SelectorFotografia
                v-model="form.fotografia"
                :disabled="guardando"
              />
            </div>
          </div>

          <div class="botones">
            <button type="button" @click="cerrar">Cancelar</button>
            <button type="submit" class="primario" :disabled="guardando">
              {{ guardando ? 'Guardando...' : 'Guardar responsable' }}
            </button>
          </div>
        </form>
      </section>
    </div>

    <!-- ASOCIACIÓN DE PACIENTES -->
    <div v-if="modalAsociar" class="fondo" @click.self="cerrarAsociar">
      <section class="ventana">
        <header class="encabezado">
          <h3>Asociar paciente</h3>
          <button type="button" @click="cerrarAsociar">×</button>
        </header>

        <p>
          Responsable:
          <strong>
            {{ seleccionado?.nombres }} {{ seleccionado?.apellidos }}
          </strong>
        </p>

        <form @submit.prevent="guardarAsociacion">
          <label class="campo">
            Paciente activo *
            <select v-model="pacienteId" required>
              <option value="">Seleccionar paciente</option>
              <option
                v-for="p in pacientesNoAsociados"
                :key="p._id"
                :value="p._id"
              >
                {{ p.nombres }} {{ p.apellidos }}
              </option>
            </select>
          </label>

          <p v-if="pacientesNoAsociados.length === 0">
            No hay pacientes activos pendientes de asociar.
          </p>

          <div class="botones">
            <button type="button" @click="cerrarAsociar">
              Cancelar
            </button>
            <button
              type="submit"
              class="primario"
              :disabled="guardando || !pacienteId"
            >
              {{ guardando ? 'Asociando...' : 'Confirmar asociación' }}
            </button>
          </div>
        </form>
      </section>
    </div>
  </main>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue';
import api from '../services/api';
import SelectorFotografia from '../components/SelectorFotografia.vue';

const responsables = ref([]);
const pacientes = ref([]);
const cargando = ref(false);
const guardando = ref(false);

const modal = ref(false);
const modalAsociar = ref(false);
const editandoId = ref(null);
const seleccionado = ref(null);
const pacienteId = ref('');

const mensaje = ref('');
const tipoMensaje = ref('exito');

const vacio = () => ({
  nombres: '',
  apellidos: '',
  parentesco: '',
  telefono: '',
  correo: '',
  direccion: '',
  fotografia: ''
});

const form = ref(vacio());

const avisar = (texto, tipo = 'exito') => {
  mensaje.value = texto;
  tipoMensaje.value = tipo;
};

const errorTexto = (error) => {
  const codigo = error.response?.status;

  if (codigo === 401) return 'Sesión inválida. Inicia sesión nuevamente.';
  if (codigo === 403) return 'No tienes permisos para esta operación.';
  if (!error.response) return 'No se pudo conectar con el servidor.';

  const datos = error.response.data;
  return Array.isArray(datos?.errores)
    ? datos.errores.join(', ')
    : datos?.mensaje || 'Ocurrió un error inesperado.';
};

const cargar = async () => {
  cargando.value = true;
  try {
    const res = await api.get('/responsables');
    responsables.value = Array.isArray(res.data) ? res.data : [];
  } catch (error) {
    avisar(errorTexto(error), 'error');
  } finally {
    cargando.value = false;
  }
};

const cargarPacientes = async () => {
  try {
    const res = await api.get('/pacientes', {
      params: { estado: 'ACTIVO' }
    });
    pacientes.value = Array.isArray(res.data) ? res.data : [];
  } catch (error) {
    avisar(errorTexto(error), 'error');
  }
};

const nuevo = () => {
  form.value = vacio();
  editandoId.value = null;
  modal.value = true;
};

const editar = (r) => {
  editandoId.value = r._id;
  form.value = {
    nombres: r.nombres || '',
    apellidos: r.apellidos || '',
    parentesco: r.parentesco || '',
    telefono: r.telefono || '',
    correo: r.correo || '',
    direccion: r.direccion || '',
    fotografia: r.fotografia || ''
  };
  modal.value = true;
};

const cerrar = () => {
  if (!guardando.value) modal.value = false;
};

const guardar = async () => {
  if (!/^\d{8}$/.test(form.value.telefono)) {
    avisar('El teléfono debe tener exactamente 8 dígitos.', 'error');
    return;
  }

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.value.correo)) {
    avisar('Ingresa un correo electrónico válido.', 'error');
    return;
  }

  guardando.value = true;

  try {
    if (editandoId.value) {
      await api.put(`/responsables/${editandoId.value}`, form.value);
    } else {
      await api.post('/responsables', form.value);
    }

    modal.value = false;
    avisar('Responsable guardado correctamente.');
    await cargar();
  } catch (error) {
    avisar(errorTexto(error), 'error');
  } finally {
    guardando.value = false;
  }
};

const pacientesNoAsociados = computed(() => {
  const asociados = new Set(
    (seleccionado.value?.pacientes || []).map(
      p => String(p._id || p)
    )
  );

  return pacientes.value.filter(
    p => !asociados.has(String(p._id))
  );
});

const asociar = async (r) => {
  seleccionado.value = r;
  pacienteId.value = '';
  modalAsociar.value = true;
  await cargarPacientes();
};

const cerrarAsociar = () => {
  if (!guardando.value) {
    modalAsociar.value = false;
    seleccionado.value = null;
  }
};

const guardarAsociacion = async () => {
  if (!seleccionado.value || !pacienteId.value) {
    avisar('Selecciona un paciente.', 'error');
    return;
  }

  guardando.value = true;

  try {
    await api.post(
      `/responsables/${seleccionado.value._id}/pacientes`,
      { pacientes: [pacienteId.value] }
    );

    modalAsociar.value = false;
    seleccionado.value = null;
    pacienteId.value = '';

    avisar('Paciente asociado correctamente.');
    await cargar();
  } catch (error) {
    avisar(errorTexto(error), 'error');
  } finally {
    guardando.value = false;
  }
};

onMounted(cargar);
</script>

<style scoped>
.contenedor { max-width: 1200px; margin: auto; padding: 25px 20px; }
.encabezado {
  display: flex; justify-content: space-between;
  align-items: center; gap: 15px; margin-bottom: 20px;
}
h2, h3 { color: #1e3a5f; margin: 0; }
p { color: #64748b; }
button {
  padding: 9px 12px; border: 1px solid #cbd5e1;
  border-radius: 6px; background: white; cursor: pointer;
}
button:disabled { opacity: .6; cursor: not-allowed; }
.primario { background: #1769c2; border-color: #1769c2; color: white; }
.tabla { overflow-x: auto; border: 1px solid #e2e8f0; border-radius: 8px; }
table { width: 100%; border-collapse: collapse; }
th, td {
  padding: 13px; border-bottom: 1px solid #e2e8f0;
  text-align: left; font-size: 13px;
}
th { background: #f8fafc; color: #475569; }
.persona { display: flex; align-items: center; gap: 10px; }
.mini-foto {
  width: 45px; height: 45px; border-radius: 50%;
  object-fit: cover; flex-shrink: 0;
}
.sin-foto { display: grid; place-items: center; background: #f1f5f9; }
.acciones { display: flex; flex-wrap: wrap; gap: 6px; }
.etiquetas { display: flex; flex-wrap: wrap; gap: 5px; }
.etiqueta {
  padding: 5px 8px; border-radius: 20px;
  background: #dbeafe; color: #1d4ed8; font-size: 11px;
}
.vacio { text-align: center; color: #64748b; }
.alerta {
  display: flex; justify-content: space-between;
  padding: 12px; margin-bottom: 15px; border-radius: 6px;
}
.exito { background: #dcfce7; color: #166534; }
.error { background: #fee2e2; color: #991b1b; }
.fondo {
  position: fixed; inset: 0; background: #0008;
  display: flex; align-items: center; justify-content: center;
  padding: 15px; z-index: 1000;
}
.ventana {
  background: white; width: 100%; max-width: 650px;
  max-height: 90vh; overflow-y: auto;
  padding: 24px; border-radius: 12px;
}
.campos { display: grid; grid-template-columns: repeat(2, 1fr); gap: 14px; }
.campos label, .campo {
  display: flex; flex-direction: column; gap: 6px;
}
.ancho { grid-column: 1 / -1; }
input, select {
  width: 100%; box-sizing: border-box; padding: 10px;
  border: 1px solid #cbd5e1; border-radius: 6px; font: inherit;
}
.botones { display: flex; justify-content: flex-end; gap: 10px; margin-top: 20px; }
@media (max-width: 650px) {
  .campos { grid-template-columns: 1fr; }
  .ancho { grid-column: auto; }
}
</style>