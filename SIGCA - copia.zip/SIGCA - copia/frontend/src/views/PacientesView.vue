
<template>
  <main class="contenedor">
    <header class="encabezado">
      <div>
        <h2>Gestión de Pacientes</h2>
        <p>Registro, consulta y actualización de expedientes</p>
      </div>
      <button v-if="puedeEditar" class="primario" @click="nuevo">
        + Registrar paciente
      </button>
    </header>

    <div v-if="mensaje" :class="['alerta', tipoMensaje]">
      <span>{{ mensaje }}</span>
      <button type="button" @click="mensaje = ''">×</button>
    </div>

    <div class="filtros">
      <input
        v-model="busqueda"
        placeholder="Buscar paciente por nombre o teléfono"
        @keyup.enter="cargar"
      />
      <select v-model="filtroEstado" @change="cargar">
        <option value="">Todos los estados</option>
        <option value="ACTIVO">Activos</option>
        <option value="INACTIVO">Inactivos</option>
      </select>
      <button @click="cargar">Buscar</button>
    </div>

    <p v-if="cargando">Cargando pacientes...</p>

    <div v-else class="tabla">
      <table>
        <thead>
          <tr>
            <th>Paciente</th>
            <th>Edad</th>
            <th>Teléfono</th>
            <th>Estado</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="p in pacientes" :key="p._id">
            <td>
              <div class="persona">
                <img
                  v-if="p.fotografia"
                  :src="p.fotografia"
                  alt="Fotografía del paciente"
                  class="mini-foto"
                />
                <div v-else class="mini-foto sin-foto">👤</div>
                <div>
                  <strong>{{ p.nombres }} {{ p.apellidos }}</strong>
                  <small>{{ p.direccion }}</small>
                </div>
              </div>
            </td>
            <td>{{ p.edad ?? calcularEdad(p.fechaNacimiento) }}</td>
            <td>{{ p.telefono }}</td>
            <td>
              <span :class="['estado', p.estado === 'ACTIVO' ? 'activo' : 'inactivo']">
                {{ p.estado }}
              </span>
            </td>
            <td>
              <div class="acciones">
                <button @click="abrir(p, true)">Ver</button>
                <button v-if="puedeEditar" @click="abrir(p, false)">
                  Editar
                </button>
                <button v-if="puedeEditar" @click="cambiarEstado(p)">
                  {{ p.estado === 'ACTIVO' ? 'Desactivar' : 'Activar' }}
                </button>
              </div>
            </td>
          </tr>
          <tr v-if="pacientes.length === 0">
            <td colspan="5" class="vacio">No hay pacientes registrados.</td>
          </tr>
        </tbody>
      </table>
    </div>

    <div v-if="modal" class="fondo" @click.self="cerrar">
      <section class="ventana">
        <header class="encabezado">
          <h3>
            {{ soloLectura ? 'Detalle del paciente' :
               editandoId ? 'Editar paciente' : 'Registrar paciente' }}
          </h3>
          <button type="button" @click="cerrar">×</button>
        </header>

        <form @submit.prevent="guardar">
          <div class="campos">
            <label>
              Nombres *
              <input v-model.trim="form.nombres" required :disabled="soloLectura" />
            </label>
            <label>
              Apellidos *
              <input v-model.trim="form.apellidos" required :disabled="soloLectura" />
            </label>
            <label>
              Fecha de nacimiento *
              <input
                v-model="form.fechaNacimiento"
                type="date"
                :max="hoy"
                required
                :disabled="soloLectura"
              />
            </label>
            <label>
              Sexo *
              <select v-model="form.sexo" required :disabled="soloLectura">
                <option value="MASCULINO">Masculino</option>
                <option value="FEMENINO">Femenino</option>
                <option value="OTRO">Otro</option>
              </select>
            </label>
            <label>
              Teléfono *
              <input
                v-model.trim="form.telefono"
                maxlength="8"
                required
                :disabled="soloLectura"
              />
            </label>
            <label>
              Inicio del proceso *
              <input
                v-model="form.fechaInicioProceso"
                type="date"
                required
                :disabled="soloLectura"
              />
            </label>
            <label class="ancho">
              Dirección *
              <input v-model.trim="form.direccion" required :disabled="soloLectura" />
            </label>

            <div class="ancho">
              <SelectorFotografia
                v-model="form.fotografia"
                :disabled="soloLectura || guardando"
              />
            </div>

            <label class="ancho">
              Observaciones administrativas
              <textarea
                v-model.trim="form.observaciones"
                rows="3"
                :disabled="soloLectura"
              ></textarea>
            </label>
          </div>

          <div v-if="soloLectura" class="detalle">
            <strong>Responsables asociados:</strong>
            <p v-if="!seleccionado?.responsables?.length">
              Sin responsables asociados.
            </p>
            <p
              v-for="r in seleccionado?.responsables || []"
              :key="r._id || r"
            >
              {{ r.nombres }} {{ r.apellidos }}
            </p>
          </div>

          <div class="botones">
            <button type="button" @click="cerrar">Cerrar</button>
            <button
              v-if="!soloLectura"
              type="submit"
              class="primario"
              :disabled="guardando"
            >
              {{ guardando ? 'Guardando...' : 'Guardar paciente' }}
            </button>
          </div>
        </form>
      </section>
    </div>
  </main>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue';
import api from '../services/api';
import { useAuthStore } from '../stores/sesion';
import SelectorFotografia from '../components/SelectorFotografia.vue';

const auth = useAuthStore();
const puedeEditar = computed(() =>
  ['ADMINISTRADOR', 'RECEPCIONISTA'].includes(auth.usuario?.rol)
);

const pacientes = ref([]);
const cargando = ref(false);
const guardando = ref(false);
const busqueda = ref('');
const filtroEstado = ref('');
const mensaje = ref('');
const tipoMensaje = ref('exito');
const modal = ref(false);
const soloLectura = ref(false);
const editandoId = ref(null);
const seleccionado = ref(null);

const fechaLocal = (valor = new Date()) => {
  if (!valor) return '';
  const d = new Date(valor);
  if (Number.isNaN(d.getTime())) return '';
  if (typeof valor === 'string' && /^\d{4}-\d{2}-\d{2}/.test(valor)) {
    return valor.slice(0, 10);
  }
  return [
    d.getFullYear(),
    String(d.getMonth() + 1).padStart(2, '0'),
    String(d.getDate()).padStart(2, '0')
  ].join('-');
};

const hoy = fechaLocal();

const vacio = () => ({
  nombres: '',
  apellidos: '',
  fechaNacimiento: '',
  sexo: 'MASCULINO',
  telefono: '',
  direccion: '',
  fechaInicioProceso: hoy,
  fotografia: '',
  observaciones: ''
});

const form = ref(vacio());

const avisar = (texto, tipo = 'exito') => {
  mensaje.value = texto;
  tipoMensaje.value = tipo;
};

const errorTexto = (error) => {
  const codigo = error.response?.status;
  if (codigo === 401) return 'Sesión inválida. Inicia sesión nuevamente.';
  if (codigo === 403) return 'No tienes permisos para esta operación.';
  if (!error.response) return 'No se pudo conectar con el servidor.';
  const datos = error.response.data;
  return Array.isArray(datos?.errores)
    ? datos.errores.join(', ')
    : datos?.mensaje || 'Ocurrió un error inesperado.';
};

const calcularEdad = (fecha) => {
  if (!fecha) return '—';
  const nacimiento = new Date(fecha);
  if (Number.isNaN(nacimiento.getTime())) return '—';
  const actual = new Date();
  let edad = actual.getFullYear() - nacimiento.getUTCFullYear();
  const mes = actual.getMonth() - nacimiento.getUTCMonth();
  if (
    mes < 0 ||
    (mes === 0 && actual.getDate() < nacimiento.getUTCDate())
  ) edad--;
  return edad;
};

const cargar = async () => {
  cargando.value = true;
  try {
    const res = await api.get('/pacientes', {
      params: {
        ...(busqueda.value.trim() ? { buscar: busqueda.value.trim() } : {}),
        ...(filtroEstado.value ? { estado: filtroEstado.value } : {})
      }
    });
    pacientes.value = Array.isArray(res.data) ? res.data : [];
  } catch (error) {
    avisar(errorTexto(error), 'error');
  } finally {
    cargando.value = false;
  }
};

const nuevo = () => {
  form.value = vacio();
  editandoId.value = null;
  seleccionado.value = null;
  soloLectura.value = false;
  modal.value = true;
};

const abrir = (p, lectura) => {
  seleccionado.value = p;
  editandoId.value = p._id;
  soloLectura.value = lectura;
  form.value = {
    nombres: p.nombres || '',
    apellidos: p.apellidos || '',
    fechaNacimiento: fechaLocal(p.fechaNacimiento),
    sexo: p.sexo || 'MASCULINO',
    telefono: p.telefono || '',
    direccion: p.direccion || '',
    fechaInicioProceso: fechaLocal(p.fechaInicioProceso),
    fotografia: p.fotografia || '',
    observaciones: p.observaciones || ''
  };
  modal.value = true;
};

const cerrar = () => {
  if (!guardando.value) modal.value = false;
};

const guardar = async () => {
  if (!puedeEditar.value) {
    avisar('No tienes permisos para modificar pacientes.', 'error');
    return;
  }

  if (!/^\d{8}$/.test(form.value.telefono)) {
    avisar('El teléfono debe tener 8 dígitos.', 'error');
    return;
  }

  if (form.value.fechaNacimiento > hoy) {
    avisar('La fecha de nacimiento no puede ser futura.', 'error');
    return;
  }

  guardando.value = true;
  try {
    if (editandoId.value) {
      await api.put(`/pacientes/${editandoId.value}`, form.value);
    } else {
      await api.post('/pacientes', form.value);
    }

    modal.value = false;
    avisar('Paciente guardado correctamente.');
    await cargar();
  } catch (error) {
    avisar(errorTexto(error), 'error');
  } finally {
    guardando.value = false;
  }
};

const cambiarEstado = async (p) => {
  const estado = p.estado === 'ACTIVO' ? 'INACTIVO' : 'ACTIVO';
  if (!window.confirm(`¿Cambiar el estado a ${estado}?`)) return;

  try {
    await api.patch(`/pacientes/${p._id}/estado`, { estado });
    avisar(`Paciente actualizado a ${estado}.`);
    await cargar();
  } catch (error) {
    avisar(errorTexto(error), 'error');
  }
};

onMounted(cargar);
</script>

<style scoped>
.contenedor { max-width: 1200px; margin: auto; padding: 25px 20px; }
.encabezado {
  display: flex; justify-content: space-between;
  align-items: center; gap: 15px; margin-bottom: 20px;
}
h2, h3 { color: #1e3a5f; margin: 0; }
p { color: #64748b; }
button {
  padding: 9px 12px; border: 1px solid #cbd5e1;
  border-radius: 6px; background: white; cursor: pointer;
}
button:disabled { opacity: .6; cursor: not-allowed; }
.primario { background: #1769c2; border-color: #1769c2; color: white; }
.filtros { display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 20px; }
.filtros input { flex: 1; min-width: 200px; }
input, select, textarea {
  width: 100%; box-sizing: border-box; padding: 10px;
  border: 1px solid #cbd5e1; border-radius: 6px; font: inherit;
}
.filtros select { width: auto; }
.tabla { overflow-x: auto; border: 1px solid #e2e8f0; border-radius: 8px; }
table { width: 100%; border-collapse: collapse; }
th, td {
  padding: 13px; text-align: left;
  border-bottom: 1px solid #e2e8f0; font-size: 13px;
}
th { background: #f8fafc; color: #475569; }
.persona { display: flex; align-items: center; gap: 10px; }
.persona small { display: block; color: #64748b; }
.mini-foto {
  width: 45px; height: 45px; border-radius: 50%;
  object-fit: cover; flex-shrink: 0;
}
.sin-foto { display: grid; place-items: center; background: #f1f5f9; }
.acciones { display: flex; flex-wrap: wrap; gap: 5px; }
.estado { padding: 5px 9px; border-radius: 20px; font-size: 11px; }
.activo { background: #dcfce7; color: #166534; }
.inactivo { background: #fee2e2; color: #991b1b; }
.vacio { text-align: center; color: #64748b; }
.alerta {
  display: flex; justify-content: space-between;
  padding: 12px; border-radius: 6px; margin-bottom: 15px;
}
.exito { background: #dcfce7; color: #166534; }
.error { background: #fee2e2; color: #991b1b; }
.fondo {
  position: fixed; inset: 0; background: #0008;
  display: flex; align-items: center; justify-content: center;
  padding: 15px; z-index: 1000;
}
.ventana {
  background: white; width: 100%; max-width: 680px;
  max-height: 90vh; overflow-y: auto;
  padding: 24px; border-radius: 12px;
}
.campos { display: grid; grid-template-columns: repeat(2, 1fr); gap: 14px; }
.campos label { display: flex; flex-direction: column; gap: 6px; }
.ancho { grid-column: 1 / -1; }
.detalle { padding: 12px; background: #f8fafc; margin-top: 15px; }
.botones { display: flex; justify-content: flex-end; gap: 10px; margin-top: 20px; }
@media (max-width: 650px) {
  .campos { grid-template-columns: 1fr; }
  .ancho { grid-column: auto; }
  .encabezado { flex-wrap: wrap; }
}
</style>