
<template>
  <div class="materiales-container">
    <div class="header-seccion">
      <div>
        <h2>Gestión de Materiales</h2>
        <p class="subtitulo">
          Control de inventario, insumos didácticos y recursos clínicos del centro
        </p>
      </div>
    </div>

    <!-- PESTAÑAS -->
    <div class="pestanas">
      <button
        type="button"
        :class="['pestana', { activa: pestanaActiva === 'inventario' }]"
        @click="pestanaActiva = 'inventario'"
      >
        Inventario
      </button>
      <button
        type="button"
        :class="['pestana', { activa: pestanaActiva === 'asignaciones' }]"
        @click="abrirAsignaciones"
      >
        Asignaciones y devoluciones
      </button>
      <button type="button" :class="['pestana', { activa: pestanaActiva === 'educativos' }]" @click="pestanaActiva = 'educativos'">Recursos educativos</button>
    </div>
    <RecursosEducativos v-if="pestanaActiva === 'educativos'" />
    <!-- MENSAJES -->
    <div
      v-if="mensajeAlerta"
      :class="['alerta', tipoAlerta === 'exito' ? 'alerta-exito' : 'alerta-error']"
    >
      {{ mensajeAlerta }}
    </div>

    <!-- PESTAÑA INVENTARIO -->
    <section v-if="pestanaActiva === 'inventario'">
      <div class="barra-acciones">
        <h3>Inventario de materiales</h3>
        <button class="btn-primario" @click="abrirModalCrear">
          + Registrar Nuevo Material
        </button>
      </div>

      <div class="filtros-box">
        <input
          v-model="busqueda"
          type="text"
          placeholder="Buscar material por nombre o descripción..."
        />

        <select v-model="filtroCategoria">
          <option value="">Todas las categorías</option>
          <option
            v-for="categoria in categorias"
            :key="categoria"
            :value="categoria"
          >
            {{ categoria }}
          </option>
        </select>

        <select v-model="filtroEstado">
          <option value="">Todos los estados</option>
          <option value="DISPONIBLE">Disponible</option>
          <option value="EN_USO">En Uso</option>
          <option value="AGOTADO">Agotado</option>
          <option value="MANTENIMIENTO">Mantenimiento</option>
        </select>
      </div>

      <div class="resumen-cards">
        <div class="card-metrica">
          <strong>{{ materiales.length }}</strong>
          <span>Total registrados</span>
        </div>
        <div class="card-metrica">
          <strong class="verde">{{ totalDisponibles }}</strong>
          <span>Disponibles</span>
        </div>
        <div class="card-metrica">
          <strong class="azul">{{ totalEnUso }}</strong>
          <span>En uso</span>
        </div>
        <div class="card-metrica">
          <strong class="rojo">{{ totalAgotados }}</strong>
          <span>Agotados</span>
        </div>
      </div>

      <div class="tabla-responsive">
        <p v-if="cargando" class="mensaje-tabla">
          Cargando materiales...
        </p>

        <table v-else class="tabla-datos">
          <thead>
            <tr>
              <th>Nombre y descripción</th>
              <th>Categoría</th>
              <th>Cantidad</th>
              <th>Estado</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="material in materialesFiltrados" :key="material._id">
              <td>
                <strong>{{ material.nombre }}</strong>
                <p class="descripcion">{{ material.descripcion }}</p>
              </td>
              <td>{{ material.categoria }}</td>
              <td>{{ material.cantidad }} un.</td>
              <td>
                <span
                  :class="['badge', 'badge-' + material.estado.toLowerCase().replace('_', '-')]"
                >
                  {{ formatearEstado(material.estado) }}
                </span>
              </td>
              <td>
                <div class="acciones">
                  <button @click="abrirModalEditar(material)">
                    ✏️ Editar
                  </button>
                  <button
                    class="btn-eliminar"
                    @click="confirmarEliminar(material)"
                  >
                    Eliminar
                  </button>
                </div>
              </td>
            </tr>

            <tr v-if="materialesFiltrados.length === 0">
              <td colspan="5" class="mensaje-tabla">
                No se encontraron materiales.
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>

    <!-- PESTAÑA ASIGNACIONES -->
    <section v-if="pestanaActiva === 'asignaciones'">
      <div class="barra-acciones">
        <h3>Asignación de materiales</h3>
        <button @click="cargarAsignaciones" :disabled="cargandoAsignaciones">
          Actualizar
        </button>
      </div>

      <div class="panel">
        <h3>Nueva asignación</h3>

        <form @submit.prevent="registrarAsignacion">
          <div class="form-grid">
            <div class="campo">
              <label>Paciente activo *</label>
              <select v-model="formAsignacion.pacienteId" required>
                <option value="">Seleccionar paciente</option>
                <option
                  v-for="paciente in pacientesActivos"
                  :key="paciente._id"
                  :value="paciente._id"
                >
                  {{ nombrePaciente(paciente) }}
                </option>
              </select>
            </div>

            <div class="campo">
              <label>Material disponible *</label>
              <select v-model="formAsignacion.materialId" required>
                <option value="">Seleccionar material</option>
                <option
                  v-for="material in materialesAsignables"
                  :key="material._id"
                  :value="material._id"
                >
                  {{ material.nombre }} - {{ material.cantidad }} disponibles
                </option>
              </select>
            </div>

            <div class="campo">
              <label>Cantidad *</label>
              <input
                v-model.number="formAsignacion.cantidad"
                type="number"
                min="1"
                step="1"
                :max="materialElegido?.cantidad || undefined"
                required
              />
              <small v-if="materialElegido">
                Existencias disponibles: {{ materialElegido.cantidad }}
              </small>
            </div>

            <div class="campo campo-completo">
              <label>Observaciones</label>
              <textarea
                v-model.trim="formAsignacion.observaciones"
                rows="3"
                placeholder="Ejemplo: Material entregado para terapia"
              ></textarea>
            </div>
          </div>

          <div class="acciones-formulario">
            <button
              type="submit"
              class="btn-primario"
              :disabled="guardandoAsignacion || cargandoAsignaciones"
            >
              {{ guardandoAsignacion ? 'Guardando...' : 'Asignar Material' }}
            </button>
          </div>
        </form>
      </div>

      <div class="panel">
        <div class="barra-acciones">
          <h3>Historial de asignaciones</h3>
          <select v-model="filtroAsignacion">
            <option value="">Todos los estados</option>
            <option value="ASIGNADO">Asignados</option>
            <option value="DEVUELTO">Devueltos</option>
          </select>
        </div>

        <p v-if="cargandoAsignaciones" class="mensaje-tabla">
          Cargando historial...
        </p>

        <div v-else class="tabla-responsive">
          <table class="tabla-datos">
            <thead>
              <tr>
                <th>Paciente</th>
                <th>Material</th>
                <th>Cantidad</th>
                <th>Fecha</th>
                <th>Estado</th>
                <th>Acción</th>
              </tr>
            </thead>
            <tbody>
              <tr
                v-for="asignacion in asignacionesFiltradas"
                :key="asignacion._id"
              >
                <td>{{ nombrePaciente(asignacion.paciente) }}</td>
                <td>{{ asignacion.material?.nombre || 'No disponible' }}</td>
                <td>{{ asignacion.cantidad }}</td>
                <td>{{ fechaAsignacion(asignacion) }}</td>
                <td>
                  <span
                    :class="['badge', asignacion.estado === 'ASIGNADO' ? 'badge-en-uso' : 'badge-disponible']"
                  >
                    {{ asignacion.estado }}
                  </span>
                </td>
                <td>
                  <button
                    v-if="asignacion.estado === 'ASIGNADO'"
                    class="btn-devolver"
                    :disabled="guardandoAsignacion"
                    @click="devolverAsignacion(asignacion)"
                  >
                    Registrar devolución
                  </button>
                  <span v-else>—</span>
                </td>
              </tr>

              <tr v-if="asignacionesFiltradas.length === 0">
                <td colspan="6" class="mensaje-tabla">
                  No hay asignaciones registradas.
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </section>

    <!-- MODAL INVENTARIO -->
    <div v-if="modalVisible" class="modal-overlay">
      <div class="modal-contenido">
        <div class="modal-header">
          <h3>
            {{ esEdicion ? 'Editar Material' : 'Registrar Nuevo Material' }}
          </h3>
          <button type="button" @click="cerrarModal">×</button>
        </div>

        <form @submit.prevent="guardarMaterial" class="formulario-modal">
          <div class="campo">
            <label>Nombre del material *</label>
            <input
              v-model.trim="form.nombre"
              type="text"
              required
            />
          </div>

          <div class="campo">
            <label>Descripción *</label>
            <textarea
              v-model.trim="form.descripcion"
              rows="3"
              required
            ></textarea>
          </div>

          <div class="form-grid">
            <div class="campo">
              <label>Cantidad en stock *</label>
              <input
                v-model.number="form.cantidad"
                type="number"
                min="0"
                step="1"
                required
              />
            </div>

            <div class="campo">
              <label>Categoría *</label>
              <select v-model="form.categoria" required>
                <option
                  v-for="categoria in categorias"
                  :key="categoria"
                  :value="categoria"
                >
                  {{ categoria }}
                </option>
              </select>
            </div>
          </div>

          <div v-if="esEdicion" class="campo">
            <label>Estado actual *</label>
            <select v-model="form.estado" required>
              <option value="DISPONIBLE">Disponible</option>
              <option value="EN_USO">En uso</option>
              <option value="AGOTADO">Agotado</option>
              <option value="MANTENIMIENTO">Mantenimiento</option>
            </select>
          </div>

          <div class="modal-acciones">
            <button type="button" @click="cerrarModal">
              Cancelar
            </button>
            <button
              type="submit"
              class="btn-primario"
              :disabled="guardando"
            >
              {{ guardando ? 'Guardando...' : esEdicion ? 'Actualizar' : 'Registrar' }}
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup>
import RecursosEducativos from '../components/RecursosEducativos.vue';
import { ref, computed, onMounted } from 'vue';
import api from '../services/api';

// CATEGORÍAS
const categorias = [
  'Fonoaudiología',
  'Terapia Ocupacional',
  'Diagnóstico Clínico',
  'Orientación Familiar',
  'Audiología',
  'General'
];

// ESTADO GENERAL
const pestanaActiva = ref('inventario');
const materiales = ref([]);
const cargando = ref(false);
const guardando = ref(false);
const mensajeAlerta = ref('');
const tipoAlerta = ref('exito');

// INVENTARIO
const busqueda = ref('');
const filtroCategoria = ref('');
const filtroEstado = ref('');
const modalVisible = ref(false);
const esEdicion = ref(false);
const materialIdSeleccionado = ref(null);

const formularioMaterialVacio = () => ({
  nombre: '',
  descripcion: '',
  cantidad: 1,
  categoria: categorias[0],
  estado: 'DISPONIBLE'
});

const form = ref(formularioMaterialVacio());

// ASIGNACIONES
const pacientes = ref([]);
const asignaciones = ref([]);
const cargandoAsignaciones = ref(false);
const guardandoAsignacion = ref(false);
const filtroAsignacion = ref('');

const formularioAsignacionVacio = () => ({
  pacienteId: '',
  materialId: '',
  cantidad: 1,
  observaciones: ''
});

const formAsignacion = ref(formularioAsignacionVacio());

// MENSAJES
const mostrarMensaje = (texto, tipo = 'exito') => {
  mensajeAlerta.value = texto;
  tipoAlerta.value = tipo;
};

const obtenerError = (error, mensajeDefecto) => {
  const estado = error.response?.status;
  const datos = error.response?.data;

  if (estado === 401) {
    return 'Tu sesión ha expirado o no es válida. Inicia sesión nuevamente.';
  }

  if (estado === 403) {
    return 'Acceso restringido: no tienes permisos para realizar esta operación.';
  }

  if (estado === 404) {
    return datos?.mensaje || 'El registro solicitado no fue encontrado.';
  }

  if (estado === 400) {
    return datos?.mensaje || 'Verifica los datos ingresados.';
  }

  if (estado >= 500) {
    return 'Ocurrió un error en el servidor. Intenta nuevamente.';
  }

  if (!error.response) {
    return 'No se pudo establecer conexión con el servidor.';
  }

  return datos?.mensaje ||
    (Array.isArray(datos?.errores) ? datos.errores.join(', ') : null) ||
    mensajeDefecto;
};

// RESPUESTAS DEL BACKEND
const listaRespuesta = (datos, claves) => {
  if (Array.isArray(datos)) return datos;

  for (const clave of claves) {
    if (Array.isArray(datos?.[clave])) {
      return datos[clave];
    }
  }

  return [];
};

// CARGAR INVENTARIO
const cargarMateriales = async () => {
  cargando.value = true;

  try {
    const respuesta = await api.get('/materiales');
    materiales.value = listaRespuesta(
      respuesta.data,
      ['materiales', 'data']
    );
  } catch (error) {
    mostrarMensaje(
      obtenerError(error, 'Error al cargar materiales'),
      'error'
    );
  } finally {
    cargando.value = false;
  }
};

// FILTROS DE INVENTARIO
const materialesFiltrados = computed(() =>
  materiales.value.filter(material => {
    const texto = busqueda.value.toLowerCase().trim();

    const coincideTexto =
      !texto ||
      (material.nombre || '').toLowerCase().includes(texto) ||
      (material.descripcion || '').toLowerCase().includes(texto);

    const coincideCategoria =
      !filtroCategoria.value ||
      material.categoria === filtroCategoria.value;

    const coincideEstado =
      !filtroEstado.value ||
      material.estado === filtroEstado.value;

    return coincideTexto && coincideCategoria && coincideEstado;
  })
);

const totalDisponibles = computed(() =>
  materiales.value.filter(m => m.estado === 'DISPONIBLE').length
);

const totalEnUso = computed(() =>
  materiales.value.filter(m => m.estado === 'EN_USO').length
);

const totalAgotados = computed(() =>
  materiales.value.filter(
    m => m.estado === 'AGOTADO' || Number(m.cantidad) === 0
  ).length
);

// MODAL INVENTARIO
const abrirModalCrear = () => {
  esEdicion.value = false;
  materialIdSeleccionado.value = null;
  form.value = formularioMaterialVacio();
  modalVisible.value = true;
};

const abrirModalEditar = (material) => {
  esEdicion.value = true;
  materialIdSeleccionado.value = material._id;

  form.value = {
    nombre: material.nombre,
    descripcion: material.descripcion,
    cantidad: material.cantidad,
    categoria: material.categoria,
    estado: material.estado
  };

  modalVisible.value = true;
};

const cerrarModal = () => {
  if (guardando.value) return;
  modalVisible.value = false;
};

// GUARDAR MATERIAL
const guardarMaterial = async () => {
  if (!Number.isSafeInteger(Number(form.value.cantidad)) ||
      Number(form.value.cantidad) < 0) {
    mostrarMensaje('La cantidad debe ser un entero válido.', 'error');
    return;
  }

  guardando.value = true;

  try {
    if (esEdicion.value) {
      await api.put(
        `/materiales/${materialIdSeleccionado.value}`,
        form.value
      );
      mostrarMensaje('Material actualizado correctamente.');
    } else {
      await api.post('/materiales', form.value);
      mostrarMensaje('Material registrado correctamente.');
    }

    modalVisible.value = false;
    await cargarMateriales();
  } catch (error) {
    mostrarMensaje(
      obtenerError(error, 'Error al guardar material'),
      'error'
    );
  } finally {
    guardando.value = false;
  }
};

// ELIMINAR MATERIAL
const confirmarEliminar = async (material) => {
  const confirmar = window.confirm(
    `¿Está seguro de eliminar el material "${material.nombre}"?`
  );

  if (!confirmar) return;

  try {
    await api.delete(`/materiales/${material._id}`);
    mostrarMensaje('Material eliminado correctamente.');
    await cargarMateriales();
  } catch (error) {
    mostrarMensaje(
      obtenerError(error, 'Error al eliminar material'),
      'error'
    );
  }
};

const formatearEstado = (estado) => {
  const estados = {
    DISPONIBLE: 'Disponible',
    EN_USO: 'En uso',
    AGOTADO: 'Agotado',
    MANTENIMIENTO: 'Mantenimiento'
  };

  return estados[estado] || estado;
};

// CARGAR ASIGNACIONES
const cargarAsignaciones = async () => {
  cargandoAsignaciones.value = true;

  try {
    const [resPacientes, resMateriales, resAsignaciones] =
      await Promise.all([
        api.get('/pacientes'),
        api.get('/materiales'),
        api.get('/asignaciones-materiales')
      ]);

    pacientes.value = listaRespuesta(
      resPacientes.data,
      ['pacientes', 'data']
    );

    materiales.value = listaRespuesta(
      resMateriales.data,
      ['materiales', 'data']
    );

    asignaciones.value = listaRespuesta(
      resAsignaciones.data,
      ['asignaciones', 'data']
    );
  } catch (error) {
    mostrarMensaje(
      obtenerError(error, 'Error al cargar asignaciones'),
      'error'
    );
  } finally {
    cargandoAsignaciones.value = false;
  }
};

const abrirAsignaciones = () => {
  pestanaActiva.value = 'asignaciones';
  cargarAsignaciones();
};

// PACIENTES ACTIVOS
const pacientesActivos = computed(() =>
  pacientes.value.filter(
    paciente => paciente.estado === 'ACTIVO'
  )
);

// MATERIALES DISPONIBLES
const materialesAsignables = computed(() =>
  materiales.value.filter(
    material =>
      Number(material.cantidad) > 0 &&
      !['AGOTADO', 'MANTENIMIENTO'].includes(material.estado)
  )
);

const materialElegido = computed(() =>
  materiales.value.find(
    material => material._id === formAsignacion.value.materialId
  )
);

// HISTORIAL
const asignacionesFiltradas = computed(() =>
  asignaciones.value.filter(
    asignacion =>
      !filtroAsignacion.value ||
      asignacion.estado === filtroAsignacion.value
  )
);

const nombrePaciente = (paciente) => {
  if (!paciente || typeof paciente !== 'object') {
    return 'Paciente no disponible';
  }

  return [
    paciente.nombres || paciente.nombre,
    paciente.apellidos || paciente.apellido
  ].filter(Boolean).join(' ') || 'Paciente sin nombre';
};

const fechaAsignacion = (asignacion) => {
  const fecha = asignacion.fechaAsignacion || asignacion.createdAt;

  if (!fecha) return 'Sin fecha';

  const valor = new Date(fecha);

  if (Number.isNaN(valor.getTime())) {
    return 'Fecha inválida';
  }

  return valor.toLocaleDateString('es-GT');
};

// REGISTRAR ASIGNACIÓN
const registrarAsignacion = async () => {
  const cantidad = Number(formAsignacion.value.cantidad);

  if (!formAsignacion.value.pacienteId ||
      !formAsignacion.value.materialId) {
    mostrarMensaje('Selecciona un paciente y un material.', 'error');
    return;
  }

  if (!Number.isSafeInteger(cantidad) || cantidad < 1) {
    mostrarMensaje('La cantidad debe ser un entero positivo.', 'error');
    return;
  }

  if (!materialElegido.value ||
      cantidad > Number(materialElegido.value.cantidad)) {
    mostrarMensaje('No hay suficientes existencias.', 'error');
    return;
  }

  guardandoAsignacion.value = true;

  try {
    await api.post('/asignaciones-materiales', {
      pacienteId: formAsignacion.value.pacienteId,
      materialId: formAsignacion.value.materialId,
      cantidad,
      observaciones: formAsignacion.value.observaciones
    });

    formAsignacion.value = formularioAsignacionVacio();

    await cargarAsignaciones();
    mostrarMensaje('Material asignado correctamente.');
  } catch (error) {
    mostrarMensaje(
      obtenerError(error, 'Error al asignar material'),
      'error'
    );
  } finally {
    guardandoAsignacion.value = false;
  }
};

// REGISTRAR DEVOLUCIÓN
const devolverAsignacion = async (asignacion) => {
  const confirmar = window.confirm(
    `¿Registrar la devolución de ${asignacion.cantidad} unidad(es)?`
  );

  if (!confirmar) return;

  guardandoAsignacion.value = true;

  try {
    await api.patch(
      `/asignaciones-materiales/${asignacion._id}/devolver`
    );

    await cargarAsignaciones();
    mostrarMensaje(
      'Devolución registrada. Existencias actualizadas.'
    );
  } catch (error) {
    mostrarMensaje(
      obtenerError(error, 'Error al registrar devolución'),
      'error'
    );
  } finally {
    guardandoAsignacion.value = false;
  }
};

onMounted(cargarMateriales);
</script>

<style scoped>
.materiales-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 25px 20px;
}

.header-seccion {
  margin-bottom: 22px;
}

h2 {
  color: #1e3a5f;
  margin-bottom: 6px;
}

h3 {
  color: #1e3a5f;
  margin: 0;
}

.subtitulo {
  color: #6c757d;
  margin-top: 4px;
}

.pestanas {
  display: flex;
  gap: 8px;
  border-bottom: 2px solid #e2e8f0;
  margin-bottom: 25px;
  flex-wrap: wrap;
}

.pestana {
  background: transparent;
  border: none;
  padding: 13px 20px;
  color: #64748b;
  font-weight: 600;
  cursor: pointer;
  border-bottom: 3px solid transparent;
}

.pestana.activa {
  color: #007bff;
  border-bottom-color: #007bff;
}

.barra-acciones {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 15px;
  flex-wrap: wrap;
  margin-bottom: 20px;
}

button {
  padding: 9px 13px;
  border: 1px solid #cbd5e1;
  border-radius: 5px;
  background: white;
  cursor: pointer;
}

button:disabled {
  opacity: .6;
  cursor: not-allowed;
}

.btn-primario {
  background: #007bff;
  border: none;
  color: white;
  font-weight: 600;
}

.btn-primario:hover {
  background: #0056b3;
}

.btn-eliminar {
  color: #dc3545;
  border-color: #dc3545;
}

.btn-devolver {
  background: #dcfce7;
  color: #166534;
  border-color: #86efac;
}

.filtros-box {
  display: flex;
  flex-wrap: wrap;
  gap: 15px;
  margin-bottom: 20px;
}

.filtros-box input {
  flex: 1;
  min-width: 220px;
}

input, select, textarea {
  padding: 10px;
  border: 1px solid #ced4da;
  border-radius: 5px;
  font: inherit;
  box-sizing: border-box;
}

.resumen-cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(170px, 1fr));
  gap: 15px;
  margin-bottom: 22px;
}

.card-metrica {
  background: white;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  padding: 20px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 5px;
}

.card-metrica strong {
  font-size: 1.8rem;
}

.card-metrica span {
  font-size: .85rem;
  color: #6c757d;
}

.verde { color: #28a745; }
.azul { color: #007bff; }
.rojo { color: #dc3545; }

.panel {
  background: white;
  border: 1px solid #e2e8f0;
  border-radius: 10px;
  padding: 24px;
  margin-bottom: 24px;
}

.panel h3 {
  margin-bottom: 18px;
}

.form-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 16px;
}

.campo {
  display: flex;
  flex-direction: column;
  gap: 7px;
}

.campo label {
  color: #495057;
  font-weight: 600;
  font-size: .9rem;
}

.campo input,
.campo select,
.campo textarea {
  width: 100%;
}

.campo small {
  color: #64748b;
}

.campo-completo {
  grid-column: 1 / -1;
}

.acciones-formulario {
  margin-top: 20px;
}

.tabla-responsive {
  background: white;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  overflow-x: auto;
}

.tabla-datos {
  width: 100%;
  border-collapse: collapse;
  text-align: left;
  font-size: .9rem;
}

.tabla-datos th,
.tabla-datos td {
  padding: 13px 15px;
  border-bottom: 1px solid #eee;
}

.tabla-datos th {
  background: #f8f9fa;
  color: #495057;
}

.descripcion {
  color: #6c757d;
  font-size: .82rem;
  margin: 5px 0 0;
}

.acciones {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

.badge {
  display: inline-block;
  border-radius: 15px;
  padding: 5px 10px;
  font-size: .8rem;
  font-weight: 600;
}

.badge-disponible {
  background: #d4edda;
  color: #155724;
}

.badge-en-uso {
  background: #cce5ff;
  color: #004085;
}

.badge-agotado {
  background: #f8d7da;
  color: #721c24;
}

.badge-mantenimiento {
  background: #ffeeba;
  color: #856404;
}

.mensaje-tabla {
  text-align: center;
  padding: 25px;
  color: #64748b;
}

.alerta {
  padding: 13px;
  border-radius: 6px;
  margin-bottom: 20px;
}

.alerta-exito {
  background: #d4edda;
  color: #155724;
}

.alerta-error {
  background: #f8d7da;
  color: #721c24;
}

.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, .5);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 15px;
  z-index: 1000;
}

.modal-contenido {
  background: white;
  width: 100%;
  max-width: 550px;
  max-height: 90vh;
  overflow-y: auto;
  border-radius: 10px;
  padding: 24px;
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.formulario-modal {
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.modal-acciones {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 15px;
}

@media (max-width: 700px) {
  .form-grid {
    grid-template-columns: 1fr;
  }

  .campo-completo {
    grid-column: auto;
  }

  .barra-acciones {
    align-items: stretch;
  }

  .pestana {
    flex: 1;
  }
}
</style>