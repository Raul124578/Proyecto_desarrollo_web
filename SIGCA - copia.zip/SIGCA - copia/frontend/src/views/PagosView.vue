
<template>
  <div class="pagos-container">
    <div class="header-seccion">
      <div>
        <h2>Gestión de Pagos y Facturación</h2>
        <p class="subtitulo">
          Registro de cobros, recibos UUID, saldos y control de anulaciones
        </p>
      </div>

      <button
        type="button"
        class="btn-nuevo"
        @click="abrirModalNuevoPago"
      >
        + Registrar Nuevo Pago
      </button>
    </div>

    <!-- NOTIFICACIONES VISIBLES SOBRE LOS MODALES -->
    <Teleport to="body">
      <div
        v-if="mensajeAlerta"
        class="notificacion-flotante"
        :class="
          tipoAlerta === 'exito'
            ? 'notificacion-exito'
            : 'notificacion-error'
        "
        role="alert"
        aria-live="assertive"
      >
        <span class="notificacion-icono">
          {{ tipoAlerta === 'exito' ? '✓' : '⚠' }}
        </span>

        <span class="notificacion-texto">
          {{ mensajeAlerta }}
        </span>

        <button
          type="button"
          class="cerrar-notificacion"
          aria-label="Cerrar notificación"
          @click="cerrarNotificacion"
        >
          ×
        </button>
      </div>
    </Teleport>

    <!-- RESUMEN DE PAGOS -->
    <div class="resumen-grid">
      <div class="resumen-card">
        <span class="label">Total Recaudado (Vigente)</span>
        <span class="valor monto">
          Q{{ (totalRecaudadoCentavos / 100).toFixed(2) }}
        </span>
      </div>

      <div class="resumen-card">
        <span class="label">Pagos Registrados</span>
        <span class="valor">{{ pagosRegistradosCount }}</span>
      </div>

      <div class="resumen-card">
        <span class="label">Pagos Anulados</span>
        <span class="valor text-anulado">
          {{ pagosAnuladosCount }}
        </span>
      </div>
    </div>

    <!-- FILTROS -->
    <div class="filtros-box">
      <input
        v-model="busqueda"
        type="text"
        placeholder="Buscar por número de recibo o paciente..."
        class="input-busqueda"
      />

      <select v-model="filtroEstado" class="select-filtro">
        <option value="">Todos los estados</option>
        <option value="REGISTRADO">Solo Registrados</option>
        <option value="ANULADO">Solo Anulados</option>
      </select>
    </div>

    <!-- HISTORIAL -->
    <div class="tabla-responsive">
      <div v-if="cargando" class="mensaje-carga">
        Cargando historial de pagos...
      </div>

      <div
        v-else-if="pagosFiltrados.length === 0"
        class="mensaje-carga"
      >
        No se encontraron pagos con los criterios especificados.
      </div>

      <table v-else class="tabla-datos">
        <thead>
          <tr>
            <th>No. Recibo</th>
            <th>Fecha</th>
            <th>Paciente</th>
            <th>Monto</th>
            <th>Método</th>
            <th>Estado</th>
            <th>Acciones</th>
          </tr>
        </thead>

        <tbody>
          <tr
            v-for="(p, idx) in pagosFiltrados"
            :key="p._id"
          >
            <td>
              <div class="recibo-box">
                <span class="correlativo-recibo">
                  {{ correlativoPago(p, idx) }}
                </span>

                <span
                  class="codigo-uuid"
                  :title="'Identificador UUID único: ' + p.numeroRecibo"
                >
                  {{ formatearUUID(p.numeroRecibo) }}
                </span>
              </div>
            </td>

            <td>{{ formatearFecha(p.createdAt) }}</td>

            <td>
              <strong>
                {{
                  p.paciente
                    ? `${p.paciente.nombres} ${p.paciente.apellidos}`
                    : 'Paciente'
                }}
              </strong>
            </td>

            <td class="monto-tabla">
              Q{{ (p.montoCentavos / 100).toFixed(2) }}
            </td>

            <td>
              <span class="badge-metodo">
                {{ p.metodo }}
              </span>
            </td>

            <td>
              <span
                class="badge-estado"
                :class="
                  p.estado === 'REGISTRADO'
                    ? 'badge-exito'
                    : 'badge-error'
                "
              >
                {{ p.estado }}
              </span>
            </td>

            <td>
              <button
                v-if="p.estado === 'REGISTRADO'"
                type="button"
                class="btn-anular"
                @click="abrirModalAnular(p)"
              >
                Anular
              </button>

              <span
                v-else
                class="texto-motivo"
                :title="p.motivoAnulacion"
              >
                Anulado:
                {{
                  p.motivoAnulacion
                    ? p.motivoAnulacion.substring(0, 20) + '...'
                    : 'Sin detalle'
                }}
              </span>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- MODAL: REGISTRAR PAGO -->
    <div
      v-if="mostrarModalPago"
      class="modal-overlay"
    >
      <div class="modal-card">
        <h3>Registrar Nuevo Cobro / Pago</h3>

        <p class="modal-desc">
          Elige la cita del paciente. Se calculará el saldo
          pendiente automáticamente.
        </p>

        <form @submit.prevent="confirmarRegistroPago">
          <div class="campo">
            <label for="citaSelect">
              Selecciona la Cita del Paciente *
            </label>

            <select
              id="citaSelect"
              v-model="formPago.citaId"
              required
              @change="alCambiarCita"
            >
              <option value="" disabled>
                -- Selecciona una cita --
              </option>

              <option
                v-for="c in citasDisponibles"
                :key="c._id"
                :value="c._id"
              >
                {{
                  c.paciente
                    ? `${c.paciente.nombres} ${c.paciente.apellidos}`
                    : 'Paciente'
                }}
                -
                {{ c.servicio?.nombre || 'Servicio' }}
                |
                Saldo:
                Q{{ (obtenerSaldoCita(c._id) / 100).toFixed(2) }}
              </option>
            </select>
          </div>

          <div
            v-if="formPago.citaId"
            class="saldo-info-box"
          >
            Saldo pendiente a liquidar:
            <strong>
              Q{{ (obtenerSaldoCita(formPago.citaId) / 100).toFixed(2) }}
            </strong>
          </div>

          <div class="campo">
            <label for="montoPago">
              Monto a Pagar en Quetzales (Q) *
            </label>

            <input
              id="montoPago"
              v-model.number="formPago.montoQuetzales"
              type="number"
              step="0.01"
              min="0.01"
              :max="
                formPago.citaId
                  ? obtenerSaldoCita(formPago.citaId) / 100
                  : undefined
              "
              placeholder="Ej. 100.00"
              required
            />

            <small
              v-if="montoExcedeSaldo"
              class="campo-error"
            >
              El monto ingresado supera el saldo pendiente
              de Q{{ (saldoSeleccionadoCentavos / 100).toFixed(2) }}.
            </small>
          </div>

          <div class="campo">
            <label for="metodoPago">
              Método de Pago *
            </label>

            <select
              id="metodoPago"
              v-model="formPago.metodo"
              required
            >
              <option value="EFECTIVO">EFECTIVO</option>
              <option value="TARJETA">
                TARJETA DE CRÉDITO/DÉBITO
              </option>
              <option value="TRANSFERENCIA">
                TRANSFERENCIA BANCARIA
              </option>
            </select>
          </div>

          <div class="modal-acciones">
            <button
              type="button"
              class="btn-cancelar"
              @click="mostrarModalPago = false"
            >
              Cancelar
            </button>

            <button
              type="submit"
              class="btn-confirmar"
              :disabled="procesando"
            >
              {{
                procesando
                  ? 'Procesando...'
                  : 'Cobrar y Generar Recibo'
              }}
            </button>
          </div>
        </form>
      </div>
    </div>

    <!-- MODAL: ANULAR PAGO -->
    <div
      v-if="mostrarModalAnulacion"
      class="modal-overlay"
    >
      <div class="modal-card">
        <h3>Anulación de Recibo / Pago</h3>

        <p class="modal-desc">
          Indica el motivo de la anulación para los
          registros contables y auditoría.
        </p>

        <form @submit.prevent="confirmarAnulacion">
          <div class="campo">
            <label for="motivoAnula">
              Motivo de Anulación *
            </label>

            <textarea
              id="motivoAnula"
              v-model.trim="motivoAnulacion"
              rows="3"
              maxlength="500"
              placeholder="Ej. Error en cobro de tarjeta..."
              required
            ></textarea>
          </div>

          <div class="modal-acciones">
            <button
              type="button"
              class="btn-cancelar"
              @click="mostrarModalAnulacion = false"
            >
              Cancelar
            </button>

            <button
              type="submit"
              class="btn-confirmar-anula"
              :disabled="procesando"
            >
              {{
                procesando
                  ? 'Procesando...'
                  : 'Confirmar Anulación'
              }}
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup>
import {
  ref,
  computed,
  onMounted,
  onUnmounted
} from 'vue';

import api from '../services/api';

const pagos = ref([]);
const citasDisponibles = ref([]);
const cargando = ref(true);
const procesando = ref(false);

const busqueda = ref('');
const filtroEstado = ref('');

const mensajeAlerta = ref('');
const tipoAlerta = ref('exito');

const mostrarModalPago = ref(false);
const mostrarModalAnulacion = ref(false);

const pagoSeleccionado = ref(null);
const motivoAnulacion = ref('');

const formPago = ref({
  citaId: '',
  montoQuetzales: 0,
  metodo: 'EFECTIVO'
});

// CONTROL DE NOTIFICACIONES
let temporizadorAlerta = null;

const cerrarNotificacion = () => {
  mensajeAlerta.value = '';

  if (temporizadorAlerta) {
    clearTimeout(temporizadorAlerta);
    temporizadorAlerta = null;
  }
};

const notificar = (msg, tipo = 'exito') => {
  if (temporizadorAlerta) {
    clearTimeout(temporizadorAlerta);
  }

  mensajeAlerta.value = msg;
  tipoAlerta.value = tipo;

  temporizadorAlerta = setTimeout(() => {
    mensajeAlerta.value = '';
    temporizadorAlerta = null;
  }, 8000);
};

// RECIBOS
const correlativoPago = (pago, idx) => {
  const numero = pagos.value.length - idx;
  return `#REC-${numero.toString().padStart(3, '0')}`;
};

const formatearUUID = (uuidCompleto) => {
  if (!uuidCompleto) return '-';

  if (uuidCompleto.length > 20) {
    return (
      uuidCompleto.slice(0, 12) +
      '...' +
      uuidCompleto.slice(-4)
    );
  }

  return uuidCompleto;
};

// CARGAR PAGOS
const cargarPagos = async () => {
  try {
    cargando.value = true;

    const res = await api.get('/pagos');

    pagos.value = res.data || [];

  } catch (error) {
    notificar(
      error.response?.data?.mensaje ||
      'Error al cargar pagos',
      'error'
    );

  } finally {
    cargando.value = false;
  }
};

// CARGAR CITAS
const cargarCitas = async () => {
  try {
    const res = await api.get('/citas?limite=100');

    const lista =
      res.data?.citas ||
      (Array.isArray(res.data) ? res.data : []);

    citasDisponibles.value = lista.filter(
      c => c.estado !== 'CANCELADA'
    );

  } catch (error) {
    console.error('Error al cargar citas:', error);

    notificar(
      error.response?.data?.mensaje ||
      'Error al cargar citas disponibles',
      'error'
    );
  }
};

// SALDO PENDIENTE
const obtenerSaldoCita = citaId => {
  const cita = citasDisponibles.value.find(
    c => c._id === citaId
  );

  if (!cita) return 0;

  const pagado = pagos.value
    .filter(
      p =>
        (
          p.cita?._id === citaId ||
          p.cita === citaId
        ) &&
        p.estado === 'REGISTRADO'
    )
    .reduce(
      (sum, p) => sum + (p.montoCentavos || 0),
      0
    );

  return Math.max(
    0,
    (cita.precioCentavos || 0) - pagado
  );
};

const saldoSeleccionadoCentavos = computed(() => {
  if (!formPago.value.citaId) return 0;

  return obtenerSaldoCita(formPago.value.citaId);
});

const montoExcedeSaldo = computed(() => {
  if (!formPago.value.citaId) return false;

  const monto = Number(formPago.value.montoQuetzales);

  if (!Number.isFinite(monto)) return false;

  return Math.round(monto * 100) >
    saldoSeleccionadoCentavos.value;
});

// ABRIR FORMULARIO DE PAGO
const abrirModalNuevoPago = async () => {
  await cargarCitas();

  formPago.value = {
    citaId: '',
    montoQuetzales: 0,
    metodo: 'EFECTIVO'
  };

  mostrarModalPago.value = true;
};

const alCambiarCita = () => {
  const saldoCentavos = obtenerSaldoCita(
    formPago.value.citaId
  );

  formPago.value.montoQuetzales =
    saldoCentavos / 100;
};

// CONFIRMAR REGISTRO DE PAGO
const confirmarRegistroPago = async () => {
  if (procesando.value) return;

  if (!formPago.value.citaId) {
    notificar(
      'Debe seleccionar una cita para registrar el pago.',
      'error'
    );
    return;
  }

  const monto = Number(formPago.value.montoQuetzales);
  const centavos = Math.round(monto * 100);
  const saldo = saldoSeleccionadoCentavos.value;

  if (
    !Number.isFinite(monto) ||
    monto <= 0 ||
    !Number.isSafeInteger(centavos)
  ) {
    notificar(
      'Ingrese un monto válido mayor que cero.',
      'error'
    );
    return;
  }

  if (saldo <= 0) {
    notificar(
      'Esta cita no tiene saldo pendiente.',
      'error'
    );
    return;
  }

  if (centavos > saldo) {
    notificar(
      `El monto ingresado Q${monto.toFixed(2)} ` +
      `supera el saldo pendiente Q${(saldo / 100).toFixed(2)}.`,
      'error'
    );
    return;
  }

  try {
    procesando.value = true;

    const res = await api.post('/pagos', {
      citaId: formPago.value.citaId,
      montoCentavos: centavos,
      metodo: formPago.value.metodo
    });

    mostrarModalPago.value = false;

    await cargarPagos();

    notificar(
      res.data?.mensaje ||
      'Pago registrado exitosamente.',
      'exito'
    );

  } catch (error) {
    notificar(
      error.response?.data?.mensaje ||
      'Error al registrar pago. Verifica tener una caja abierta.',
      'error'
    );

  } finally {
    procesando.value = false;
  }
};

// ABRIR ANULACIÓN
const abrirModalAnular = pago => {
  pagoSeleccionado.value = pago;
  motivoAnulacion.value = '';
  mostrarModalAnulacion.value = true;
};

// CONFIRMAR ANULACIÓN
const confirmarAnulacion = async () => {
  if (!pagoSeleccionado.value || procesando.value) {
    return;
  }

  if (!motivoAnulacion.value.trim()) {
    notificar(
      'Debe indicar el motivo de anulación.',
      'error'
    );
    return;
  }

  try {
    procesando.value = true;

    const res = await api.patch(
      `/pagos/${pagoSeleccionado.value._id}/anular`,
      {
        motivo: motivoAnulacion.value
      }
    );

    mostrarModalAnulacion.value = false;
    pagoSeleccionado.value = null;

    await cargarPagos();

    notificar(
      res.data?.mensaje ||
      'Pago anulado correctamente.',
      'exito'
    );

  } catch (error) {
    notificar(
      error.response?.data?.mensaje ||
      'Error al anular pago',
      'error'
    );

  } finally {
    procesando.value = false;
  }
};

// FILTROS
const pagosFiltrados = computed(() => {
  return pagos.value.filter(p => {
    const termino = busqueda.value
      .toLowerCase()
      .trim();

    const coincideTexto =
      !termino ||
      (
        p.numeroRecibo &&
        p.numeroRecibo.toLowerCase().includes(termino)
      ) ||
      (
        p.paciente &&
        `${p.paciente.nombres} ${p.paciente.apellidos}`
          .toLowerCase()
          .includes(termino)
      );

    const coincideEstado =
      !filtroEstado.value ||
      p.estado === filtroEstado.value;

    return coincideTexto && coincideEstado;
  });
});

// RESUMEN
const totalRecaudadoCentavos = computed(() => {
  return pagos.value
    .filter(p => p.estado === 'REGISTRADO')
    .reduce(
      (acum, p) => acum + (p.montoCentavos || 0),
      0
    );
});

const pagosRegistradosCount = computed(() => {
  return pagos.value.filter(
    p => p.estado === 'REGISTRADO'
  ).length;
});

const pagosAnuladosCount = computed(() => {
  return pagos.value.filter(
    p => p.estado === 'ANULADO'
  ).length;
});

// FORMATO DE FECHA
const formatearFecha = fechaStr => {
  if (!fechaStr) return '-';

  const d = new Date(fechaStr);

  return d.toLocaleString('es-GT', {
    dateStyle: 'short',
    timeStyle: 'short'
  });
};

// INICIALIZAR
onMounted(() => {
  cargarPagos();
  cargarCitas();
});

// LIMPIEZA
onUnmounted(() => {
  if (temporizadorAlerta) {
    clearTimeout(temporizadorAlerta);
  }
});
</script>

<style scoped>
.pagos-container {
  max-width: 1100px;
  margin: 30px auto;
  padding: 0 20px;
}

.header-seccion {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 25px;
  gap: 15px;
}

.header-seccion h2 {
  color: #1a365d;
  margin: 0;
}

.subtitulo {
  color: #64748b;
  margin: 5px 0 0;
}

.btn-nuevo {
  background: #2b6cb0;
  color: white;
  border: none;
  padding: 10px 18px;
  border-radius: 6px;
  font-weight: 600;
  cursor: pointer;
}

.resumen-grid {
  display: grid;
  grid-template-columns: repeat(
    auto-fit,
    minmax(220px, 1fr)
  );
  gap: 15px;
  margin-bottom: 25px;
}

.resumen-card {
  background: white;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
  display: flex;
  flex-direction: column;
}

.resumen-card .label {
  font-size: 0.85rem;
  color: #718096;
}

.resumen-card .valor {
  font-size: 1.6rem;
  font-weight: bold;
  color: #2d3748;
  margin-top: 5px;
}

.resumen-card .monto {
  color: #2b6cb0;
}

.text-anulado {
  color: #e53e3e !important;
}

.filtros-box {
  display: flex;
  gap: 15px;
  margin-bottom: 20px;
}

.input-busqueda {
  flex: 1;
  min-width: 0;
  padding: 10px 14px;
  border: 1px solid #cbd5e0;
  border-radius: 6px;
  font-size: 0.95rem;
}

.select-filtro {
  padding: 10px 14px;
  border: 1px solid #cbd5e0;
  border-radius: 6px;
  background: white;
  font-size: 0.95rem;
}

.tabla-responsive {
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
  overflow-x: auto;
}

.tabla-datos {
  width: 100%;
  border-collapse: collapse;
}

.tabla-datos th,
.tabla-datos td {
  padding: 12px 14px;
  text-align: left;
  border-bottom: 1px solid #e2e8f0;
}

.tabla-datos th {
  background: #f7fafc;
  color: #4a5568;
  font-size: 0.85rem;
}

.recibo-box {
  display: flex;
  flex-direction: column;
  gap: 3px;
}

.correlativo-recibo {
  font-weight: 700;
  color: #2b6cb0;
  font-family: monospace;
  font-size: 0.95rem;
}

.codigo-uuid {
  font-size: 0.75rem;
  color: #718096;
  font-family: monospace;
}

.saldo-info-box {
  background: #ebf8ff;
  border: 1px solid #bee3f8;
  color: #2b6cb0;
  padding: 8px 12px;
  border-radius: 6px;
  margin-bottom: 15px;
  font-size: 0.9rem;
}

.monto-tabla {
  font-weight: 700;
  color: #2d3748;
}

.badge-metodo {
  background: #e2e8f0;
  padding: 3px 8px;
  border-radius: 4px;
  font-size: 0.8rem;
  font-weight: 600;
  color: #4a5568;
}

.badge-estado {
  padding: 4px 10px;
  border-radius: 12px;
  font-size: 0.8rem;
  font-weight: bold;
}

.badge-exito {
  background: #c6f6d5;
  color: #22543d;
}

.badge-error {
  background: #fed7d7;
  color: #742a2a;
}

.btn-anular {
  background: #fed7d7;
  color: #c53030;
  border: 1px solid #feb2b2;
  padding: 5px 10px;
  border-radius: 4px;
  cursor: pointer;
  font-weight: 600;
  font-size: 0.8rem;
}

.texto-motivo {
  font-size: 0.8rem;
  color: #718096;
}

.mensaje-carga {
  padding: 30px;
  text-align: center;
  color: #718096;
}

/* MODALES */
.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  padding: 15px;
  box-sizing: border-box;
}

.modal-card {
  background: white;
  padding: 30px;
  border-radius: 10px;
  width: 90%;
  max-width: 500px;
  max-height: 90vh;
  overflow-y: auto;
  box-sizing: border-box;
}

.modal-card h3 {
  margin-top: 0;
  color: #1a365d;
}

.modal-desc {
  color: #718096;
  font-size: 0.95rem;
  margin-bottom: 20px;
}

.campo {
  margin-bottom: 18px;
}

.campo label {
  display: block;
  font-weight: 600;
  margin-bottom: 6px;
  color: #2d3748;
}

.campo input,
.campo select,
.campo textarea {
  width: 100%;
  padding: 10px;
  border: 1px solid #cbd5e0;
  border-radius: 6px;
  font-size: 0.95rem;
  box-sizing: border-box;
}

.campo-error {
  display: block;
  margin-top: 7px;
  color: #c53030;
  font-size: 0.85rem;
  font-weight: 600;
}

.modal-acciones {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  margin-top: 20px;
}

.btn-cancelar {
  background: #e2e8f0;
  border: none;
  padding: 10px 16px;
  border-radius: 6px;
  cursor: pointer;
  font-weight: 600;
  color: #4a5568;
}

.btn-confirmar {
  background: #2b6cb0;
  color: white;
  border: none;
  padding: 10px 16px;
  border-radius: 6px;
  cursor: pointer;
  font-weight: 600;
}

.btn-confirmar-anula {
  background: #c53030;
  color: white;
  border: none;
  padding: 10px 16px;
  border-radius: 6px;
  cursor: pointer;
  font-weight: 600;
}

.btn-confirmar:disabled,
.btn-confirmar-anula:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

/* NOTIFICACIONES FLOTANTES */
.notificacion-flotante {
  position: fixed !important;
  top: 20px;
  left: 50%;
  transform: translateX(-50%);
  z-index: 2147483647 !important;

  display: flex;
  align-items: center;
  gap: 12px;

  width: calc(100% - 32px);
  max-width: 560px;
  padding: 16px 18px;
  box-sizing: border-box;

  border-radius: 9px;
  font-size: 14px;
  font-weight: 600;
  line-height: 1.5;
  box-shadow: 0 8px 30px rgba(0, 0, 0, 0.3);
}

.notificacion-error {
  background: #f8d7da;
  color: #842029;
  border: 2px solid #dc3545;
}

.notificacion-exito {
  background: #d1e7dd;
  color: #0f5132;
  border: 2px solid #198754;
}

.notificacion-icono {
  font-size: 22px;
  flex-shrink: 0;
}

.notificacion-texto {
  flex: 1;
  overflow-wrap: anywhere;
}

.cerrar-notificacion {
  background: transparent;
  border: none;
  color: inherit;
  font-size: 24px;
  cursor: pointer;
  flex-shrink: 0;
}

@media (max-width: 600px) {
  .header-seccion,
  .filtros-box {
    flex-direction: column;
    align-items: stretch;
  }

  .modal-card {
    padding: 18px;
  }

  .modal-acciones {
    flex-wrap: wrap;
  }

  .notificacion-flotante {
    top: 12px;
  }
}
</style>

