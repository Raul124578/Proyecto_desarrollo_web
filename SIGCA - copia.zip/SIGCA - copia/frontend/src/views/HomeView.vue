
<template>
  <div class="home-page">

    <!-- Encabezado institucional -->
    <section class="hero-header">
      <h1>{{ nombreCentro }}</h1>
      <p>{{ lemaCentro }}</p>
    </section>

    <p v-if="cargando" class="mensaje-estado">
      Cargando información institucional...
    </p>

    <p v-else-if="errorCarga" class="mensaje-estado error" role="alert">
      {{ errorCarga }}
    </p>

    <template v-else>

      <!-- Carrusel dinámico desde MongoDB -->
      <section
        v-if="imagenes.length > 0"
        class="carrusel-container"
        aria-label="Carrusel institucional"
      >
        <div class="carrusel-slide">
          <img
            :src="imagenes[indiceActual].imagen"
            :alt="imagenes[indiceActual].titulo || 'Imagen institucional'"
          />
        </div>

        <!-- Navegación del carrusel -->
        <template v-if="imagenes.length > 1">
          <button
            type="button"
            class="carrusel-btn anterior"
            aria-label="Imagen anterior"
            @click="anteriorImagen"
          >
            &#10094;
          </button>

          <button
            type="button"
            class="carrusel-btn siguiente"
            aria-label="Imagen siguiente"
            @click="siguienteImagen"
          >
            &#10095;
          </button>

          <!-- Indicadores -->
          <div class="carrusel-indicadores">
            <button
              v-for="(img, idx) in imagenes"
              :key="idx"
              type="button"
              :class="['punto', { activo: idx === indiceActual }]"
              :aria-label="`Mostrar imagen ${idx + 1}`"
              :aria-current="idx === indiceActual ? 'true' : undefined"
              @click="indiceActual = idx"
            ></button>
          </div>
        </template>
      </section>

      <!-- Accesos rápidos -->
      <section class="accesos-rapidos">
        <div class="card-acceso">
          <h3>Nuestros Servicios</h3>
          <p>
            Conoce los tratamientos y áreas de atención que ofrecemos.
          </p>
          <router-link to="/servicios" class="btn-link">
            Ver Catálogo &rarr;
          </router-link>
        </div>

        <div class="card-acceso">
          <h3>Solicitar una Cita</h3>
          <p>
            Envía tu solicitud en línea para programar tu consulta.
          </p>
          <router-link to="/solicitar-cita" class="btn-link">
            Solicitar &rarr;
          </router-link>
        </div>

        <div class="card-acceso">
          <h3>Horarios de Atención</h3>
          <p>
            Consulta nuestras jornadas y horas de atención al público.
          </p>
          <router-link to="/horarios" class="btn-link">
            Consultar &rarr;
          </router-link>
        </div>
      </section>

      <!-- Misión y visión desde MongoDB -->
      <section
        v-if="contenido.mision || contenido.vision"
        class="mision-vision-container"
      >
        <div v-if="contenido.mision" class="bloque-mv">
          <h2>Misión</h2>
          <p>{{ contenido.mision }}</p>
        </div>

        <div v-if="contenido.vision" class="bloque-mv">
          <h2>Visión</h2>
          <p>{{ contenido.vision }}</p>
        </div>
      </section>

      <!-- Actividades institucionales -->
      <section
        v-if="actividades.length > 0"
        class="actividades-container"
      >
        <h2>Nuestras actividades</h2>

        <div class="actividades-grid">
          <article
            v-for="(actividad, index) in actividades"
            :key="index"
            class="card-actividad"
          >
            <h3>{{ actividad.titulo }}</h3>
            <p>{{ actividad.descripcion }}</p>
          </article>
        </div>
      </section>

    </template>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue';
import api from '../services/api';

// Datos institucionales
const contenido = ref({});
const cargando = ref(true);
const errorCarga = ref('');

// Control del carrusel
const indiceActual = ref(0);

// Información obtenida de MongoDB
const nombreCentro = computed(() =>
  contenido.value.institucion || "Centro K'aslemal"
);

const lemaCentro = computed(() =>
  contenido.value.lema || ''
);

const imagenes = computed(() =>
  Array.isArray(contenido.value.carrusel)
    ? contenido.value.carrusel.filter(item => item.imagen)
    : []
);

const actividades = computed(() =>
  Array.isArray(contenido.value.actividades)
    ? contenido.value.actividades
    : []
);

// Navegación del carrusel
const siguienteImagen = () => {
  if (imagenes.value.length === 0) return;

  indiceActual.value =
    (indiceActual.value + 1) % imagenes.value.length;
};

const anteriorImagen = () => {
  if (imagenes.value.length === 0) return;

  indiceActual.value =
    (indiceActual.value - 1 + imagenes.value.length)
    % imagenes.value.length;
};

// Obtener contenido publicado
const cargarContenido = async () => {
  cargando.value = true;
  errorCarga.value = '';

  try {
    const respuesta = await api.get('/contenido/publico');

    contenido.value = respuesta.data || {};
    indiceActual.value = 0;
  } catch (error) {
    console.error(
      'Error al cargar contenido institucional:',
      error
    );

    if (error.response?.status === 404) {
      errorCarga.value =
        'El contenido institucional aún no está publicado.';
    } else {
      errorCarga.value =
        'No se pudo cargar la información institucional.';
    }
  } finally {
    cargando.value = false;
  }
};

onMounted(cargarContenido);
</script>

<style scoped>
.home-page {
  max-width: 1000px;
  margin: 0 auto;
  padding: 20px;
}

/* Encabezado */
.hero-header {
  text-align: center;
  margin-bottom: 25px;
}

.hero-header h1 {
  color: #0056b3;
  font-size: 2rem;
  margin-bottom: 6px;
}

.hero-header p {
  color: #666;
  font-size: 1.05rem;
}

.mensaje-estado {
  text-align: center;
  padding: 20px;
  color: #555;
}

.mensaje-estado.error {
  color: #a61b29;
}

/* Carrusel: mantiene proporciones de las imágenes */
.carrusel-container {
  position: relative;
  width: 100%;
  aspect-ratio: 12 / 5;
  height: auto;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  margin-bottom: 35px;
  background-color: #f5f5f5;
}

.carrusel-slide {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
}

.carrusel-slide img {
  display: block;
  width: 100%;
  height: 100%;
  object-fit: contain;
  opacity: 1;
}

/* Botones de navegación */
.carrusel-btn {
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  background-color: rgba(0, 0, 0, 0.45);
  color: white;
  border: none;
  font-size: 24px;
  padding: 10px 15px;
  cursor: pointer;
  border-radius: 4px;
  z-index: 2;
}

.carrusel-btn:hover {
  background-color: rgba(0, 0, 0, 0.75);
}

.anterior {
  left: 15px;
}

.siguiente {
  right: 15px;
}

/* Indicadores */
.carrusel-indicadores {
  position: absolute;
  bottom: 10px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  gap: 8px;
  z-index: 2;
}

.punto {
  width: 12px;
  height: 12px;
  padding: 0;
  border: none;
  background-color: rgba(255, 255, 255, 0.65);
  border-radius: 50%;
  cursor: pointer;
}

.punto.activo {
  background-color: #007bff;
  box-shadow: 0 0 0 2px white;
}

/* Accesos rápidos */
.accesos-rapidos {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
  gap: 20px;
  margin-bottom: 35px;
}

.card-acceso {
  background-color: #fff;
  border: 1px solid #e0e0e0;
  border-radius: 6px;
  padding: 20px;
  text-align: center;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}

.card-acceso h3 {
  color: #333;
  margin-bottom: 10px;
}

.card-acceso p {
  color: #666;
  font-size: 0.9rem;
  margin-bottom: 15px;
}

.btn-link {
  color: #007bff;
  font-weight: bold;
  text-decoration: none;
}

/* Misión y visión */
.mision-vision-container {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 25px;
  background-color: #fff;
  border: 1px solid #e0e0e0;
  border-radius: 6px;
  padding: 25px;
  margin-bottom: 35px;
}

.bloque-mv h2 {
  color: #0056b3;
  margin-bottom: 12px;
  font-size: 1.3rem;
}

.bloque-mv p {
  color: #555;
  line-height: 1.6;
}

/* Actividades */
.actividades-container {
  margin-bottom: 35px;
}

.actividades-container h2 {
  color: #0056b3;
  text-align: center;
  margin-bottom: 20px;
}

.actividades-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 20px;
}

.card-actividad {
  padding: 20px;
  border: 1px solid #e0e0e0;
  border-radius: 6px;
  background-color: #fff;
}

.card-actividad h3 {
  color: #0056b3;
  margin-bottom: 10px;
}

.card-actividad p {
  color: #555;
  line-height: 1.6;
}

/* Adaptación a pantallas pequeñas */
@media (max-width: 768px) {
  .home-page {
    padding: 12px;
  }

  .hero-header h1 {
    font-size: 1.5rem;
  }

  .carrusel-btn {
    font-size: 18px;
    padding: 6px 9px;
  }

  .carrusel-indicadores {
    bottom: 6px;
  }

  .punto {
    width: 9px;
    height: 9px;
  }

  .mision-vision-container {
    grid-template-columns: 1fr;
    padding: 18px;
  }
}
</style>