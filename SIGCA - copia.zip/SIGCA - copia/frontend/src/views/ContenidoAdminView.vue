
<template>
  <main class="admin-contenido">
    <h2>Administración del contenido institucional</h2>
    <p>Edita la información que se mostrará en el portal público.</p>

    <p v-if="aviso" :class="['aviso', esError ? 'error' : 'exito']" role="status">
      {{ aviso }}
    </p>

    <p v-if="cargando">Cargando información...</p>

    <form v-else @submit.prevent="guardar">
      <h3>Información general</h3>

      <label>
        Nombre de la institución
        <input v-model.trim="form.institucion" required />
      </label>

      <label>
        Lema
        <input v-model.trim="form.lema" />
      </label>

      <label>
        Misión
        <textarea v-model.trim="form.mision" rows="4" required />
      </label>

      <label>
        Visión
        <textarea v-model.trim="form.vision" rows="4" required />
      </label>

      <h3>Información de contacto</h3>

      <label>
        Teléfono
        <input v-model.trim="form.contacto.telefono" />
      </label>

      <label>
        Correo institucional
        <input v-model.trim="form.contacto.correo" type="email" />
      </label>

      <label>
        Dirección
        <input v-model.trim="form.contacto.direccion" />
      </label>

      <label>
        Horario general de atención
        <input v-model.trim="form.contacto.horarioAtencion" />
      </label>

      <h3>Actividades</h3>

      <div v-for="(actividad, i) in form.actividades" :key="i" class="item">
        <label>
          Título
          <input v-model.trim="actividad.titulo" required />
        </label>
        <label>
          Descripción
          <textarea v-model.trim="actividad.descripcion" rows="2" />
        </label>
        <button type="button" class="eliminar" @click="form.actividades.splice(i, 1)">
          Eliminar actividad
        </button>
      </div>

      <button type="button" class="secundario" @click="form.actividades.push({ titulo: '', descripcion: '' })">
        + Agregar actividad
      </button>

      <h3>Horarios</h3>

      <div v-for="(horario, i) in form.horarios" :key="i" class="item">
        <label>
          Día
          <input v-model.trim="horario.dia" placeholder="Lunes a viernes" required />
        </label>
        <label>
          Horario
          <input v-model.trim="horario.horario" placeholder="08:00 a 17:00" required />
        </label>
        <button type="button" class="eliminar" @click="form.horarios.splice(i, 1)">
          Eliminar horario
        </button>
      </div>

      <button type="button" class="secundario" @click="form.horarios.push({ dia: '', horario: '' })">
        + Agregar horario
      </button>

      <h3>Carrusel de imágenes</h3>
      <p class="ayuda">Utiliza una URL de imagen accesible desde el navegador.</p>

      <div v-for="(imagen, i) in form.carrusel" :key="i" class="item">
        <label>
          URL de la imagen
          <input
            v-model.trim="imagen.imagen"
            type="text"
             placeholder="/imagenes/bienvenida.jpg"
             required
            />
        </label>
        <label>
          Título
          <input v-model.trim="imagen.titulo" />
        </label>
        <label>
          Descripción
          <textarea v-model.trim="imagen.descripcion" rows="2" />
        </label>
        <img v-if="imagen.imagen" :src="imagen.imagen" alt="Vista previa" class="preview" />
        <button type="button" class="eliminar" @click="form.carrusel.splice(i, 1)">
          Eliminar imagen
        </button>
      </div>

      <button type="button" class="secundario" @click="form.carrusel.push({ imagen: '', titulo: '', descripcion: '' })">
        + Agregar imagen
      </button>

      <div class="acciones">
        <button type="submit" :disabled="ocupado">
          {{ ocupado ? 'Guardando...' : 'Guardar cambios' }}
        </button>
      </div>
    </form>

    <section class="publicacion">
      <h3>Publicación</h3>
      <p>Estado: <strong>{{ form.publicado ? 'Publicado' : 'Borrador' }}</strong></p>
      <button type="button" :disabled="ocupado || cargando || !guardado" @click="publicar(true)">
        Publicar contenido
      </button>
      <button type="button" class="eliminar" :disabled="ocupado || cargando || !guardado" @click="publicar(false)">
        Retirar publicación
      </button>
      <p class="ayuda">Guarda los cambios antes de publicar.</p>
    </section>
  </main>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue';
import api from '../services/api';

const aviso = ref('');
const esError = ref(false);
const ocupado = ref(false);
const cargando = ref(true);
const guardado = ref(false);

const form = reactive({
  institucion: '',
  lema: '',
  mision: '',
  vision: '',
  contacto: {
    telefono: '',
    correo: '',
    direccion: '',
    horarioAtencion: ''
  },
  actividades: [],
  horarios: [],
  carrusel: [],
  publicado: false
});

const mostrarAviso = (mensaje, error = false) => {
  aviso.value = mensaje;
  esError.value = error;
};

const cargar = async () => {
  try {
    const { data } = await api.get('/contenido/admin');

    form.institucion = data.institucion || '';
    form.lema = data.lema || '';
    form.mision = data.mision || '';
    form.vision = data.vision || '';
    form.contacto = {
      telefono: data.contacto?.telefono || '',
      correo: data.contacto?.correo || '',
      direccion: data.contacto?.direccion || '',
      horarioAtencion: data.contacto?.horarioAtencion || ''
    };
    form.actividades = data.actividades || [];
    form.horarios = data.horarios || [];
    form.carrusel = data.carrusel || [];
    form.publicado = Boolean(data.publicado);
    guardado.value = Boolean(data._id);
  } catch (error) {
    mostrarAviso(
      error.response?.data?.mensaje || 'No se pudo cargar el contenido.',
      true
    );
  } finally {
    cargando.value = false;
  }
};

const guardar = async () => {
  ocupado.value = true;
  mostrarAviso('');

  try {
    const { data } = await api.put('/contenido/admin', {
      institucion: form.institucion,
      lema: form.lema,
      mision: form.mision,
      vision: form.vision,
      contacto: form.contacto,
      actividades: form.actividades,
      horarios: form.horarios,
      carrusel: form.carrusel
    });

    guardado.value = true;
    form.publicado = Boolean(data.contenido?.publicado);
    mostrarAviso('Contenido guardado correctamente en MongoDB.');
  } catch (error) {
    mostrarAviso(
      error.response?.data?.mensaje || 'No se pudo guardar el contenido.',
      true
    );
  } finally {
    ocupado.value = false;
  }
};

const publicar = async (valor) => {
  ocupado.value = true;

  try {
    await api.patch('/contenido/admin/publicacion', { publicado: valor });
    form.publicado = valor;
    mostrarAviso(valor ? 'Contenido publicado correctamente.' : 'Contenido retirado.');
  } catch (error) {
    mostrarAviso(
      error.response?.data?.mensaje || 'No se pudo cambiar la publicación.',
      true
    );
  } finally {
    ocupado.value = false;
  }
};

onMounted(cargar);
</script>

<style scoped>
.admin-contenido {
  max-width: 900px;
  margin: 30px auto;
  padding: 24px;
  background: white;
  border-radius: 8px;
}

h2, h3 { color: #0056b3; }
h3 { margin-top: 28px; }

form, .item {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

label {
  display: flex;
  flex-direction: column;
  gap: 6px;
  font-weight: 600;
}

input, textarea {
  width: 100%;
  box-sizing: border-box;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  font: inherit;
}

.item {
  border: 1px solid #ddd;
  padding: 15px;
  border-radius: 6px;
  margin: 10px 0;
}

button {
  padding: 10px 16px;
  border: none;
  border-radius: 5px;
  background: #0069d9;
  color: white;
  cursor: pointer;
  margin: 6px 8px 6px 0;
}

button:disabled { opacity: .5; cursor: not-allowed; }
.secundario { background: #357a38; }
.eliminar { background: #b02a37; }

.preview {
  max-width: 250px;
  max-height: 150px;
  object-fit: contain;
}

.acciones { margin-top: 20px; }
.publicacion { margin-top: 30px; border-top: 1px solid #ddd; }
.ayuda { color: #666; font-size: .9rem; }
.aviso { padding: 12px; border-radius: 5px; }
.exito { background: #d4edda; color: #155724; }
.error { background: #f8d7da; color: #721c24; }
</style>