
<template>
  <div class="contacto-container">
    <h2>Ponte en Contacto</h2>
    <p class="subtitulo">
      ¿Tienes dudas o necesitas información sobre nuestros servicios?
      Escríbenos.
    </p>

    <div class="contacto-layout">
      <!-- Información institucional -->
      <div class="info-box">
        <h3>{{ institucion.institucion || "Centro K'aslemal" }}</h3>

        <p class="info-item">
          📍 <strong>Ubicación:</strong>
          {{ institucion.contacto?.direccion || 'Información no disponible' }}
        </p>

        <p class="info-item">
          📞 <strong>Teléfono:</strong>
          {{ institucion.contacto?.telefono || 'Información no disponible' }}
        </p>

        <p class="info-item">
          ✉️ <strong>Correo:</strong>
          {{ institucion.contacto?.correo || 'Información no disponible' }}
        </p>

        <p class="info-item">
          🕒 <strong>Atención:</strong>
          {{ institucion.contacto?.horarioAtencion || 'Consultar horarios' }}
        </p>

        <div v-if="institucion.horarios?.length" class="info-nota">
          <h4>Horarios de atención</h4>
          <p v-for="(item, index) in institucion.horarios" :key="index">
            <strong>{{ item.dia }}:</strong> {{ item.horario }}
          </p>
        </div>

        <div class="info-nota">
          Para agendar una cita, utiliza la opción
          <strong>Solicitar Cita</strong> del menú principal.
        </div>
      </div>

      <!-- Formulario -->
      <div class="formulario-box">
        <div v-if="enviadoExitoso" class="alerta alerta-exito" role="status">
          <p>
            ¡Gracias por comunicarte! Tu mensaje fue registrado correctamente.
          </p>

          <button
            type="button"
            class="btn-enviar"
            @click="nuevoMensaje"
          >
            Enviar otra consulta
          </button>
        </div>

        <form v-else class="formulario" @submit.prevent="enviarMensaje">
          <div class="campo">
            <label for="nombre">Nombre completo *</label>
            <input
              id="nombre"
              v-model.trim="form.nombre"
              type="text"
              maxlength="120"
              placeholder="Ej. Juan Pérez"
              required
            />
          </div>

          <div class="campo-doble">
            <div class="campo">
              <label for="correo">Correo electrónico *</label>
              <input
                id="correo"
                v-model.trim="form.correo"
                type="email"
                maxlength="254"
                placeholder="ejemplo@dominio.com"
                required
              />
            </div>

            <div class="campo">
              <label for="telefono">Teléfono (8 dígitos) *</label>
              <input
                id="telefono"
                v-model="form.telefono"
                type="tel"
                inputmode="numeric"
                maxlength="8"
                placeholder="Ej. 55551234"
                required
                @input="limpiarTelefono"
              />
            </div>
          </div>

          <div class="campo">
            <label for="asunto">Asunto *</label>
            <input
              id="asunto"
              v-model.trim="form.asunto"
              type="text"
              maxlength="150"
              placeholder="Motivo de tu consulta"
              required
            />
          </div>

          <div class="campo">
            <label for="mensaje">Mensaje *</label>
            <textarea
              id="mensaje"
              v-model.trim="form.mensaje"
              rows="5"
              maxlength="3000"
              placeholder="Escribe tu consulta aquí..."
              required
            ></textarea>
          </div>

          <div
            v-if="errorValidacion"
            class="alerta alerta-error"
            role="alert"
          >
            {{ errorValidacion }}
          </div>

          <button
            type="submit"
            class="btn-enviar"
            :disabled="enviando"
          >
            {{ enviando ? 'Enviando mensaje...' : 'Enviar mensaje' }}
          </button>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup>
import { reactive, ref, onMounted } from 'vue';
import api from '../services/api';

const institucion = ref({});
const enviando = ref(false);
const enviadoExitoso = ref(false);
const errorValidacion = ref('');

const form = reactive({
  nombre: '',
  correo: '',
  telefono: '',
  asunto: '',
  mensaje: ''
});

const limpiarTelefono = () => {
  form.telefono = form.telefono.replace(/\D/g, '').slice(0, 8);
};

const cargarInformacion = async () => {
  try {
    const respuesta = await api.get('/contenido/publico');
    institucion.value = respuesta.data || {};
  } catch (error) {
    // El contenido puede no estar publicado todavía.
    console.warn('Contenido institucional no disponible:', error.message);
  }
};

const enviarMensaje = async () => {
  if (enviando.value) return;

  errorValidacion.value = '';

  const datos = {
    nombre: form.nombre.trim(),
    correo: form.correo.trim(),
    telefono: form.telefono.trim(),
    asunto: form.asunto.trim(),
    mensaje: form.mensaje.trim()
  };

  if (Object.values(datos).some(valor => !valor)) {
    errorValidacion.value = 'Completa todos los campos obligatorios.';
    return;
  }

  const regexCorreo = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  if (!regexCorreo.test(datos.correo)) {
    errorValidacion.value = 'Ingresa un correo electrónico válido.';
    return;
  }

  if (!/^\d{8}$/.test(datos.telefono)) {
    errorValidacion.value = 'El teléfono debe contener exactamente 8 dígitos.';
    return;
  }

  try {
    enviando.value = true;

    const respuesta = await api.post('/contacto', datos);

    if (respuesta.status === 201) {
      enviadoExitoso.value = true;
    } else {
      errorValidacion.value = 'No se pudo confirmar el envío del mensaje.';
    }
  } catch (error) {
    errorValidacion.value =
      error.response?.data?.mensaje ||
      'No fue posible enviar el mensaje. Verifica la conexión e intenta nuevamente.';

    console.error('Error al enviar contacto:', error);
  } finally {
    enviando.value = false;
  }
};

const nuevoMensaje = () => {
  Object.assign(form, {
    nombre: '',
    correo: '',
    telefono: '',
    asunto: '',
    mensaje: ''
  });

  enviadoExitoso.value = false;
  errorValidacion.value = '';
};

onMounted(cargarInformacion);
</script>

<style scoped>
.contacto-container {
  max-width: 950px;
  margin: 0 auto;
  padding: 30px 20px;
}

h2 {
  text-align: center;
  color: #333;
}

.subtitulo {
  text-align: center;
  color: #666;
  margin-bottom: 30px;
}

.contacto-layout {
  display: grid;
  grid-template-columns: 1fr 1.5fr;
  gap: 30px;
}

.info-box,
.formulario-box {
  background: #fff;
  border: 1px solid #e0e0e0;
  border-radius: 6px;
  padding: 25px;
}

.info-box {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.info-box h3 {
  color: #0056b3;
  margin-bottom: 10px;
}

.info-item {
  color: #555;
  font-size: 0.95rem;
  overflow-wrap: anywhere;
}

.info-nota {
  margin-top: 15px;
  background: #f8f9fa;
  padding: 12px;
  border-radius: 4px;
  font-size: 0.85rem;
  color: #666;
}

.info-nota p {
  margin-top: 8px;
}

.formulario {
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.campo-doble {
  display: flex;
  gap: 15px;
}

.campo-doble .campo {
  flex: 1;
  min-width: 0;
}

.campo {
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.campo label {
  font-size: 0.85rem;
  font-weight: 600;
  color: #495057;
}

.campo input,
.campo textarea {
  width: 100%;
  box-sizing: border-box;
  padding: 10px 12px;
  border: 1px solid #ced4da;
  border-radius: 4px;
  font-size: 0.95rem;
  font-family: inherit;
}

.campo input:focus,
.campo textarea:focus {
  outline: none;
  border-color: #80bdff;
  box-shadow: 0 0 0 2px rgba(0,123,255,.25);
}

.btn-enviar {
  background: #007bff;
  color: #fff;
  border: none;
  padding: 11px;
  font-size: 1rem;
  border-radius: 4px;
  cursor: pointer;
  font-weight: 600;
  margin-top: 10px;
}

.btn-enviar:hover:not(:disabled) {
  background: #0056b3;
}

.btn-enviar:disabled {
  background: #6c757d;
  cursor: not-allowed;
}

.alerta {
  padding: 12px 15px;
  border-radius: 4px;
  font-size: 0.9rem;
}

.alerta-exito {
  background: #d4edda;
  color: #155724;
  border: 1px solid #c3e6cb;
}

.alerta-error {
  background: #f8d7da;
  color: #721c24;
  border: 1px solid #f5c6cb;
}

@media (max-width: 768px) {
  .contacto-layout {
    grid-template-columns: 1fr;
  }

  .campo-doble {
    flex-direction: column;
  }
}
</style>
