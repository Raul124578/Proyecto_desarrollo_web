
<template>
  <div class="selector">
    <label class="etiqueta">Fotografía (opcional)</label>
    <div class="contenido">
      <img
        v-if="modelValue"
        :src="modelValue"
        alt="Fotografía"
        class="foto"
      />
      <div v-else class="foto vacia">👤</div>

      <div class="acciones">
        <input
          ref="entrada"
          type="file"
          accept="image/jpeg,image/png,image/webp"
          hidden
          :disabled="disabled || procesando"
          @change="seleccionar"
        />
        <button
          type="button"
          :disabled="disabled || procesando"
          @click="entrada?.click()"
        >
          {{ procesando ? 'Procesando...' : 'Seleccionar fotografía' }}
        </button>
        <button
          v-if="modelValue"
          type="button"
          :disabled="disabled || procesando"
          @click="quitar"
        >
          Quitar fotografía
        </button>
        <small>JPG, PNG o WebP. Máximo 5 MB.</small>
        <small v-if="error" class="error">{{ error }}</small>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';

defineProps({
  modelValue: { type: String, default: '' },
  disabled: { type: Boolean, default: false }
});

const emit = defineEmits(['update:modelValue']);
const entrada = ref(null);
const procesando = ref(false);
const error = ref('');

const quitar = () => {
  emit('update:modelValue', '');
  error.value = '';
  if (entrada.value) entrada.value.value = '';
};

const seleccionar = async (evento) => {
  const archivo = evento.target.files?.[0];
  if (!archivo) return;

  error.value = '';
  const permitidos = ['image/jpeg', 'image/png', 'image/webp'];

  if (!permitidos.includes(archivo.type)) {
    error.value = 'Selecciona una imagen JPG, PNG o WebP.';
    evento.target.value = '';
    return;
  }

  if (archivo.size > 5 * 1024 * 1024) {
    error.value = 'La imagen supera los 5 MB.';
    evento.target.value = '';
    return;
  }

  procesando.value = true;
  const url = URL.createObjectURL(archivo);

  try {
    const imagen = new Image();
    await new Promise((resolve, reject) => {
      imagen.onload = resolve;
      imagen.onerror = reject;
      imagen.src = url;
    });

    const escala = Math.min(
      1,
      400 / Math.max(imagen.width, imagen.height)
    );

    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(imagen.width * escala));
    canvas.height = Math.max(1, Math.round(imagen.height * escala));

    const contexto = canvas.getContext('2d');
    if (!contexto) throw new Error('No se pudo procesar la imagen.');

    contexto.fillStyle = '#ffffff';
    contexto.fillRect(0, 0, canvas.width, canvas.height);
    contexto.drawImage(imagen, 0, 0, canvas.width, canvas.height);

    const resultado = canvas.toDataURL('image/jpeg', 0.7);

    if (resultado.length > 600000) {
      throw new Error('La fotografía comprimida es demasiado grande.');
    }

    emit('update:modelValue', resultado);
  } catch (e) {
    error.value = e.message || 'No se pudo cargar la fotografía.';
  } finally {
    URL.revokeObjectURL(url);
    evento.target.value = '';
    procesando.value = false;
  }
};
</script>

<style scoped>
.selector { width: 100%; }
.etiqueta {
  display: block;
  margin-bottom: 10px;
  font-weight: 600;
  color: #475569;
}
.contenido {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 18px;
}
.foto {
  width: 110px;
  height: 110px;
  border-radius: 12px;
  object-fit: cover;
  border: 1px solid #cbd5e1;
}
.vacia {
  display: grid;
  place-items: center;
  background: #f1f5f9;
  font-size: 42px;
}
.acciones {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 8px;
}
button {
  padding: 9px 12px;
  background: #1769c2;
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
}
button:disabled { opacity: .6; cursor: not-allowed; }
small { color: #64748b; }
.error { color: #b91c1c; }
</style>