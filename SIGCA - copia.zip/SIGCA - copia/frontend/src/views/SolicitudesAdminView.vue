
<template>
  <div class="solicitudes-container">
    <div class="header-seccion">
      <div>
        <h2>Solicitudes de Citas</h2>
        <p class="subtitulo">
          Revisión de solicitudes en línea, seguimiento y conversión a citas formales
        </p>
      </div>
      <button @click="cargarDatos" class="btn-recargar">
        🔄 Actualizar Lista
      </button>
    </div>

    <!-- ALERTAS SOBRE TODOS LOS MODALES -->
    <Teleport to="body">
      <div
        v-if="mensajeAlerta"
        class="notificacion-flotante"
        :class="tipoAlerta === 'exito' ? 'notificacion-exito' : 'notificacion-error'"
        role="alert"
        aria-live="assertive"
      >
        <span>{{ tipoAlerta === 'exito' ? '✓' : '⚠' }}</span>
        <span class="notificacion-texto">{{ mensajeAlerta }}</span>
        <button
          type="button"
          class="cerrar-notificacion"
          aria-label="Cerrar notificación"
          @click="mensajeAlerta = ''"
        >
          ×
        </button>
      </div>
    </Teleport>

    <!-- FILTROS -->
    <div class="filtros-box">
      <input
        v-model="busqueda"
        type="text"
        placeholder="Buscar por solicitante, correo o teléfono..."
        class="input-busqueda"
      />

      <select v-model="filtroEstado" class="select-filtro">
        <option value="">Todos los estados</option>
        <option value="PENDIENTE">Pendientes</option>
        <option value="CONTACTADO">Contactados</option>
        <option value="CONVERTIDA">Convertidas a Cita</option>
        <option value="RECHAZADA">Rechazadas</option>
      </select>
    </div>

    <!-- TABLA DE SOLICITUDES -->
    <div class="tabla-responsive">
      <div v-if="cargando" class="mensaje-carga">
        Cargando solicitudes de citas...
      </div>

      <div
        v-else-if="solicitudesFiltradas.length === 0"
        class="mensaje-carga"
      >
        No se encontraron solicitudes registradas.
      </div>

      <table v-else class="tabla-datos">
        <thead>
          <tr>
            <th>Solicitante</th>
            <th>Contacto</th>
            <th>Servicio</th>
            <th>Fecha Preferida</th>
            <th>Motivo / Observación</th>
            <th>Estado</th>
            <th>Acciones</th>
          </tr>
        </thead>

        <tbody>
          <tr
            v-for="s in solicitudesFiltradas"
            :key="s._id"
          >
            <td>
              <strong>{{ s.nombre }}</strong>
              <div class="fecha-creacion">
                Recibida: {{ formatearFechaCorta(s.createdAt) }}
              </div>
            </td>

            <td>
              <div>📧 {{ s.correo }}</div>
              <div>📞 {{ s.telefono }}</div>
            </td>

            <td>
              <span v-if="s.servicioId">
                <strong>{{ s.servicioId.nombre }}</strong>
                <div class="servicio-info">
                  {{ s.servicioId.duracionMinutos }} min
                </div>
              </span>
              <span v-else>Servicio no especificado</span>
            </td>

            <td>
              <div>📅 {{ formatearFecha(s.fechaPreferida) }}</div>
              <small>
                Horario: {{ s.horarioPreferido || 'Cualquiera' }}
              </small>
            </td>

            <td>
              <span>{{ s.motivo || 'Sin mensaje' }}</span>
              <div v-if="s.observacionesAdmin" class="nota-admin">
                <strong>Admin:</strong> {{ s.observacionesAdmin }}
              </div>
            </td>

            <td>
              <span
                class="badge-estado"
                :class="'badge-' + s.estado.toLowerCase()"
              >
                {{ s.estado }}
              </span>
            </td>

            <td class="acciones">
              <button
                type="button"
                class="btn-accion btn-gestionar"
                @click="abrirModalGestion(s)"
              >
                ✏️ Gestionar
              </button>

              <button
                v-if="s.estado !== 'CONVERTIDA' && s.estado !== 'RECHAZADA'"
                type="button"
                class="btn-accion btn-convertir"
                @click="abrirModalConversion(s)"
              >
                📅 Convertir a Cita
              </button>

              <span
                v-else-if="s.estado === 'CONVERTIDA'"
                class="texto-convertida"
              >
                ✓ Agendada
              </span>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- MODAL: GESTIONAR SOLICITUD -->
    <div v-if="modalGestion" class="modal-overlay">
      <div class="modal-contenido">
        <div class="modal-header">
          <h3>Gestionar Solicitud de {{ solicitudSeleccionada?.nombre }}</h3>
          <button
            type="button"
            class="btn-cerrar"
            @click="cerrarModalGestion"
          >
            ×
          </button>
        </div>

        <form
          class="formulario-modal"
          @submit.prevent="guardarGestion"
        >
          <div class="campo">
            <label>Estado de la Solicitud *</label>
            <select v-model="formGestion.estado" required>
              <option value="PENDIENTE">PENDIENTE</option>
              <option value="CONTACTADO">CONTACTADO</option>
              <option value="RECHAZADA">RECHAZADA</option>
              <option value="CONVERTIDA" disabled>
                CONVERTIDA (Utilizar Convertir a Cita)
              </option>
            </select>
          </div>

          <div class="campo">
            <label>Observaciones Administrativas</label>
            <textarea
              v-model="formGestion.observacionesAdmin"
              rows="3"
              placeholder="Ingrese observaciones..."
            ></textarea>
          </div>

          <div class="modal-acciones">
            <button
              type="button"
              class="btn-cancelar"
              @click="cerrarModalGestion"
            >
              Cancelar
            </button>

            <button
              type="submit"
              class="btn-guardar"
              :disabled="guardando"
            >
              {{ guardando ? 'Guardando...' : 'Actualizar Solicitud' }}
            </button>
          </div>
        </form>
      </div>
    </div>

    <!-- MODAL: CONVERTIR SOLICITUD -->
    <div v-if="modalConversion" class="modal-overlay">
      <div class="modal-contenido modal-amplio">
        <div class="modal-header">
          <h3>Agendar Cita Formal desde Solicitud</h3>
          <button
            type="button"
            class="btn-cerrar"
            @click="cerrarModalConversion"
          >
            ×
          </button>
        </div>

        <div class="resumen-solicitud-card">
          <p>
            <strong>Solicitante:</strong>
            {{ solicitudSeleccionada?.nombre }}
          </p>
          <p>
            <strong>Contacto:</strong>
            {{ solicitudSeleccionada?.telefono }}
            / {{ solicitudSeleccionada?.correo }}
          </p>
          <p>
            <strong>Servicio:</strong>
            {{ solicitudSeleccionada?.servicioId?.nombre }}
          </p>
          <p>
            <strong>Fecha solicitada:</strong>
            {{ formatearFecha(solicitudSeleccionada?.fechaPreferida) }}
            ({{ solicitudSeleccionada?.horarioPreferido }})
          </p>
        </div>

        <form
          class="formulario-modal"
          @submit.prevent="ejecutarConversion"
        >
          <div class="campo">
            <label>1. Asignación del Paciente *</label>

            <div class="opciones-modo-paciente">
              <label
                class="opcion-card"
                :class="{ activa: modoPaciente === 'nuevo' }"
              >
                <input
                  v-model="modoPaciente"
                  type="radio"
                  value="nuevo"
                />
                <div>
                  <strong>🆕 Crear expediente nuevo</strong>
                  <div class="opcion-desc">
                    Registrar automáticamente al solicitante
                  </div>
                </div>
              </label>

              <label
                class="opcion-card"
                :class="{ activa: modoPaciente === 'existente' }"
              >
                <input
                  v-model="modoPaciente"
                  type="radio"
                  value="existente"
                />
                <div>
                  <strong>👤 Paciente ya registrado</strong>
                  <div class="opcion-desc">
                    Seleccionar paciente existente
                  </div>
                </div>
              </label>
            </div>
          </div>

          <!-- PACIENTE NUEVO -->
          <div
            v-if="modoPaciente === 'nuevo'"
            class="caja-formulario-paciente"
          >
            <div class="campo-doble">
              <div class="campo">
                <label>Nombres *</label>
                <input
                  v-model.trim="formNuevoPaciente.nombres"
                  type="text"
                  required
                />
              </div>

              <div class="campo">
                <label>Apellidos *</label>
                <input
                  v-model.trim="formNuevoPaciente.apellidos"
                  type="text"
                  required
                />
              </div>
            </div>

            <div class="campo-triple">
              <div class="campo">
                <label>Teléfono *</label>
                <input
                  v-model.trim="formNuevoPaciente.telefono"
                  type="text"
                  required
                />
              </div>

              <div class="campo">
                <label>Sexo *</label>
                <select v-model="formNuevoPaciente.sexo" required>
                  <option value="MASCULINO">Masculino</option>
                  <option value="FEMENINO">Femenino</option>
                  <option value="OTRO">Otro</option>
                </select>
              </div>

              <div class="campo">
                <label>Fecha de Nacimiento *</label>
                <input
                  v-model="formNuevoPaciente.fechaNacimiento"
                  type="date"
                  required
                />
              </div>
            </div>

            <div class="campo">
              <label>Dirección de Residencia *</label>
              <input
                v-model.trim="formNuevoPaciente.direccion"
                type="text"
                required
              />
            </div>
          </div>

          <!-- PACIENTE EXISTENTE -->
          <div v-else class="campo">
            <label>Seleccionar Paciente *</label>
            <select
              v-model="formConversion.pacienteId"
              required
            >
              <option value="" disabled>
                -- Selecciona un paciente registrado --
              </option>

              <option
                v-for="pac in pacientes"
                :key="pac._id"
                :value="pac._id"
              >
                {{ pac.nombres }} {{ pac.apellidos }}
                (Tel: {{ pac.telefono || 'S/N' }})
              </option>
            </select>
          </div>

          <!-- PROFESIONAL -->
          <div class="campo">
            <label>2. Profesional Responsable *</label>

            <select
              v-model="formConversion.profesionalId"
              required
            >
              <option value="" disabled>
                -- Selecciona un profesional --
              </option>

              <option
                v-for="pro in profesionales"
                :key="pro._id"
                :value="pro._id"
              >
                {{ pro.nombre }}
              </option>
            </select>
          </div>

          <!-- FECHA -->
          <div class="campo">
            <label>3. Fecha y Hora Exacta de Inicio *</label>
            <input
              v-model="formConversion.fechaInicio"
              type="datetime-local"
              required
            />
            <small class="campo-ayuda">
              Se reservará según la duración del servicio.
            </small>
          </div>

          <!-- OBSERVACIONES -->
          <div class="campo">
            <label>Observaciones de la Cita</label>
            <textarea
              v-model="formConversion.observaciones"
              rows="2"
              placeholder="Detalles adicionales..."
            ></textarea>
          </div>

          <div class="modal-acciones">
            <button
              type="button"
              class="btn-cancelar"
              @click="cerrarModalConversion"
            >
              Cancelar
            </button>

            <button
              type="submit"
              class="btn-guardar btn-confirmar-conversion"
              :disabled="guardando"
            >
              {{ guardando ? 'Agendando...' : 'Confirmar y Agendar Cita' }}
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue';
import api from '../services/api';

const solicitudes = ref([]);
const pacientes = ref([]);
const profesionales = ref([]);

const cargando = ref(true);
const guardando = ref(false);

const busqueda = ref('');
const filtroEstado = ref('');

const mensajeAlerta = ref('');
const tipoAlerta = ref('exito');

const modalGestion = ref(false);
const modalConversion = ref(false);
const solicitudSeleccionada = ref(null);

const modoPaciente = ref('nuevo');

const formNuevoPaciente = ref({
  nombres: '',
  apellidos: '',
  telefono: '',
  sexo: 'MASCULINO',
  fechaNacimiento: '2000-01-01',
  direccion: 'Ciudad de Guatemala'
});

const formGestion = ref({
  estado: 'PENDIENTE',
  observacionesAdmin: ''
});

const formConversion = ref({
  pacienteId: '',
  profesionalId: '',
  fechaInicio: '',
  observaciones: ''
});

// NOTIFICACIONES
let temporizadorAlerta = null;

const mostrarMensaje = (mensaje, tipo = 'exito') => {
  if (temporizadorAlerta) {
    clearTimeout(temporizadorAlerta);
  }

  mensajeAlerta.value = mensaje;
  tipoAlerta.value = tipo;

  temporizadorAlerta = setTimeout(() => {
    mensajeAlerta.value = '';
    temporizadorAlerta = null;
  }, 8000);
};

// CARGAR DATOS
const cargarDatos = async () => {
  try {
    cargando.value = true;

    const [resSolicitudes, resPacientes, resUsuarios] =
      await Promise.all([
        api.get('/solicitudes-cita'),
        api.get('/pacientes?estado=ACTIVO')
          .catch(() => ({ data: [] })),
        api.get('/usuarios/profesionales')
          .catch(() => ({ data: [] }))
      ]);

    solicitudes.value = resSolicitudes.data;
    pacientes.value = resPacientes.data;
    profesionales.value = resUsuarios.data;

  } catch (err) {
    mostrarMensaje(
      err.response?.data?.mensaje ||
      'Error al cargar datos del servidor',
      'error'
    );
  } finally {
    cargando.value = false;
  }
};

// FILTROS
const solicitudesFiltradas = computed(() => {
  return solicitudes.value.filter(s => {
    const coincideEstado =
      !filtroEstado.value || s.estado === filtroEstado.value;

    const termino = busqueda.value.toLowerCase().trim();

    const coincideTexto =
      !termino ||
      (s.nombre && s.nombre.toLowerCase().includes(termino)) ||
      (s.correo && s.correo.toLowerCase().includes(termino)) ||
      (s.telefono && s.telefono.includes(termino));

    return coincideEstado && coincideTexto;
  });
});

// GESTIONAR SOLICITUD
const abrirModalGestion = solicitud => {
  solicitudSeleccionada.value = solicitud;

  formGestion.value = {
    estado: solicitud.estado,
    observacionesAdmin: solicitud.observacionesAdmin || ''
  };

  modalGestion.value = true;
};

const cerrarModalGestion = () => {
  modalGestion.value = false;
  solicitudSeleccionada.value = null;
};

const guardarGestion = async () => {
  try {
    guardando.value = true;

    await api.patch(
      `/solicitudes-cita/${solicitudSeleccionada.value._id}/estado`,
      formGestion.value
    );

    cerrarModalGestion();
    await cargarDatos();

    mostrarMensaje(
      'Solicitud actualizada correctamente',
      'exito'
    );

  } catch (err) {
    mostrarMensaje(
      err.response?.data?.mensaje ||
      'Error al actualizar la solicitud',
      'error'
    );
  } finally {
    guardando.value = false;
  }
};

// ABRIR CONVERSIÓN
const abrirModalConversion = solicitud => {
  solicitudSeleccionada.value = solicitud;

  const pacienteCoincidente = pacientes.value.find(p =>
    p.telefono === solicitud.telefono ||
    (p.nombres + ' ' + p.apellidos)
      .toLowerCase()
      .includes(solicitud.nombre.toLowerCase())
  );

  const partesNombre = (solicitud.nombre || '')
    .trim()
    .split(/\s+/);

  const nombresSugeridos = partesNombre[0] || 'Solicitante';
  const apellidosSugeridos =
    partesNombre.slice(1).join(' ') || 'General';

  modoPaciente.value = pacienteCoincidente
    ? 'existente'
    : 'nuevo';

  formNuevoPaciente.value = {
    nombres: nombresSugeridos,
    apellidos: apellidosSugeridos,
    telefono: solicitud.telefono || '',
    sexo: 'MASCULINO',
    fechaNacimiento: '2000-01-01',
    direccion: 'Ciudad de Guatemala'
  };

  let fechaInicioDefecto = '';

  if (solicitud.fechaPreferida) {
    const fecha = String(solicitud.fechaPreferida).slice(0, 10);

    const hora =
      solicitud.horarioPreferido === 'Tarde'
        ? '14:00'
        : '09:00';

    fechaInicioDefecto = `${fecha}T${hora}`;
  }

  formConversion.value = {
    pacienteId: pacienteCoincidente
      ? pacienteCoincidente._id
      : '',
    profesionalId: profesionales.value[0]?._id || '',
    fechaInicio: fechaInicioDefecto,
    observaciones:
      `Cita confirmada a partir de solicitud web de ${solicitud.nombre}. ` +
      `Motivo original: ${solicitud.motivo || 'N/A'}`
  };

  modalConversion.value = true;
};

const cerrarModalConversion = () => {
  modalConversion.value = false;
  solicitudSeleccionada.value = null;
};

// CONVERTIR SOLICITUD A CITA
const ejecutarConversion = async () => {
  try {
    guardando.value = true;

    const payload = {
      profesionalId: formConversion.value.profesionalId,
      fechaInicio: formConversion.value.fechaInicio,
      observaciones: formConversion.value.observaciones
    };

    if (modoPaciente.value === 'nuevo') {
      payload.crearPacienteNuevo = true;
      payload.nuevoPaciente = formNuevoPaciente.value;
    } else {
      payload.crearPacienteNuevo = false;
      payload.pacienteId = formConversion.value.pacienteId;
    }

    await api.post(
      `/solicitudes-cita/${solicitudSeleccionada.value._id}/convertir-cita`,
      payload
    );

    cerrarModalConversion();
    await cargarDatos();

    mostrarMensaje(
      '¡Cita agendada y expediente generado con éxito!',
      'exito'
    );

  } catch (err) {
    mostrarMensaje(
      err.response?.data?.mensaje ||
      'Error al convertir la solicitud a cita',
      'error'
    );
  } finally {
    guardando.value = false;
  }
};

// FORMATO DE FECHAS
const formatearFecha = fechaStr => {
  if (!fechaStr) return '-';

  const [anio, mes, dia] = String(fechaStr)
    .slice(0, 10)
    .split('-')
    .map(Number);

  const fecha = new Date(anio, mes - 1, dia, 12);

  return fecha.toLocaleDateString('es-GT', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });
};

const formatearFechaCorta = fechaStr => {
  if (!fechaStr) return '-';

  const fecha = new Date(fechaStr);

  return fecha.toLocaleDateString('es-GT', {
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  });
};

onMounted(() => {
  cargarDatos();
});

onUnmounted(() => {
  if (temporizadorAlerta) {
    clearTimeout(temporizadorAlerta);
  }
});
</script>

<style scoped>
.solicitudes-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 25px 20px;
}

.header-seccion {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 15px;
  margin-bottom: 20px;
}

.subtitulo {
  color: #6c757d;
  font-size: 0.95rem;
  margin-top: 4px;
}

.btn-recargar {
  background: #6c757d;
  color: white;
  border: none;
  padding: 9px 14px;
  border-radius: 5px;
  cursor: pointer;
}

.filtros-box {
  display: flex;
  gap: 15px;
  margin-bottom: 20px;
}

.input-busqueda {
  flex: 1;
  min-width: 0;
  padding: 10px;
  border: 1px solid #ced4da;
  border-radius: 5px;
}

.select-filtro {
  min-width: 180px;
  padding: 10px;
  border: 1px solid #ced4da;
  border-radius: 5px;
}

.tabla-responsive {
  background: white;
  border: 1px solid #e0e0e0;
  border-radius: 7px;
  overflow-x: auto;
}

.tabla-datos {
  width: 100%;
  border-collapse: collapse;
  text-align: left;
  font-size: 0.9rem;
}

.tabla-datos th,
.tabla-datos td {
  padding: 12px 15px;
  border-bottom: 1px solid #eee;
  vertical-align: top;
}

.tabla-datos th {
  background: #f8f9fa;
  color: #495057;
}

.fecha-creacion,
.servicio-info {
  font-size: 0.8rem;
  color: #777;
  margin-top: 4px;
}

.mensaje-carga {
  text-align: center;
  padding: 35px;
  color: #6c757d;
}

.nota-admin {
  background: #f1f3f5;
  padding: 6px;
  margin-top: 6px;
  border-radius: 4px;
  font-size: 0.8rem;
}

.badge-estado {
  display: inline-block;
  padding: 5px 9px;
  border-radius: 12px;
  font-size: 0.75rem;
  font-weight: bold;
}

.badge-pendiente {
  background: #fff3cd;
  color: #856404;
}

.badge-contactado {
  background: #cce5ff;
  color: #004085;
}

.badge-convertida {
  background: #d4edda;
  color: #155724;
}

.badge-rechazada {
  background: #f8d7da;
  color: #721c24;
}

.acciones {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.btn-accion {
  border: none;
  padding: 7px 10px;
  border-radius: 5px;
  cursor: pointer;
  font-weight: 500;
}

.btn-gestionar {
  background: #e9ecef;
  color: #333;
}

.btn-convertir,
.btn-confirmar-conversion {
  background: #28a745 !important;
  color: white;
}

.texto-convertida {
  color: #28a745;
  font-weight: bold;
}

/* VENTANAS FLOTANTES */
.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  padding: 15px;
}

.modal-contenido {
  background: white;
  border-radius: 8px;
  width: 100%;
  max-width: 500px;
  padding: 22px;
  max-height: 90vh;
  overflow-y: auto;
}

.modal-amplio {
  max-width: 660px;
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
  margin-bottom: 15px;
  border-bottom: 1px solid #eee;
  padding-bottom: 12px;
}

.modal-header h3 {
  margin: 0;
}

.btn-cerrar {
  border: none;
  background: transparent;
  font-size: 25px;
  cursor: pointer;
}

.resumen-solicitud-card {
  background: #f8f9fa;
  border: 1px solid #e9ecef;
  border-radius: 5px;
  padding: 12px;
  margin-bottom: 15px;
}

.resumen-solicitud-card p {
  margin: 5px 0;
}

.formulario-modal {
  display: flex;
  flex-direction: column;
  gap: 14px;
}

.campo {
  display: flex;
  flex-direction: column;
  gap: 5px;
  min-width: 0;
}

.campo label {
  font-size: 0.85rem;
  font-weight: 600;
  color: #495057;
}

.campo input,
.campo select,
.campo textarea {
  padding: 9px 10px;
  border: 1px solid #ced4da;
  border-radius: 5px;
  font-size: 0.9rem;
  min-width: 0;
}

.campo-ayuda,
.opcion-desc {
  font-size: 0.78rem;
  color: #6c757d;
}

.opciones-modo-paciente {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
}

.opcion-card {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  border: 1px solid #ced4da;
  border-radius: 6px;
  padding: 12px;
  cursor: pointer;
}

.opcion-card.activa {
  border-color: #007bff;
  background: #f0f7ff;
}

.caja-formulario-paciente {
  background: #f8f9fa;
  padding: 12px;
  border: 1px solid #e9ecef;
  border-radius: 6px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.campo-doble,
.campo-triple {
  display: flex;
  gap: 10px;
}

.campo-doble .campo,
.campo-triple .campo {
  flex: 1;
}

.modal-acciones {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 15px;
}

.btn-cancelar,
.btn-guardar {
  border: none;
  padding: 10px 15px;
  border-radius: 5px;
  cursor: pointer;
  font-weight: 600;
}

.btn-cancelar {
  background: #6c757d;
  color: white;
}

.btn-guardar {
  background: #007bff;
  color: white;
}

.btn-guardar:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

/* ALERTA POR ENCIMA DE LOS MODALES */
.notificacion-flotante {
  position: fixed !important;
  top: 20px;
  left: 50%;
  transform: translateX(-50%);
  z-index: 2147483647 !important;

  width: calc(100% - 32px);
  max-width: 560px;
  padding: 16px 18px;

  display: flex;
  align-items: center;
  gap: 12px;

  border-radius: 9px;
  box-shadow: 0 8px 30px rgba(0, 0, 0, 0.3);
  font-size: 14px;
  font-weight: 600;
  line-height: 1.5;
  box-sizing: border-box;
}

.notificacion-error {
  background: #f8d7da;
  border: 2px solid #dc3545;
  color: #842029;
}

.notificacion-exito {
  background: #d1e7dd;
  border: 2px solid #198754;
  color: #0f5132;
}

.notificacion-texto {
  flex: 1;
  overflow-wrap: anywhere;
}

.cerrar-notificacion {
  background: transparent;
  border: none;
  color: inherit;
  font-size: 24px;
  cursor: pointer;
  flex-shrink: 0;
}

@media (max-width: 600px) {
  .header-seccion,
  .filtros-box,
  .campo-doble,
  .campo-triple {
    flex-direction: column;
  }

  .opciones-modo-paciente {
    grid-template-columns: 1fr;
  }

  .modal-contenido {
    padding: 16px;
  }

  .notificacion-flotante {
    top: 12px;
  }
}
</style>

