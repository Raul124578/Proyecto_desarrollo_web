
<template>
  <header class="navbar">
    <div class="navbar-contenido">

      <!-- LOGO Y NOMBRE DEL CENTRO -->
      <router-link
        to="/"
        class="marca"
        @click="cerrarMenus"
      >
        <div class="logo-icono">
          <img
            v-if="centroStore.logoUrl"
            :src="centroStore.logoUrl"
            alt="Logo del Centro K'aslemal"
          />
          <span v-else class="logo-alternativo">✚</span>
        </div>

        <div class="marca-texto">
          <strong>{{ centroStore.nombre || "K'aslemal" }}</strong>
          <small>Centro de Atención</small>
        </div>
      </router-link>

      <!-- BOTÓN PARA PANTALLAS PEQUEÑAS -->
      <button
        type="button"
        class="boton-movil"
        :aria-expanded="menuMovilAbierto"
        aria-label="Abrir o cerrar menú"
        @click="menuMovilAbierto = !menuMovilAbierto"
      >
        <svg
          width="23"
          height="23"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        >
          <path
            v-if="!menuMovilAbierto"
            d="M4 6h16M4 12h16M4 18h16"
          />
          <path
            v-else
            d="M18 6 6 18M6 6l12 12"
          />
        </svg>
      </button>

      <!-- NAVEGACIÓN PRINCIPAL -->
      <nav
        :class="[
          'navegacion',
          { 'movil-abierta': menuMovilAbierto }
        ]"
        aria-label="Navegación principal"
      >

        <!-- INICIO -->
        <router-link
          to="/"
          class="nav-enlace"
          @click="cerrarMenus"
        >
          Inicio
        </router-link>

        <!-- PORTAL PÚBLICO -->
        <div class="grupo-menu">
          <button
            type="button"
            class="nav-enlace boton-menu"
            :aria-expanded="menuAbierto === 'portal'"
            @click="alternarMenu('portal')"
          >
            Portal público
            <svg
              class="flecha"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
              aria-hidden="true"
            >
              <path d="m6 9 6 6 6-6" />
            </svg>
          </button>

          <div
            v-if="menuAbierto === 'portal'"
            class="submenu"
          >
            <router-link
              to="/servicios"
              @click="cerrarMenus"
            >
              <span>♡</span>
              Servicios
            </router-link>

            <router-link
              to="/horarios"
              @click="cerrarMenus"
            >
              <span>◷</span>
              Horarios
            </router-link>

            <router-link
              to="/contacto"
              @click="cerrarMenus"
            >
              <span>✉</span>
              Contacto
            </router-link>

            <router-link
              to="/solicitar-cita"
              @click="cerrarMenus"
            >
              <span>▣</span>
              Solicitar cita
            </router-link>
          </div>
        </div>

        <!-- OPCIONES DE USUARIOS AUTENTICADOS -->
        <template v-if="authStore.estaAutenticado">

          <!-- PACIENTES Y CITAS -->
          <div class="grupo-menu">
            <button
              type="button"
              class="nav-enlace boton-menu"
              :aria-expanded="menuAbierto === 'pacientes'"
              @click="alternarMenu('pacientes')"
            >
              Pacientes y citas
              <svg
                class="flecha"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="2"
                stroke-linecap="round"
                stroke-linejoin="round"
                aria-hidden="true"
              >
                <path d="m6 9 6 6 6-6" />
              </svg>
            </button>

            <div
              v-if="menuAbierto === 'pacientes'"
              class="submenu"
            >
              <router-link
                v-if="esAdministracion"
                to="/admin/pacientes"
                @click="cerrarMenus"
              >
                <span>♙</span>
                Pacientes
              </router-link>

              <router-link
                v-if="esAdministracion"
                to="/admin/responsables"
                @click="cerrarMenus"
              >
                <span>♧</span>
                Responsables
              </router-link>

              <router-link
                to="/admin/citas"
                @click="cerrarMenus"
              >
                <span>▦</span>
                Calendario de citas
              </router-link>

              <router-link
                to="/admin/solicitudes"
                @click="cerrarMenus"
              >
                <span>☷</span>
                Solicitudes
              </router-link>
            </div>
          </div>

          <!-- SERVICIOS -->
          <div
            v-if="esAdministracion"
            class="grupo-menu"
          >
            <button
              type="button"
              class="nav-enlace boton-menu"
              :aria-expanded="menuAbierto === 'servicios'"
              @click="alternarMenu('servicios')"
            >
              Servicios
              <svg
                class="flecha"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="2"
                stroke-linecap="round"
                stroke-linejoin="round"
                aria-hidden="true"
              >
                <path d="m6 9 6 6 6-6" />
              </svg>
            </button>

            <div
              v-if="menuAbierto === 'servicios'"
              class="submenu"
            >
              <router-link
                to="/admin/servicios"
                @click="cerrarMenus"
              >
                <span>⚙</span>
                Administrar servicios
              </router-link>

              <router-link
                to="/servicios"
                @click="cerrarMenus"
              >
                <span>♡</span>
                Ver servicios públicos
              </router-link>
            </div>
          </div>

          <!-- ADMINISTRACIÓN -->
          <div class="grupo-menu">
            <button
              type="button"
              class="nav-enlace boton-menu"
              :aria-expanded="menuAbierto === 'administracion'"
              @click="alternarMenu('administracion')"
            >
              Administración
              <svg
                class="flecha"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="2"
                stroke-linecap="round"
                stroke-linejoin="round"
                aria-hidden="true"
              >
                <path d="m6 9 6 6 6-6" />
              </svg>
            </button>

            <div
              v-if="menuAbierto === 'administracion'"
              class="submenu"
            >
              <router-link
                to="/admin/materiales"
                @click="cerrarMenus"
              >
                <span>▤</span>
                Materiales
              </router-link>

              <router-link
                v-if="authStore.esAdmin"
                to="/admin/usuarios"
                @click="cerrarMenus"
              >
                <span>♙</span>
                Usuarios
              </router-link>

              <router-link
                v-if="authStore.esAdmin"
                to="/admin/contenido"
                @click="cerrarMenus"
              >
                <span>▣</span>
                Contenido institucional
              </router-link>
            </div>
          </div>

          <!-- FINANZAS -->
          <div
            v-if="esAdministracion"
            class="grupo-menu"
          >
            <button
              type="button"
              class="nav-enlace boton-menu"
              :aria-expanded="menuAbierto === 'finanzas'"
              @click="alternarMenu('finanzas')"
            >
              Finanzas
              <svg
                class="flecha"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="2"
                stroke-linecap="round"
                stroke-linejoin="round"
                aria-hidden="true"
              >
                <path d="m6 9 6 6 6-6" />
              </svg>
            </button>

            <div
              v-if="menuAbierto === 'finanzas'"
              class="submenu"
            >
              <router-link
                to="/admin/pagos"
                @click="cerrarMenus"
              >
                <span>＄</span>
                Pagos
              </router-link>

              <router-link
                to="/admin/caja"
                @click="cerrarMenus"
              >
                <span>▣</span>
                Caja diaria
              </router-link>
            </div>
          </div>

          <!-- PERFIL DE USUARIO -->
          <div class="grupo-menu usuario-menu">
            <button
              type="button"
              class="usuario-boton"
              :aria-expanded="menuAbierto === 'usuario'"
              @click="alternarMenu('usuario')"
            >
              <span class="avatar">
                <svg
                  width="19"
                  height="19"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  stroke-width="2"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  aria-hidden="true"
                >
                  <circle cx="12" cy="8" r="4" />
                  <path d="M5 21a7 7 0 0 1 14 0" />
                </svg>
              </span>

              <span class="usuario-nombre">
                {{ authStore.nombreUsuario || 'Usuario' }}
              </span>

              <svg
                class="flecha"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="2"
                stroke-linecap="round"
                stroke-linejoin="round"
                aria-hidden="true"
              >
                <path d="m6 9 6 6 6-6" />
              </svg>
            </button>

            <div
              v-if="menuAbierto === 'usuario'"
              class="submenu submenu-derecha"
            >
              <div class="usuario-info">
                <strong>
                  {{ authStore.nombreUsuario || 'Usuario' }}
                </strong>
                <small>
                  {{ authStore.usuario?.rol || '' }}
                </small>
              </div>

              <button
                type="button"
                class="cerrar-sesion"
                @click="salir"
              >
                <span>⏻</span>
                Cerrar sesión
              </button>
            </div>
          </div>
        </template>

        <!-- INGRESO -->
        <template v-else>
          <router-link
            to="/login"
            class="boton-ingresar"
            @click="cerrarMenus"
          >
            Ingresar
          </router-link>
        </template>

      </nav>
    </div>
  </header>
</template>

<script setup>
import { computed, ref } from 'vue';
import { useRouter } from 'vue-router';
import { useCentroStore } from '../stores/centro';
import { useAuthStore } from '../stores/sesion';

const router = useRouter();
const centroStore = useCentroStore();
const authStore = useAuthStore();

const menuAbierto = ref(null);
const menuMovilAbierto = ref(false);

const esAdministracion = computed(() =>
  ['ADMINISTRADOR', 'RECEPCIONISTA'].includes(
    authStore.usuario?.rol
  )
);

const alternarMenu = (nombre) => {
  menuAbierto.value =
    menuAbierto.value === nombre ? null : nombre;
};

const cerrarMenus = () => {
  menuAbierto.value = null;
  menuMovilAbierto.value = false;
};

const salir = () => {
  cerrarMenus();
  authStore.cerrarSesion();
  router.push('/');
};
</script>

<style scoped>
/* BARRA PRINCIPAL */
.navbar {
  position: relative;
  z-index: 1000;
  width: 100%;
  background: #ffffff;
  border-bottom: 1px solid #e8edf4;
  box-shadow: 0 3px 16px rgba(22, 59, 102, 0.06);
}

.navbar-contenido {
  width: 100%;
  max-width: 1500px;
  min-height: 84px;
  margin: 0 auto;
  padding: 12px 30px;
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 24px;
}

/* LOGO Y NOMBRE */
.marca {
  display: flex;
  align-items: center;
  gap: 13px;
  flex-shrink: 0;
  text-decoration: none;
}

.logo-icono {
  width: 58px;
  height: 58px;
  border-radius: 14px;
  background: #edf5ff;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  flex-shrink: 0;
}

.logo-icono img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.logo-alternativo {
  font-size: 27px;
  color: #1769c2;
}

.marca-texto {
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 4px;
}

.marca-texto strong {
  font-size: 19px;
  font-weight: 750;
  color: #153e70;
  letter-spacing: -0.4px;
  white-space: nowrap;
}

.marca-texto small {
  font-size: 11px;
  font-weight: 500;
  color: #718096;
  white-space: nowrap;
}

/* NAVEGACIÓN */
.navegacion {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 6px;
  flex-wrap: wrap;
}

.nav-enlace {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 7px;
  min-height: 42px;
  padding: 10px 13px;
  box-sizing: border-box;
  background: transparent;
  border: 1px solid transparent;
  border-radius: 10px;
  color: #334e70;
  font-size: 13px;
  font-weight: 600;
  font-family: inherit;
  text-decoration: none;
  white-space: nowrap;
  cursor: pointer;
  transition:
    background 0.2s ease,
    color 0.2s ease,
    border-color 0.2s ease;
}

.nav-enlace:hover {
  background: #f0f6ff;
  color: #0866c2;
}

.nav-enlace.router-link-active {
  background: #eaf3ff;
  color: #0866c2;
}

.boton-menu[aria-expanded="true"] {
  background: #eaf3ff;
  color: #0866c2;
}

/* FLECHAS */
.flecha {
  display: inline-block;
  width: 15px;
  height: 15px;
  flex-shrink: 0;
  margin-left: 2px;
  color: #66809d;
  transition: transform 0.22s ease;
}

.boton-menu[aria-expanded="true"] .flecha,
.usuario-boton[aria-expanded="true"] .flecha {
  transform: rotate(180deg);
}

/* MENÚS DESPLEGABLES */
.grupo-menu {
  position: relative;
}

.submenu {
  position: absolute;
  top: calc(100% + 10px);
  left: 0;
  z-index: 2000;
  display: flex;
  flex-direction: column;
  gap: 4px;
  min-width: 245px;
  padding: 9px;
  background: #ffffff;
  border: 1px solid #e5edf7;
  border-radius: 14px;
  box-shadow: 0 14px 36px rgba(23, 53, 90, 0.15);
  animation: aparecerMenu 0.18s ease;
}

@keyframes aparecerMenu {
  from {
    opacity: 0;
    transform: translateY(-5px);
  }

  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.submenu a,
.submenu button {
  display: flex;
  align-items: center;
  gap: 11px;
  width: 100%;
  padding: 12px 13px;
  box-sizing: border-box;
  background: transparent;
  border: none;
  border-radius: 9px;
  color: #425873;
  font-family: inherit;
  font-size: 13px;
  font-weight: 500;
  text-align: left;
  text-decoration: none;
  cursor: pointer;
  transition: background 0.2s, color 0.2s;
}

.submenu a:hover,
.submenu a.router-link-active,
.submenu button:hover {
  background: #eef5ff;
  color: #0866c2;
}

.submenu a span {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 22px;
  color: #1769c2;
  font-size: 16px;
}

/* PERFIL */
.usuario-menu {
  margin-left: 10px;
}

.usuario-boton {
  display: flex;
  align-items: center;
  gap: 10px;
  min-height: 46px;
  padding: 7px 12px 7px 7px;
  background: #f4f8ff;
  border: 1px solid #dce8f8;
  border-radius: 12px;
  color: #163e70;
  font-family: inherit;
  cursor: pointer;
  transition: background 0.2s, border-color 0.2s;
}

.usuario-boton:hover,
.usuario-boton[aria-expanded="true"] {
  background: #eaf3ff;
  border-color: #c7ddfa;
}

.avatar {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 34px;
  height: 34px;
  border-radius: 10px;
  background: #dceaff;
  color: #1769c2;
}

.usuario-nombre {
  max-width: 160px;
  overflow: hidden;
  color: #163e70;
  font-size: 12px;
  font-weight: 700;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.submenu-derecha {
  left: auto;
  right: 0;
}

.usuario-info {
  display: flex;
  flex-direction: column;
  gap: 5px;
  padding: 12px 13px;
  border-bottom: 1px solid #e8edf4;
}

.usuario-info strong {
  color: #163e70;
  font-size: 13px;
}

.usuario-info small {
  color: #718096;
  font-size: 11px;
}

.submenu .cerrar-sesion {
  color: #dc3545;
  font-weight: 600;
}

.submenu .cerrar-sesion:hover {
  background: #fff0f1;
  color: #b91c1c;
}

/* BOTÓN INGRESAR */
.boton-ingresar {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 11px 20px;
  border-radius: 10px;
  background: #1769c2;
  color: white;
  font-size: 13px;
  font-weight: 700;
  text-decoration: none;
}

.boton-ingresar:hover {
  background: #10539d;
}

/* BOTÓN MÓVIL */
.boton-movil {
  display: none;
  padding: 9px 13px;
  background: #eef5ff;
  border: 1px solid #dce8f8;
  border-radius: 10px;
  color: #1769c2;
  cursor: pointer;
}

/* DISEÑO RESPONSIVO */
@media (max-width: 1250px) {
  .navbar-contenido {
    padding: 14px 22px;
    flex-wrap: wrap;
  }

  .boton-movil {
    display: flex;
    align-items: center;
    justify-content: center;
    margin-left: auto;
  }

  .navegacion {
    display: none;
    width: 100%;
    flex-direction: column;
    align-items: stretch;
    gap: 5px;
  }

  .navegacion.movil-abierta {
    display: flex;
  }

  .nav-enlace,
  .boton-menu {
    width: 100%;
    justify-content: space-between;
    text-align: left;
  }

  .grupo-menu {
    width: 100%;
  }

  .submenu {
    position: static;
    min-width: auto;
    margin: 6px 0 10px 12px;
    border-left: 3px solid #1769c2;
    border-radius: 8px;
    box-shadow: none;
    animation: none;
  }

  .usuario-menu {
    margin-left: 0;
  }

  .usuario-boton {
    width: 100%;
    justify-content: flex-start;
  }

  .usuario-boton .flecha {
    margin-left: auto;
  }

  .submenu-derecha {
    right: auto;
  }
}

@media (max-width: 480px) {
  .navbar-contenido {
    padding: 12px 15px;
  }

  .logo-icono {
    width: 48px;
    height: 48px;
  }

  .marca-texto strong {
    font-size: 16px;
  }

  .marca-texto small {
    font-size: 10px;
  }
}

@media (prefers-reduced-motion: reduce) {
  .flecha,
  .nav-enlace,
  .submenu,
  .usuario-boton {
    animation: none;
    transition: none;
  }
}
</style>
