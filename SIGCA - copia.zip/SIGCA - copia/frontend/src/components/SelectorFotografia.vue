
<template>
  <div class="selector-fotografia">
    <label class="titulo">Fotografía (opcional)</label>

    <div class="contenido">
      <div class="vista-previa">
        <img
          v-if="modelValue"
          :src="modelValue"
          alt="Fotografía seleccionada"
        />

        <div v-else class="sin-foto">
          <span class="icono">👤</span>
          <small>Sin fotografía</small>
        </div>
      </div>

      <div class="opciones">
        <input
          ref="archivoInput"
          type="file"
          accept="image/jpeg,image/png,image/webp"
          class="oculto"
          :disabled="disabled || procesando"
          @change="seleccionarArchivo"
        />

        <button
          type="button"
          class="btn-seleccionar"
          :disabled="disabled || procesando"
          @click="abrirSelector"
        >
          {{ procesando ? 'Procesando...' : 'Seleccionar fotografía' }}
        </button>

        <button
          v-if="modelValue"
          type="button"
          class="btn-quitar"
          :disabled="disabled || procesando"
          @click="quitarFotografia"
        >
          Quitar fotografía
        </button>

        <small>
          Formatos: JPG, PNG o WebP. Máximo 5 MB.
        </small>

        <p v-if="error" class="error" role="alert">
          {{ error }}
        </p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';

defineProps({
  modelValue: {
    type: String,
    default: ''
  },
  disabled: {
    type: Boolean,
    default: false
  }
});

const emit = defineEmits(['update:modelValue']);

const archivoInput = ref(null);
const procesando = ref(false);
const error = ref('');

const abrirSelector = () => {
  archivoInput.value?.click();
};

const quitarFotografia = () => {
  emit('update:modelValue', '');
  error.value = '';

  if (archivoInput.value) {
    archivoInput.value.value = '';
  }
};

const seleccionarArchivo = async (evento) => {
  const archivo = evento.target.files?.[0];

  if (!archivo) return;

  error.value = '';

  const formatosPermitidos = [
    'image/jpeg',
    'image/png',
    'image/webp'
  ];

  if (!formatosPermitidos.includes(archivo.type)) {
    error.value = 'Selecciona una imagen JPG, PNG o WebP.';
    evento.target.value = '';
    return;
  }

  if (archivo.size > 5 * 1024 * 1024) {
    error.value = 'La fotografía no debe superar 5 MB.';
    evento.target.value = '';
    return;
  }

  procesando.value = true;

  let urlTemporal = '';

  try {
    urlTemporal = URL.createObjectURL(archivo);

    const imagen = new Image();

    await new Promise((resolve, reject) => {
      imagen.onload = resolve;
      imagen.onerror = reject;
      imagen.src = urlTemporal;
    });

    const maximo = 400;

    const escala = Math.min(
      1,
      maximo / Math.max(imagen.width, imagen.height)
    );

    const canvas = document.createElement('canvas');

    canvas.width = Math.max(
      1,
      Math.round(imagen.width * escala)
    );

    canvas.height = Math.max(
      1,
      Math.round(imagen.height * escala)
    );

    const contexto = canvas.getContext('2d');

    if (!contexto) {
      throw new Error('No se pudo procesar la imagen.');
    }

    contexto.drawImage(
      imagen,
      0,
      0,
      canvas.width,
      canvas.height
    );

    const fotografiaComprimida = canvas.toDataURL(
      'image/jpeg',
      0.7
    );

    // Evita exceder el límite JSON del backend.
    if (fotografiaComprimida.length > 600000) {
      throw new Error(
        'La fotografía es demasiado grande. Selecciona otra.'
      );
    }

    emit('update:modelValue', fotografiaComprimida);
  } catch (e) {
    error.value =
      e.message || 'No se pudo procesar la fotografía.';
  } finally {
    if (urlTemporal) {
      URL.revokeObjectURL(urlTemporal);
    }

    evento.target.value = '';
    procesando.value = false;
  }
};
</script>

<style scoped>
.selector-fotografia {
  width: 100%;
}

.titulo {
  display: block;
  font-size: 13px;
  font-weight: 600;
  color: #475569;
  margin-bottom: 10px;
}

.contenido {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 20px;
}

.vista-previa {
  width: 110px;
  height: 110px;
  border: 2px dashed #cbd5e1;
  border-radius: 12px;
  overflow: hidden;
  background: #f8fafc;
  flex-shrink: 0;
}

.vista-previa img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.sin-foto {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  color: #64748b;
}

.icono {
  font-size: 38px;
}

.opciones {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 9px;
}

.opciones small {
  color: #64748b;
  font-size: 11px;
}

.oculto {
  display: none;
}

button {
  padding: 9px 13px;
  border-radius: 6px;
  cursor: pointer;
  font-weight: 600;
}

.btn-seleccionar {
  color: white;
  background: #1769c2;
  border: 1px solid #1769c2;
}

.btn-quitar {
  color: #b91c1c;
  background: white;
  border: 1px solid #fecaca;
}

button:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.error {
  color: #b91c1c;
  font-size: 12px;
  margin: 0;
}
</style>
