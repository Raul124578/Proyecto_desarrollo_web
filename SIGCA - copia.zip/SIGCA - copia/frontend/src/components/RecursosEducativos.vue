<template>
  <section class="recursos">
    <header class="cabecera"><h3>Recursos educativos</h3><button v-if="puedeGestionar" @click="nuevo">+ Nuevo recurso</button></header>
    <p v-if="mensaje" :class="{ error: esError }">{{ mensaje }}</p>
    <div class="controles"><input v-model="buscar" placeholder="Buscar título o descripción"/><select v-model="filtro"><option value="">Todos</option><option>ACTIVO</option><option>INACTIVO</option></select><button @click="cargar">Actualizar</button></div>
    <p v-if="cargando">Cargando recursos...</p>
    <div class="tabla" v-else><table><thead><tr><th>Título / descripción</th><th>Tipo</th><th>Registro</th><th>Estado</th><th>Acciones</th></tr></thead><tbody>
      <tr v-for="r in filtrados" :key="r._id"><td><strong>{{ r.titulo }}</strong><p>{{ r.descripcion }}</p></td><td>{{ r.tipo }}</td><td>{{ fecha(r.fechaRegistro) }}</td><td>{{ r.estado }}</td><td class="acciones"><a :href="r.enlaceRecurso" target="_blank" rel="noopener noreferrer">Abrir recurso</a><button v-if="puedeGestionar" @click="editar(r)">Editar</button><button v-if="puedeGestionar" @click="estado(r)">{{ r.estado === 'ACTIVO' ? 'Desactivar' : 'Activar' }}</button></td></tr>
      <tr v-if="!filtrados.length"><td colspan="5">No se encontraron recursos.</td></tr>
    </tbody></table></div>
    <h3>Asignar recurso a un paciente activo</h3>
    <form class="formulario" @submit.prevent="asignar"><label>Paciente<select v-model="asignacion.pacienteId" required><option value="">Seleccionar</option><option v-for="p in pacientes" :key="p._id" :value="p._id">{{ p.nombres }} {{ p.apellidos }}</option></select></label><label>Recurso activo<select v-model="asignacion.recursoId" required><option value="">Seleccionar</option><option v-for="r in recursos.filter(x => x.estado === 'ACTIVO')" :key="r._id" :value="r._id">{{ r.titulo }}</option></select></label><label>Observaciones<input v-model="asignacion.observaciones" maxlength="1000"/></label><button type="submit" :disabled="guardando">Asignar</button></form>
    <h3>Historial de asignaciones</h3>
    <div class="tabla"><table><thead><tr><th>Paciente</th><th>Recurso</th><th>Fecha</th><th>Observaciones</th></tr></thead><tbody><tr v-for="a in asignaciones" :key="a._id"><td>{{ a.paciente?.nombres }} {{ a.paciente?.apellidos }}</td><td>{{ a.recurso?.titulo || 'Recurso no disponible' }}</td><td>{{ fecha(a.fechaAsignacion) }}</td><td>{{ a.observaciones || '—' }}</td></tr><tr v-if="!asignaciones.length"><td colspan="4">Sin asignaciones.</td></tr></tbody></table></div>
    <div v-if="modal" class="fondo" @click.self="modal=false"><form class="ventana" @submit.prevent="guardar"><h3>{{ editando ? 'Editar recurso' : 'Nuevo recurso' }}</h3><label>Título<input v-model.trim="form.titulo" required maxlength="150"/></label><label>Descripción<textarea v-model.trim="form.descripcion" required maxlength="2000"/></label><label>Tipo<select v-model="form.tipo" required><option value="GUIA">Guía</option><option value="DOCUMENTO">Documento</option><option value="VIDEO">Video</option><option value="ENLACE">Enlace</option><option value="OTRO">Otro</option></select></label><label>Enlace (http:// o https://)<input v-model.trim="form.enlaceRecurso" type="url" required/></label><div class="acciones"><button type="button" @click="modal=false">Cancelar</button><button type="submit" :disabled="guardando">Guardar</button></div></form></div>
  </section>
</template>
<script setup>
import { computed, onMounted, ref } from 'vue';
import api from '../services/api';
import { useAuthStore } from '../stores/sesion';
const auth = useAuthStore();
const puedeGestionar = computed(() => ['ADMINISTRADOR','RECEPCIONISTA'].includes(auth.usuario?.rol));
const recursos=ref([]), pacientes=ref([]), asignaciones=ref([]), buscar=ref(''), filtro=ref(''), mensaje=ref(''), esError=ref(false), cargando=ref(false), guardando=ref(false), modal=ref(false), editando=ref(null);
const vacio=()=>({titulo:'',descripcion:'',tipo:'GUIA',enlaceRecurso:''});
const form=ref(vacio());
const asignacion=ref({pacienteId:'',recursoId:'',observaciones:''});
const fecha=v=>v?new Date(v).toLocaleDateString('es-GT'):'—';
const filtrados=computed(()=>recursos.value.filter(r=>(!filtro.value||r.estado===filtro.value)&&(`${r.titulo} ${r.descripcion}`).toLowerCase().includes(buscar.value.toLowerCase())));
const avisar=(s,error=false)=>{mensaje.value=s;esError.value=error;};
const errorDe=e=>e.response?.data?.mensaje || (e.response?.status===403?'Sin permisos':'No se pudo completar la operación');
const cargar=async()=>{cargando.value=true;try{const [r,p,a]=await Promise.all([api.get('/recursos-educativos'),api.get('/pacientes',{params:{estado:'ACTIVO'}}),api.get('/recursos-educativos/asignaciones')]);recursos.value=r.data;pacientes.value=p.data;asignaciones.value=a.data;}catch(e){avisar(errorDe(e),true);}finally{cargando.value=false;}};
const nuevo=()=>{editando.value=null;form.value=vacio();modal.value=true;};
const editar=r=>{editando.value=r._id;form.value={titulo:r.titulo,descripcion:r.descripcion,tipo:r.tipo,enlaceRecurso:r.enlaceRecurso};modal.value=true;};
const guardar=async()=>{guardando.value=true;try{if(editando.value)await api.put(`/recursos-educativos/${editando.value}`,form.value);else await api.post('/recursos-educativos',form.value);modal.value=false;avisar('Recurso guardado correctamente');await cargar();}catch(e){avisar(errorDe(e),true);}finally{guardando.value=false;}};
const estado=async r=>{if(!window.confirm('¿Cambiar estado del recurso?'))return;try{await api.patch(`/recursos-educativos/${r._id}/estado`,{estado:r.estado==='ACTIVO'?'INACTIVO':'ACTIVO'});await cargar();avisar('Estado actualizado');}catch(e){avisar(errorDe(e),true);}};
const asignar=async()=>{guardando.value=true;try{await api.post('/recursos-educativos/asignaciones',asignacion.value);asignacion.value={pacienteId:'',recursoId:'',observaciones:''};avisar('Recurso asignado correctamente');await cargar();}catch(e){avisar(errorDe(e),true);}finally{guardando.value=false;}};
onMounted(cargar);
</script>
<style scoped>
.recursos{padding:15px 0}.cabecera,.controles,.acciones{display:flex;gap:10px;align-items:center;justify-content:space-between;flex-wrap:wrap}.controles{margin:16px 0}button{background:#1769c2;color:white;border:0;border-radius:6px;padding:9px 12px;cursor:pointer}button:disabled{opacity:.5}input,select,textarea{box-sizing:border-box;width:100%;padding:10px;border:1px solid #cbd5e1;border-radius:6px}.controles input{flex:1;min-width:180px}.controles select{width:auto}.tabla{overflow:auto}table{border-collapse:collapse;width:100%;margin:12px 0 25px}th,td{text-align:left;border-bottom:1px solid #e2e8f0;padding:12px;vertical-align:top}th{background:#f8fafc}.formulario{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;margin:12px 0 25px}label{display:block;font-size:13px;font-weight:600}label input,label select,label textarea{margin-top:6px}.error{color:#b91c1c}.fondo{position:fixed;inset:0;background:#0008;display:grid;place-items:center;z-index:1000;padding:15px}.ventana{width:min(550px,100%);max-height:90vh;overflow:auto;background:white;padding:22px;border-radius:12px}.ventana label{margin:12px 0}
</style>
